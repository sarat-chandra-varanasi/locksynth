

element_at_index(Index, List, Element) :-
        element_at_index(Index, 0, List, Element).

element_at_index(Index, Index, [H|_], H).

element_at_index(Index, Curr, [_|T], Element) :-
           Curr < Index, 
           Curr1 is Curr + 1, 
           element_at_index(Index, Curr1, T, Element).

index_of(Element, List, Index) :-
            index_of(Element, List, 0, Index).


index_of(Element, [Element|_], Index, Index) :- !.
index_of(Element, [H|T], Curr, Index) :- 
           Element \= H, 
           Curr1 is Curr + 1, !, 
           index_of(Element, T, Curr1, Index).


index_in_term(Element, Term, Index) :-
        Term =.. [_|Args],
        index_of(Element, Args, Index).


frequency(List, Frequencies) :- 
      frequency(List, [], 0, Frequencies).

frequency([H|T], Store, CurrIndex, Frequencies) :-
        not(member((H, _, _), Store)),
        CurrIndex1 is CurrIndex + 1, 
        frequency(T, [(H, 1, [CurrIndex])|Store], CurrIndex1, Frequencies).

frequency([H|T], Store, CurrIndex, Frequencies) :-
        member((H, F, I), Store),
        F1 is F + 1, 
        NewElement = (H, F1, [CurrIndex|I]),
        replace((H,F,I),NewElement, Store, Store1),
        CurrIndex1 is CurrIndex + 1,
        frequency(T, Store1, CurrIndex1, Frequencies).

frequency([], Frequencies, _, Frequencies).

duplicate_arg_indices([H|T],R) :-
          H = (Element, Frequency, Indices),
          Frequency > 1, 
          Element = constant(_),
          duplicate_arg_indices(T, R).


duplicate_arg_indices([H|T],[X|R]) :-
          H = (Element, Frequency, Indices),
          Frequency > 1, 
          Element \= constant(_),
          X = (Element, Indices),
          duplicate_arg_indices(T, R). 

duplicate_arg_indices([H|T],R) :-
          H = (Element, Frequency, Indices),
          Frequency =< 1, 
          duplicate_arg_indices(T, R). 

duplicate_arg_indices([], []).

:- dynamic symcount/2.

gensym(X, X) :- 
    not(symcount(X,_)), !,
    assert(symcount(X,0)).

gensym(X, Y) :-
    symcount(X, C),
    retractall(symcount(X,_)),
    C1 is C + 1,
    assert(symcount(X,C1)),
    term_string(X, Xs),
    term_string(C1, Cs),
    string_concat(Xs, Cs, Ys),
    term_string(Y, Ys).

dup_symbols([FreqEntry|T], Dups) :-
     FreqEntry = (Element, Freq, Indices),
     gensymbols(Element, Freq, Symbols),
     pair(Symbols, Indices, Dups).
     

gensymbols(Element, Freq, Symbols) :-
       retractall(symcount(Element, _)),
       gensymbols(Element, Freq, [], Symbols).

gensymbols(Element, Freq, P, Symbols) :-
        Freq > 0, 
        gensym(Element, Sym),
        append(P, [Sym], P1),
        Freq1 is Freq - 1,
        gensymbols(Element, Freq1, P1, Symbols).


gensymbols(Element, 0, Symbols, Symbols). 


update_element_at_index(Element, Index, List, List1) :-
            update_element_at_index(Element, Index, List, 0, [], List1).


update_element_at_index(Element, Index, [H|T], CurrIndex, P, List1) :-
          CurrIndex < Index, 
          append(P, [H], P1),
          CurrIndex1 is CurrIndex + 1,
          update_element_at_index(Element, Index, T, CurrIndex1, P1, List1).

update_element_at_index(Element, Index, [H|T], CurrIndex, P, List1) :-
          Index = CurrIndex, 
          append(P, [Element], P1),
          append(P1, T, List1).




rewrite_same_var_term(Term, Term2, _) :-
    retractall(symcount(_, _)),
        Term =.. [Name|Args],
        frequency(Args, Frequencies),
        duplicate_arg_indices(Frequencies, ArgIndices),
        dup_symbols(ArgIndices, DupSymbols),
        update_dup_symbols(Args, DupSymbols, Args2),
        Term2 =.. [Name|Args2].

update_dup_symbols(Args, DupSymbols, Args1) :-
         update_dup_symbols(Args, DupSymbols, Args1).

update_dup_symbols(Args, [(Sym, Index)|T], Args2) :-
         update_element_at_index(Sym, Index, Args, Args1),
         update_dup_symbols(Args1, T, Args2).

update_dup_symbols(Args, [], Args).
