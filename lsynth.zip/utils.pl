

flatten([H|T], [H|R]) :-
      H \= [],
      H \= [_|_], !,
      flatten(T, R).

flatten([H|T], R) :-
      H = [], !,
      flatten(T, R).

flatten([H|T], R) :-
      !,
      flatten(H, R1),
      flatten(T, R2),
      append(R1, R2, R).

flatten([], []).


remove_duplicates([H|T],R) :-
         member(H, T), !,
         remove_duplicates(T, R).

remove_duplicates([H|T], [H|R]) :-
          not(member(H, T)), !,
          remove_duplicates(T, R).
    
remove_duplicates([], []).

write_to_file(File, Content) :-
      current_output(PrevStream),
      open(File, write, NewStream),
      set_output(NewStream),
      write(Content),
      set_output(PrevStream),
      close(NewStream).


set_intersect([H|T], List, [H|R]) :-
           member(H, List),
           set_intersect(T, List, R).

set_intersect([H|T], List, R) :-
           not(member(H, List)),
           set_intersect(T, List, R).

set_intersect([], _, []).


replace(X, Y, [X|T], [Y|R]) :-
             replace(X, Y, T, R).

replace(X, Y, [X1|T], [X1|R]) :-
              X \= X1,
              replace(X, Y, T, R).

replace(X, Y, [], []).


 maplist_general(Pred, [H|T], [Result|R]) :-
         append(H, [Result], H1),
         Term =.. [Pred|H1],
         call(Term),
         maplist_general(Pred, T, R).

maplist_general(_, [], []).


set_diff([H|T], List, [H|R]) :-
           not(member(H, List)),
           set_diff(T, List, R).


set_diff([H|T], List, R) :-
          member(H, List),
          set_diff(T, List, R).


set_diff([], _, []).


pair([H|T], [H1|T1], [(H, H1)|R]) :-
             pair(T, T1, R).

pair([], [], []).

conjunct_str([], '').

conjunct_str([H], Str) :-
      term_string(H, Str).


conjunct_str([H|T], Str) :-
      term_string(H, S1),
      string_concat(S1, ',', S2),
      conjunct_str(T, S3),
      string_concat(S2, S3, Str).

list_str([H], H) :- !.

list_str([H|T], Str) :-
      T \= [],
      string_concat(H, ', ', S2),
      conjunct_str(T, S3),
      string_concat(S2, S3, Str).

lint_string(Str, Str2) :-
      string_chars(Str, List),
      remove('"', List, List1),
      string_chars(Str2, List1).


remove(H, [H|T], R) :-
         remove(H, T, R).

remove(H, [X|T], [X|R]) :-
         X \== H, 
         remove(H, T, R).

remove(_, [], []).

rules_str(Rules, Str) :-
     rules_str_helper(Rules, "", Str).

rules_str_helper([H|T], S, S2) :-
         string_concat(H, S, S1),
         rules_str_helper(T, S1, S2).

rules_str_helper([], S, S).


cross_element(X, [H|T], [(X,H)|R]) :-
         cross_element(X, T, R).

cross_element(_, [], []).


choose_2(List, Combinations) :-
      choose_2_helper(List, Combos),
      flatten(Combos, Combinations).

choose_2_helper([H|T], [R|R1])  :-
      pair(H, T, R),
      choose_2_helper(T, R1).

choose_2_helper([], []).


pair_list_value_helper([H|T], Value, [(H, Value)|R]) :-
         pair_list_value_helper(T, Value, R).

pair_list_value_helper([], _, []).

pair_list_value(List, Value, Pairs) :-
        pair_list_value_helper(List, Value, Pairs2),
        flatten(Pairs2, Pairs).

clear :- 
     once(shell(clear, 0)).

b :-
     shell('./merge.sh', _).


build :-
     shell('./merge.sh', _).

set_ds(Val) :-
      retractall(ds(_)),
      assert(ds(Val)).


add_underscore(A, B, C) :-
    string_concat(A, "_", As),
    string_concat(As, B, C).



reduce(List, Op, I, X) :-
      List = [A, B|T], !,
      call(Op, A, B, X1),
      reduce_helper(T, Op, X1, X).

reduce_helper([], Op, P, P).          

reduce_helper([H|T], Op, P, X) :-
         call(Op, P, H, X1),
         reduce_helper(T, Op, X1, X).  

reduce([H], _, _, H) :- !.

          
sum(X, Y, Z) :- Z is X + Y. 

l :- [merge].
bl :- b, l.

exit :- halt.

zip(X, [H|T], [(X,H)|R]) :-
      !, zip(X, T, R).

zip(_, [], []). 


show(LineNo) :-
   term_string(LineNo, S),
   string_concat('head -n ', S, S1),
   string_concat(S1, ' merge.pl | tail -n 1', Cmd),
   shell(Cmd, _).

gen_rounds(Num, Facts) :-
   gen_rounds(Num, [], Facts).


gen_rounds(Num, P, Rules)  :-
       Num > 1,
       Rule = rule(head(round(constant(Num))), body([])), 
       Num1 is Num - 1,
       gen_rounds(Num1, [Rule|P], Rules).

gen_rounds(1, P, Rules) :- 
     Rule = rule(head(round(constant(1))), body([])), 
     Rules = [Rule|P].  


add_space(Str, Str1) :-
     string_concat(Str, ' ', Str1).
 
copy_command(Source, Destination, Cmd) :-
     maplist(add_space, ["cp", Source], Prefix),
     append(Prefix, [Destination], Args),
     reduce(Args, string_concat, "", Cmd).

base_theory_path(Path) :- 
      %ds(DS),
      %ds_file(DSFile),
      %input_path(InputPath),
      %string_concat(InputPath, DSFile, Path),
      input_path(Path). 

ds_file(File) :-
      ds(DS),
      term_string(DS, DS1),
      string_concat(DS1, '.lp', File).


write_rules_to_file(File, Rules) :-
          write_rules(Rules, S),
          rules_str(S, S1),
          write_to_file(File, S1).


add_contents_to_file(File, Contents) :-
       open(File, append, Stream),
       current_output(Curr),
       set_output(Stream),
       write(Contents),
       set_output(Curr),
       close(Stream).

get_name(Term, Name) :-
       Term =.. [Name|_].

assert_list([H|T]) :-
         assert(H),
         assert_list(T).

assert_list([]).


:- dynamic input_path/1.
:- dynamic reasoning_path/1.

% custom reset 
cr :- 
 retractall(input_path(_)),
 retractall(reasoning_path(_)),
 assert(input_path('')),
 assert(reasoning_path('')).


%  cross_product([H|T], )


remove_term(([H|T], Term), [H|R]) :-
        H \= rule(_, _),
        remove_term((T, Term), R).

remove_term(([H|T], Term), R) :-
        H = rule(head(Head), _),
        Head =.. [Term|_],
        remove_term((T, Term), R).

remove_term(([H|T], Term), [H|R]) :-
       H = rule(head(Head), _),
       Head =.. [Name|_],
       Name \= Term,
       remove_term((T, Term), R).


remove_term(([],_), []). 


tuple_list(Tuple, List) :-
     tuple_list(Tuple, [], List).

tuple_list(Tuple, P, List) :-
     Tuple =.. [',', X, Y], !,
     append(P, [X], P1),
     tuple_list(Y, P1, List).

tuple_list(Tuple, P, List) :-
     Tuple =.. [X], !, 
     append(P, [X], List).

tuple_list(Tuple, P, List) :-
       !, append(P, [Tuple], List).

begins_with(Term, Str) :-
       term_string(Term, S),
       string_chars(S, Chars),
       string_chars(Str, Pattern),
       append(Pattern, _, Chars).