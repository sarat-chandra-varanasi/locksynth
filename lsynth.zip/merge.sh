rm merge.pl
cat *.pl >> merge.pl
