

:- discontiguous unfold_and_check/3.
:- discontiguous unfold/3.
:- discontiguous map_vars_domain/3.
:- discontiguous rewrite_primitives_helper/2.
:- discontiguous rename_steps/4.
:- discontiguous code/7.
:- discontiguous next_node/3.
:- discontiguous traversal_start/2.
:- discontiguous unfold2_goals/3.
:- discontiguous rules_str_helper/3.
:- discontiguous unfold2/2.
:- discontiguous pair/3.
:- discontiguous nonterminal/2.
:- dynamic primitive_write_step/2.
:- dynamic time_dependent/2.
:- discontiguous format_constructor_rules/2.
:- discontiguous operation/2.
:- discontiguous modifies/3.
:- discontiguous causes/3.
:- discontiguous write_operation/3.
:- discontiguous start_node/2.
:- discontiguous end_node/2.
:- discontiguous start_node/2.
:- discontiguous end_node/2.
:- discontiguous class/2.
:- discontiguous pre/4.
:- discontiguous gen_text/4.
:- discontiguous program_steps/4.
:- discontiguous format_sasp_arg/2.
:- discontiguous format_sasp_rule/2.
:- discontiguous project_into_time_helper/2.
:- dynamic signature/2.
:- dynamic signature/3.
:- discontiguous primitive_write_operation/2.
:- dynamic ds/1.
:- discontiguous class/2.
:- dynamic class/2.
:- dynamic node_property/1.
:- discontiguous node_property/1.

signature(locked, 1, [node]).
sig_type(locked, 1, [node]).
eq_theory(Rules) :-
 	cleanup, 
 	retractall(symcount(_, _)),
        base_theory(UserDefinedTheory),
        assert_base_theory(UserDefinedTheory),
        maplist(rewrite_rule, UserDefinedTheory, Rewrites),
        maplist(gen_eq_rules, Rewrites, EqRules),
        flatten(EqRules, EqRules1),
        remove_duplicates(EqRules1, EqRules2),
        findall(X, invariant(X), Invariants), 
        maplist(gen_invariant_rule_notime, Invariants, InvariantConstraints),
        append(Rewrites, EqRules2, Part1), 
        node_property_eq_rules(NodePropEqRules),
        append(Part1, NodePropEqRules, Part2),
        append(Part2, InvariantConstraints, Rules),
        format_constructor(ConstructorRules),
        assert_list(ConstructorRules).


gen_invariant_rule_notime(not(Pred), constraint([Pred])).


gen_invariant_rule_notime(Pred, constraint([not(Pred)])).


prepare_eq_theory :-
       % shell('rm eq_check', _),
       copy_command('./eq_theories.lp', 'eq_theory', Cmd),
       shell(Cmd, _),
       cleanup,
       eq_theory(Rules),
       write_rules(Rules, S),
       rules_str(S,S1),
       add_contents_to_file('eq_theory', S1).% Find symbolic instances of data structure definition that satisfiy a relation
% unfold sytematically the definition of the data stucture
% we can find the instances ourselves (or) get it as input from user of the system
% every predicate used in a time-independent fashion

     
equiv_class(Conjunct, Class) :-
     unfold_and_check(Conjunct, Class).


unfold_and_check(Conjunct, Class) :-
        unfold_and_check(Conjunct, Class, 0).


unfold_and_check(Conjunct, _, Depth) :-
         %findall(Terms, unfold(Depth, Terms), List),
         %check_list(List, Conjunct).
         unfold(Depth, Terms),
         flatten(Terms, Flattened),
         check_term(Flattened, Conjunct).

unfold_and_check(Conjunct, Class, Depth) :-
        Depth1 is Depth + 1,
        unfold_and_check(Conjunct, Class, Depth1).


unfold_and_flatten(Depth, Terms2) :-
      unfold(Depth, Terms), flatten(Terms, Terms2). 

unfold_and_check(Conjunct, Class, Depth) :-
         findall(Terms, unfold_and_flatten(Depth, Terms), List),
         not(check_list(List, Conjunct)),
         Depth1 is Depth + 1,
         unfold_and_check(Conjunct, Class, Depth1).

check_term(Terms, Conjunct) :-
        prepare_conjunct(Conjunct, ConjunctStr),
        flatten(Terms, Terms2),
        get_terminals(Terms2, Terms3),
        prepare_terms(Terms3, TermsStr),
        % append_definitions_to_theory([ConjunctStr, TermsStr]),
        string_concat(ConjunctStr, TermsStr, S2),
        copy_command('eq_theory', './reasoning_files/eq_check', Cmd),
        shell(Cmd, _),
        add_contents_to_file('./reasoning_files/eq_check', S2),
        % solve_models(equiv, success).
        solve_models('eq_check', one, X), 
        X \= [].


check_list([H|_], Conjunct) :-
         check_term(H, Conjunct), !.

check_list([H|T], Conjunct) :-
        not(check_term(H, Conjunct)),
        check_list(T, Conjunct).


% rule(head(list), body([node(h), num(kh), num(var('KX')), edge(h, 'X'), key(h, kh), key('X', 'KX'), lt(kh, 'KX'), suffix('X')])).
% rule(head(suffix(t)), body([])).
% rule(head(suffix('X'),body([node('X'), node('Y'), num('KX'), num('KY'), key('X', 'KX'), key('Y', 'KY'), lt('KX', 'KY'), suffix('Y')])).

%rule(head(suffix(t)), body([])).
%rule(head(suffix(var(x))), body([node(var(x)), node(var(y)), num(var(kx)), num(var(ky)), edge(var(x), var(y)),
%          key(var(x), var(kx)), key(var(y), var(ky)), lt(var(kx), var(ky)), suffix(var(y))])).

%rule(head(list), 
%	 body([
%  node(h),
%  num(kh),
%  num(var(kx)),
%  edge(h, var(x)),
%  key(h, kh),
%  key(var(x), var(kx)),
%  lt(kh, var(kx)),
%  suffix(var(x)),
%  node(var(x))
%])).


%rule(head(tree), body([node(var(x)), root(var(x)), node(var(y)), left(var(x), var(y)), node(var(z)),
%                       right(var(x), var(z)), tree(var(y)), tree(var(z))])).

%rule(head(tree(nil)), body([])).

%rule(head(tree(x)), body([node(var(x)), node(var(y)), left(var(x), var(y)), node(var(z)),
%                       right(var(x), var(z)), tree(var(y)), tree(var(z))])).


%terminal(edge).
%terminal(node).
%terminal(num).
%terminal(key).
% start(list).
%nonterminal(suffix, 1).
% start(tree).
%nonterminal(tree, 1).

unfold(Depth, [Terms|Terms1]) :- 
     start(Start),
     find_rule(Start, Rule), 
     Rule = rule(head(Start), body(Body)),
     vars_of(Body, Vars2),
     gen_fresh_symbols(Vars2, Body, FreshVars),
     nonground_terms(Body, Nonground),
     set_diff(Body, Nonground, TermsGround),
     (Depth = 0 -> (
                   %all_possible_substitutions(FreshVars, Body, Terms),
                   purge_vars_with_constants(Nonground, TermsSubstituted),
                   append(TermsGround, TermsSubstituted, Terms),
                   Terms1 = [])
                ;
     subst_fresh_vars_conjunct(FreshVars, Body, Body1),
     get_nonterminals(Body1, NonTerminals),
     set_diff(Body1, NonTerminals, Terms),
     pair_depth(NonTerminals, 0, Remainder),
     unfold(Remainder, Terms1, Depth)
     ).


unfold([], [], _).

find_rule(Pred, Rule) :-
    rule(head(Head), body(B)),
    Pred =..[Name|Args1],
    Head =..[Name|Args2],
    length(Args1, L),
    length(Args2, L),
    Rule = rule(head(Head), body(B)).


unfold([(Pred, CurrentDepth)|T], [Terms|Terms1], Depth) :-
       CurrentDepth < Depth - 1,
       find_rule(Pred, Rule),
       Pred =.. [_|Args],
       Rule = rule(head(Head), body(Body)),
       Head =.. [_|Vars],
       pair_symbol_vars(Args, Vars, Pairs),
       subst_fresh_vars_conjunct(Pairs, Body, Body1),
       vars_of(Body1, Vars2),
       gen_fresh_symbols(Vars2, Body1, Vars3),
       subst_fresh_vars_conjunct(Vars3, Body1, Body2),
       get_nonterminals(Body2, NonTerminals),
       set_diff(Body2, NonTerminals, Terms),
       (NonTerminals \= [] -> 
              (CurrentDepth1 is CurrentDepth + 1,
              pair_depth(NonTerminals, CurrentDepth1, Continuation),
              append(T, Continuation, T1),
              unfold(T1, Terms1, Depth)) 
                           ;
              unfold(T, Terms1, Depth)).

unfold([(Pred, CurrentDepth)|T], [Terms|Terms1], Depth) :-
           CurrentDepth is Depth - 1,
             find_rule(Pred, Rule),
           Pred =.. [_|Args],
           Rule = rule(head(Head), body(Body)),
           Head =.. [_|Vars],
       pair_symbol_vars(Args, Vars, Pairs),
       subst_fresh_vars_conjunct(Pairs, Body, Body1),
       get_nonterminals(Body1, NonTerminals),
       set_diff(Body1, NonTerminals, Terms),
      (NonTerminals \= [] -> 
              (
              pair_depth(NonTerminals, Depth, Continuation),
              append(T, Continuation, T1),
              unfold(T1, Terms1, Depth)) 
                           ;
              unfold(T, Terms1, Depth)).

unfold([(Pred, Depth)|T], [Terms|Terms1], Depth) :-
      find_rule(Pred, Rule),
       Pred =.. [_|Args],
       Rule = rule(head(Head), body(Body)),
       Head =.. [_|Vars],
       pair_symbol_vars(Args, Vars, Pairs),
       subst_fresh_vars_conjunct(Pairs, Body, Body1),
       nonground_terms(Body1, Nonground),
       set_diff(Body1, Nonground, TermsGround),
       %all_possible_substitutions(Pairs, Nonground, TermsSubstituted),
       purge_vars_with_constants(Nonground, TermsSubstituted),
       append(TermsGround, TermsSubstituted, Terms),
       unfold(T, Terms1, Depth).


term_vars_2(Head, Vars) :-
     Head =..[_|Args],
     filter_vars(Args, Vars).

filter_vars([var(X)|T], [X|R]) :-
        !, 
        filter_vars(T, R).

filter_vars([H|T], R) :-
          H \= var(_),
          !, 
          filter_vars(T, R).

filter_vars([], []).

var_type(Var, [H|_], Domain) :-
        H =.. [Domain, var(Var)], 
        domain(Domain), !.

var_type(Var, [H|T], Domain) :-
        H =.. [D, var(Var)], 
        not(domain(D)), 
        var_type(Var, T, Domain).	

var_type(Var, [H|T], Domain) :-
        H =..[_, var(V)],
        Var \= V,
        var_type(Var, T, Domain).

var_type(Var, [H|T], Domain) :-
        H =.. [_, V],
        V \= var(_),
        var_type(Var, T, Domain).

var_type(Var, [H|T], Domain) :-
        H =.. [_|Args],
        length(Args, L), 
        L > 1,
        var_type(Var, T, Domain).

gen_fresh_symbol(Var, Body, (Var, FreshVar)) :-
         var_type(Var, Body, Domain),
         generate_symbol(Domain, FreshVar).

gen_fresh_symbols([H|T], Body, [Tuple|R]) :- 
         gen_fresh_symbol(H, Body, Tuple),
         gen_fresh_symbols(T, Body, R).

gen_fresh_symbols([], _, []).


substitute_fresh_var((Old, New), Term, Term2) :-
		Term =.. [Name|Args],		
        replace(var(Old), New, Args, Args1),
        Term2 =.. [Name|Args1].

substitute_fresh_vars([H|T], Term, Term2) :-
        substitute_fresh_var(H, Term, Term1),
        substitute_fresh_vars(T, Term1, Term2).

substitute_fresh_vars([], Term, Term).
    
	
subst_fresh_vars_conjunct(Vars, [H|T], [H1|R]) :-
         substitute_fresh_vars(Vars, H, H1),
         subst_fresh_vars_conjunct(Vars, T, R).

subst_fresh_vars_conjunct(_, [], []).


get_nonterminals([H|T], [H|R]) :-
      H =..[Name|Args],
      %length(Args, L),
      %nonterminal(Name, L), !,
      nonterminal(Name), 
      get_nonterminals(T, R).

get_nonterminals([H|T], R) :-
      H =..[Name|Args],
      %length([Name|Args], L),
      %not(nonterminal(Name, L)), !, 
      not(nonterminal(Name)),
      get_nonterminals(T, R).

get_nonterminals([], []).


pair_symbol_vars([H|T], [var(X)|T1], [(X,H)|R]) :-
          pair_symbol_vars(T, T1, R).

pair_symbol_vars([_|T], [H1|T1], R) :-
         H1 \= var(_),
         pair_symbol_vars(T, T1, R).

pair_symbol_vars([], [], []).


has_substitutable_vars([H|_]) :-
         H =.. [Domain, var(_)],
         constants(_, Domain).          

has_substitutable_vars([H|T]) :-
        H =.. [Domain, var(_)],
        not(constants(_, Domain)),
        has_substitutable_vars(T).

has_substitutable_vars([H|T]) :-
        H =.. [_, X],
        X \== var(_),
        has_substitutable_vars(T).

% not doing type inference, assumed that all types are known via domain predicates
has_substitutable_vars([H|T]) :-
        H =.. List,
        length(List, L),
        L > 2,
        has_substitutable_vars(T).



subst_fresh_symbol_conjunct(Symbol, Var, [H|T], [H1|R]) :-
          substitute_fresh_var((Var, Symbol), H, H1),
          subst_fresh_symbol_conjunct(Symbol, Var, T, R).

subst_fresh_symbol_conjunct(_, _, [], []).


purge_vars_with_constants(Conjunct, Conjunct) :- 
          not(has_substitutable_vars(Conjunct)).


purge_vars_with_constants(Conjunct, Conjunct2) :-
         has_substitutable_vars(Conjunct),
         subst_constants(Conjunct, Conjunct1),
         purge_vars_with_constants(Conjunct1, Conjunct2).



%subst_constants(Conjunct, Conjunct1) :-
%        maplist(term_vars_2, Conjunct, Vars),
%        flatten(Vars, Vars1),
%        remove_duplicates(Vars1, Vars2),
%        member(V, Vars2),
%        var_type(V, Conjunct, Domain),
%        constants(C, Domain),
%         subst_fresh_symbol_conjunct(C, V, Conjunct, Conjunct1).

subst_constants(Conjunct, Conjunct1) :-
        maplist(term_vars_2, Conjunct, Vars),
        flatten(Vars, Vars1),
        remove_duplicates(Vars1, Vars2),
        member(V, Vars2),
        var_type(V, Conjunct, node),
        terminal_node_symbol(C),
        subst_fresh_symbol_conjunct(C, V, Conjunct, Conjunct1).

subst_constants(Conjunct, Conjunct) :-
        maplist(term_vars_2, Conjunct, Vars),
        flatten(Vars, Vars1),
        remove_duplicates(Vars1, Vars2),
        member(V, Vars2),
        var_type(V, Conjunct, Domain),
        Domain \== node.
        % terminal_node_symbol(C),
        % subst_fresh_symbol_conjunct(C, V, Conjunct, Conjunct1).



pair_depth([H|T], Depth, [(H,Depth)|R]) :- 
         pair_depth(T, Depth, R).

pair_depth([], _, []).



all_possible_substitutions(_, NonTerminals, Terms) :-
        purge_vars_with_constants(NonTerminals, Terms).

all_possible_substitutions([H|T], NonTerminals, Terms) :-
      H = (A, B),
      subst_fresh_symbol_conjunct(B, A, NonTerminals, Terms1),
      all_possible_substitutions(T, Terms1, Terms).

all_possible_substitutions([_|T], NonTerminals, Terms) :-
            all_possible_substitutions(T, NonTerminals, Terms).


all_possible_substitutions([], _, []).


vars_of(Conjunct, Vars2) :-
     maplist(term_vars_2, Conjunct, Vars), !, 
     flatten(Vars, Vars1),
     remove_duplicates(Vars1, Vars2).
     
nonground_terms([H|T], [H|R]) :-
      H =.. [_|Args],
      member(var(_), Args),
      nonground_terms(T, R).

nonground_terms([H|T], R) :-
      H =.. [_|Args],
      not(member(var(_), Args)),
      nonground_terms(T, R).


nonground_terms([], []).


prepare_conjunct(Conjunct, Str4) :-
        % conjunct_str(Conjunct, BodyStr),
        maplist(domain_info, Conjunct, Doms),
        flatten(Doms, Doms1),
        remove_duplicates(Doms1, Doms2),
        maplist(format_conjunct_term, Doms2, DomsFmt),
        list_str(DomsFmt, DomsStr),
        lint_string(DomsStr, DomsStr1),
        maplist(format_conjunct_term, Conjunct, BodyStr), !,
        list_str(BodyStr, BodyStr1),
        string_concat(DomsStr1, ", ", DomsStr2),
        string_concat(DomsStr2, BodyStr1, BodyStr2),
        string_concat('condition :- ', BodyStr2, Str),
        string_concat(Str, '.\n', Str2),
        string_concat(Str2, '\n:- not condition.\n', Str3),
        lint_string(Str3, Str4).

prepare_terms([H|T], Str2) :-
       % format_conjunct_term(H, S1),
       term_string(H, S1),
       string_concat(S1, '.\n', S2),
       prepare_terms(T, S3),
       string_concat(S2, S3, Str),
       lint_string(Str, Str2).

prepare_terms([], '').  

test([node(x), node(y), reachable(x), edge(x, y), suffix(y), num(kx), num(ky), key(x, kx), key(y, ky), node(target), num(ktarget), key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky), not(reachable(target))]).
test2([node(x), node(y), reachable(x), edge(x, target), edge(target, y), suffix(y), num(kx), num(ky), key(x, kx), key(y, ky), node(target), num(ktarget), key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)]).
get_terminals(List, Terminals) :- 
       get_nonterminals(List, NonTerminals),
       set_diff(List, NonTerminals, Terminals).
gen_falsify_pred(Pred, R) :- 
      signature(Pred, _, Domains),
      maplist(generate_symbol, Domains, Symbols),
      term_string(Pred, Predstr),
      string_concat(Predstr, "_falsify", Headstr),
      term_string(Headname, Headstr),
      Positive =.. [Pred|Symbols],
      last_element(Symbols, Time),
      generate_symbol(time, NextTime),
      replace(Time, NextTime, Symbols, Symbols1),
      Positive1 =.. [Pred|Symbols1],
      Naf =.. [not, Positive1],
      Body = [Positive, next_time(Time, NextTime), Naf],
      R = rule(head(Headname), body(Body)).


 gen_falsify_theory(Rules) :-
       findall(X, time_dependent(X, _), Preds),
       maplist(gen_falsify_pred, Preds, Rules).


check_falsify(Pred, Success) :-
      reset_counts, 
      max_depth(Length),
      time_chain(Length, Chain),
      gen_falsify_pred(Pred, Rule),
      gen_interference_theory(T),
      Rule = rule(head(Rulename), _),
      append(T, [Rule, constraint([not(Rulename)])], F),
      append(F, Chain, F1),
      write_rules(F1, S),
      rules_str(S, S1),
      string_concat('falsify_', Pred, CheckFalsify),
      add_to_base_theory(CheckFalsify, S1),
      solve_models(CheckFalsify, one, Models),
      (Models \= [] -> Success = true ; Success = false).


check_falsify_2(Pred, Op, Block, Success) :-
     reset_counts, 
     time_chain(2, Chain),
      gen_falsify_pred(Pred, Rule),
      gen_interference_rules_positive(Op, Block, T),
      Rule = rule(head(Rulename), _),
      append(T, [Rule, constraint([not(Rulename)])], F),
      append(F, Chain, F1),
      write_rules(F1, S),
      rules_str(S, S1),
      string_concat('falsify_', Pred, CheckFalsify),
      add_to_base_theory(CheckFalsify, S1),
      solve_models(CheckFalsify, one, Models),
      (Models \= [] -> Success = true ; Success = false).


format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. ['..', X, Y], !,
      capitalize(X, X1),
      capitalize(Y, Y1),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " .. ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [Relop, X, Y], 
      relop(Relop), !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      (Relop \= '!=' -> term_string(Relop, RelString)
                ;   RelString = ' != '),
      string_concat(X1s, RelString, X1s1),
      string_concat(X1s1, Y1s, Formatted).


%format_conjunct_term_alt(Term, Formatted) :- 
%      Term =.. [+, X, Y], !,
%      capitalize(X, X1),
%      capitalize(Y, Y1),
%      term_string(X1, X1s),
%      term_string(Y1, Y1s),
%      string_concat(X1s, " + ", X1s1),
%      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term_alt(constant(Symbol), Symbol).

format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [\=, X, Y], !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " != ", X1s1),
      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [=, X, Y], !,
       (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
        format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " = ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [not, Term2],
       format_conjunct_term_alt(Term2, Format2),
       string_concat('not ', Format2, Formatted).

format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [Name|Args],
       Name \== not,
       maplist(capitalize, Args, Caps),
       list_str(Caps, ArgsStr),
       term_string(Name, NameStr),
       string_concat(NameStr, '(',  S1),
       string_concat(S1, ArgsStr, S2),
       string_concat(S2, ')', Formatted).

format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [Name],
       term_string(Name, Formatted).
% :- module(format_terms, []).

time_dependent2(Name) :-
      signature(Name, _, Domains),
      member(time, Domains).

add_time_list(TimeSymbol, [H|T], [not(Term2)|R]) :-
       H = (not(Term)),
       Term =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [TimeSymbol], List2),
       Term2 =.. List2,
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [Term|R]) :-
       H \= (not(_)),
       H =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [TimeSymbol], List2),
       Term =.. List2,
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [H|R]) :-
       H = (not(Term)),
       Term =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [H|R]) :-
       H \= (not(_)),
       H =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list(TimeSymbol, T, R).


add_time_list(_, [], []).



add_time_list_constant(TimeSymbol, [H|T], [not(Term2)|R]) :-
       H = (not(Term)),
       Term =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [constant(TimeSymbol)], List2),
       Term2 =.. List2,
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [Term|R]) :-
       H \= (not(_)),
       H =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [constant(TimeSymbol)], List2),
       Term =.. List2,
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [H|R]) :-
       H = (not(Term)),
       Term =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [H|R]) :-
       H \= (not(_)),
       H =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list_constant(TimeSymbol, T, R).


add_time_list_constant(_, [], []).



add_time(Term, Term2) :-
    lint_negation(Term, Term1),
    Term1 =.. [Name|_],
    time_dependent2(Name),
    Term1 =.. List,
    generate_symbol(time, Symbol),
    append(List,[Symbol], List2),
    Term2 =.. List2.

add_time(Term, Term) :-
    lint_negation(Term, Term1),
    Term1 =.. [Name|_],
    not(time_dependent2(Name)).


add_time_unconditional(TimeSymbol, Term, Term2) :-
          lint_negation(Term, Term1),
          Term1 =.. List,
          append(List, [TimeSymbol], List2),
          Term2 =.. List2.
 
add_time_unconditional_constant(TimeSymbol, Term, Term2) :-
          lint_negation(Term, Term1),
          Term1 =.. List,
          append(List, [constant(TimeSymbol)], List2),
          Term2 =.. List2.


map_vars_domain([H|T], [D|Tail], [Term|R]) :- 
         Term =.. [D,H],
         map_vars_domain(T, Tail, R).

map_vars_domain([], _, []).

term_domainvars(Term, DomainVars) :-
      lint_negation(Term, Term1),
      Term1 =.. [_|Vars],
      get_domains(Term1, Domains),
      map_vars_domain(Vars, Domains, DomainVars).

map_vars_domain([H|T], [D|Tail], [Term|R]) :- 
         [H|T] \= [],
         Term =.. [D,H], 
         map_vars_domain(T, Tail, R), !.

map_vars_domain([], _, []).

tuple_1([(H,_)|T], [H|R]) :-
               tuple_1(T, R).
tuple_1([], []).

term_vars(Term, Vars) :-
       lint_negation(Term, Term2),
       Term2 =.. [_|Vars].

conjunct_vars(List, Vars) :-
    maplist(term_vars, List, VarsMap),
    flatten(VarsMap, Flattened),
    remove_duplicates(Flattened, Vars).

neg_term(Term, NegTerm) :-
      term_string(Term, String),
      string_concat('neg_',String, NegString),
      term_string(NegTerm, NegString).

conjunct_domainvars(List, DomainVars) :-
     maplist(term_domainvars, List, DomainVarsMap),
     flatten(DomainVarsMap, Flattened),
     remove_duplicates(Flattened, DomainVars).


lint_negation(Term, Term2) :-
      Term =.. [not, Term2], !.

lint_negation(Term, Term).


time_var(Term1, Var) :-
      Term1 =.. List,
      last_element(List, Var).

copy_timevar(Term1, Term2, Term3) :-
       time_var(Term1, Var),
       append_var(Var, Term2, Term3).

last_element(List, X) :-
      append(_, [X], List).

append_var(Var, Term, Term1) :-
        Term =.. List,
        append(List, [Var], List1),
        Term1 =.. List1.


get_domains(Term, Domains) :-
      Term =.. [Name|_],
      signature(Name, _, Domains).

domain_variant(Domain, Variant) :-
       Domain =.. [Name,_],
       generate_symbol(Name, Symbol),
       Variant =.. [Name,Symbol].


var_domain(Domain, Var) :-
        Domain =.. [_,Var].

rename_vars(Term, Domains, Term2) :-
    Term =.. [Name|_],
    maplist(var_domain, Domains, List),
    Term2 =.. [Name|List].

% Term2 borrows the same timestep from Term1
same_timevar(Term1, Term2, Term3) :-
      Term1 =.. List,
      last_element(List, TimeVar),
      Term2 =.. List2,
      append(List3, [_], List2),
      append(List3, [TimeVar], List4),
      Term3 =.. List4.


domain_term_of(Var, [H|_], H) :-
      H =.. [_, Var].

domain_term_of(Var, [H|T], Term) :-
      H =.. [_, V],
      Var \== V,
      domain_term_of(Var, T, Term).

domain_of(Var, [H|_], Domain) :-
        H =.. [Domain, Var].

domain_of(Var, [H|T], Domain) :-
        H =.. [_,V],
        V \== Var,
        domain_of(Var, T, Domain).


common_vars(Term1, Term2, Common) :-
        Term1 =.. [_|Vars1],
        Term2 =.. [_|Vars2],
        set_intersect(Vars1, Vars2, Common).

relop(>).
relop(<).
relop(>=).
relop(<=).
relop('!=').
relop('..').
relop(+).
relop(..).
relop(-).

reduce([], string_concat, _, '').

format_conjunct_term(Term, Formatted) :- 
      Term =.. ['..', X, Y], !,
      capitalize(X, X1),
      capitalize(Y, Y1),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " .. ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term(Term, Formatted) :- 
      Term =.. [Relop, X, Y], 
      relop(Relop), !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      term_string(Relop, RelString),
      string_concat(X1s, RelString, X1s1),
      string_concat(X1s1, Y1s, Formatted).


%format_conjunct_term(Term, Formatted) :- 
%      Term =.. [+, X, Y], !,
%      capitalize(X, X1),
%      capitalize(Y, Y1),
%      term_string(X1, X1s),
%      term_string(Y1, Y1s),
%      string_concat(X1s, " + ", X1s1),
%      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term(constant(Symbol), Symbol).

format_conjunct_term(Term, Formatted) :- 
      Term =.. [\=, X, Y], !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " != ", X1s1),
      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term(Term, Formatted) :- 
      Term =.. [=, X, Y], !,
       (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
        format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " = ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


drop_last_tactic_helper(Term, Term2) :-
        Term =.. [Name|Args],
        append(Prefix, [X], Args),
        Term2 =.. [Name|Prefix].

drop_last_tactic(Literals, Literals1) :-
       maplist(drop_last_tactic_helper, Literals, Literals1).


get_types([H|T], Literals, [Term|R]) :-
        type_of(H, Literals, Type),
        Term =.. [Type, H], !,
        get_types(T, Literals, R).

get_types([H|T], Literals, [Term|R]) :-
        not(type_of(H, Literals, Type)),
        drop_last_tactic(Literals, Literals1),
        type_of(H, Literals1, Type),
        Term =.. [Type, H], !,
        get_types(T, Literals, R).

get_types([H|T], Literals, R) :-
      !, get_types(T, Literals, R). 

get_types([], _, []).

capitalize_special(Term, String) :-
       Term =.. [Type, Arg],
       capitalize(Arg, S),
       term_string(Type, TypeS),
       string_concat(TypeS, '(', S1),
       string_concat(S1, S, S2),
       string_concat(S2, ")", String).

pair_doms([H|T], [Type|T1], [Term|R]) :-
          Term =.. [Type, H],
          pair_doms(T, T1, R).

pair_doms([], [], []).

add_comma(Str, Str1) :-
       string_concat(Str, ",", Str1).


format_conjunct_term(Term, Formatted) :-
       Term =.. [not, Term2],
       Term2 =..[_|Args],
       get_types(Args, [Term2], Doms),
       %pair_doms(Args, Types, Doms),
       maplist(capitalize_special, Doms, Doms1),
       maplist(add_comma, Doms1, Doms2),
       reduce(Doms2, string_concat, ",", Doms3),
       format_conjunct_term(Term2, Format2),
       string_concat('not ', Format2, Format3),
       string_concat(Doms3, Format3, Formatted).

format_conjunct_term(Term, Formatted) :-
       Term =.. [Name|Args],
       Name \== not,
       maplist(capitalize, Args, Caps),
       list_str(Caps, ArgsStr),
       term_string(Name, NameStr),
       string_concat(NameStr, '(',  S1),
       string_concat(S1, ArgsStr, S2),
       string_concat(S2, ')', Formatted).

format_conjunct_term(Term, Formatted) :-
       Term =.. [Name],
       term_string(Name, Formatted).


capitalize(typenum(Symbol), Symbol).
capitalize(constant(Symbol), Symbol).
capitalize('..'(X,Y), Str) :-
       term_string(X, Xs),
       term_string(Y, Ys),
       string_concat(Xs, '..', Xs1),
       string_concat(Xs1, Ys, Str).

capitalize(Symbol, Str) :-
       constants(Symbol, _),
       term_string(Symbol, Str).

capitalize(Symbol, Caps) :-
       not(constants(Symbol, _)),
       not(number(Symbol)),
       term_string(Symbol, Str),
       string_chars(Str, [H|T]),
       char_code(H, Code),
       CapsCode is Code - 32,
       char_code(H1, CapsCode),
       string_chars(Caps, [H1|T]).

capitalize(Symbol, SymbolString) :-
       not(constants(Symbol, _)),
       number(Symbol),
       term_string(Symbol, SymbolString).
       


dom_of(Arg, Body, Domain) :-
       is_var(Arg, Body),
       domain_of(var(Arg), Body, Domain).


dom_of(Arg, Body, Domain) :-
      not(is_var(Arg, Body)),
      constants(Arg, Domain).


is_var(Arg, [Term|_]) :-
         Term =.. [_, var(Arg)].

is_var(Arg, [X|T]) :-
      X =.. [_|Args],
      length(Args, L), 
      L > 1,
      is_var(Arg, T).

is_var(Arg, [X|T]) :- 
      X =.. [_, A],
      A \= Arg,
      A \= var(Arg),
      is_var(Arg, T).


to_var(Term, Term1) :-
      Term \= not(_),
      Term =.. [Name|Args],
      maplist(to_var_helper, Args, Args1),
      Term1 =.. [Name|Args1].

to_var(Term, not(Term2)) :-
      Term = not(Term1),
      Term1 =.. [Name|Args],
      maplist(to_var_helper, Args, Args1),
      Term2 =.. [Name|Args1].
            
to_var_helper(X, var(X)) :-
          not(constants(X, _)).
to_var_helper(X, X) :-
         constants(X, _).

append_definitions_to_theory(Definitions) :-
		 shell('cat empty > theory_appended.lp', _),
         % shell('cp theory_eq.lp theory_appended.lp', _),
         shell('cp tree.lp theory_appended.lp', _),
         open('theory_appended.lp', append, Stream),
         current_output(Out),
         set_output(Stream),
         append_helper(Definitions),
         set_output(Out),
         close(Stream).

append_helper([H|T]) :-
        write(H),
        append_helper(T).

append_helper([]).


write_rule(Rule, Str2) :-
   Rule = rule(head(Head), body(Body)),
   format_conjunct_term(Head, Headfmt),
   maplist(format_conjunct_term, Body, Bodyfmt),
   term_string(Headfmt, Headstr),
   conjunct_str(Bodyfmt, Bodystr), 
   (Body \= [] ->  string_concat(Headstr, " :- ", Head1) ; 
                   Head1 = Headstr
   ),
   string_concat(Bodystr, ".\n", Body1),
   string_concat(Head1, Body1, Str),
   lint_string(Str, Str2).
   %write(Str2).


write_rule(Rule, Str2) :-
   Rule = constraint(Body),
   maplist(format_conjunct_term, Body, Bodyfmt),
   conjunct_str(Bodyfmt, Bodystr),
   string_concat(":- ", Bodystr, Bodystr1),
   string_concat(Bodystr1, ".\n", Str),
   lint_string(Str, Str2).
   %write(Str2).


write_rule_alt(Rule, Str2) :-
   Rule = rule(head(Head), body(Body)),
   format_conjunct_term_alt(Head, Headfmt),
   maplist(format_conjunct_term_alt, Body, Bodyfmt),
   term_string(Headfmt, Headstr),
   conjunct_str(Bodyfmt, Bodystr), 
   (Body \= [] ->  string_concat(Headstr, " :- ", Head1) ; 
                   Head1 = Headstr
   ),
   string_concat(Bodystr, ".\n", Body1),
   string_concat(Head1, Body1, Str),
   lint_string(Str, Str2).
   %write(Str2).


write_rule_alt(Rule, Str2) :-
   Rule = constraint(Body),
   maplist(format_conjunct_term_alt, Body, Bodyfmt),
   conjunct_str(Bodyfmt, Bodystr),
   string_concat(":- ", Bodystr, Bodystr1),
   string_concat(Bodystr1, ".\n", Str),
   lint_string(Str, Str2).
   %write(Str2).




write_rules([H|T], [S|S1]) :-
    write_rule(H, S), !, 
    write_rules(T, S1).

write_rules([], []) :- !.


write_rules_alt([H|T], [S|S1]) :-
    write_rule_alt(H, S), !, 
    write_rules_alt(T, S1).

write_rules_alt([], []) :- !.


reasoning_path('./reasoning_files/').
% input_path('./input/').


% reasoning_path('').
% input_path('').


add_to_base_theory(Extension, Rules) :-
         ds(DS),
         class(DS, X),
         facts_rules(X, R),
         write_rules(R, R1),
         rules_str(R1, Rs),
         string_concat(Rules, Rs, Rs1),
         %term_string(DS, DS1),
         input_path(InputPath),
         reasoning_path(ReasoningPath),
         %string_concat(DS1, '.lp ', DSFile),
         %string_concat(InputPath, DSFile, DSPath),
         %DSPath = './reasoning_files/base_theory.lp',
         string_concat(ReasoningPath, "base_theory.lp", DSPath),
         string_concat(ReasoningPath, Extension, ExtensionPath),
         copy_command(DSPath, ExtensionPath, Cmd),
         shell(Cmd, _),
         open(ExtensionPath, append, Stream),
         current_output(Out),
         set_output(Stream),
         write(Rs1),
         set_output(Out),
         close(Stream).


facts_rules(List, Rules) :- 
      maplist(fact_rule, List, Rules).


symbol_constant(X, constant(X)).

fact_rule(Term, Rule) :-
      Term =.. [Name|Args],
      maplist(symbol_constant, Args, Args1),
      Term1 =.. [Name| Args1],
      Rule = rule(head(Term1), body([])).

      operation(inst_nurmi, add).
operation(inst_nurmi, remove).
operation(inst_nurmi, blacking).
operation(inst_nurmi, single_rotation).
operation(inst_nurmi, double_rotation).
operation(inst_nurmi, reduce_weight).
operation(inst_nurmi, rotate_and_reduce_weight).


write_operation(inst_nurmi, add,_).
write_operation(inst_nurmi, remove,_).
write_operation(inst_nurmi, blacking,_).
write_operation(inst_nurmi, single_rotation,_).
write_operation(inst_nurmi, double_rotation,_).
write_operation(inst_nurmi, reduce_weight,_).
write_operation(inst_nurmi, rotate_and_reduce_weight,_).


causes(inst_nurmi, weight_left(x,w), change_weight_left(x,w)).
causes(inst_nurmi, weight_right(x,w),change_weight_right(x,w)).
causes(inst_nurmi, left(x,y), link_left(x,y)).
causes(inst_nurmi, right(x,y), link_right(x,y)).

primitive_write_operation(inst_nurmi, link_left).
primitive_write_operation(inst_nurmi, link_right).
primitive_write_operation(inst_nurmi, change_weight_left).
primitive_write_operation(inst_nurmi, change_weight_right).

modifies(inst_nurmi, x, link_left(x,y)).
modifies(inst_nurmi, x, link_right(x,y)).
modifies(inst_nurmi, x, change_weight_left(x,w)).
modifies(inst_nurmi, x, change_weight_right(x,w)).


pre(inst_nurmi, blacking, onlycase, 
	[
	 reachable(p), left(p, c), 
     weight_left(p, w), int_gt(w, 0), weight_left(c, 0), weight_right(c, 0), sum(w, -1, w1) 
	]).

program_steps(inst_nurmi, blacking, onlycase, [
     change_weight_left(c, 1),
     change_weight_right(c, 1),
     change_weight(p, w1)
	]).

pre(inst_nurmi, single_rotation, case1, [
     reachable(p), left(p, v),
     left(v, u), left(u, a), right(u, b), right(v, c),
     weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w, 1)
	]).

program_steps(inst_nurmi, single_rotation, case1, [
       link_right(u, v),
       link_left(v, b),
       link_left(p, v)
	]).

pre(inst_nurmi, double_rotation, case1, [
      reachable(p), left(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul, 1), weight_left(tee , wtl), int_gte(wtl, 1),
      weight_right(tee, wtr), int_gte(wtr, 1) 

	]).

program_steps(inst_nurmi, double_rotation, case1, [
      link_left(t, u),
      link_right(u, b),
      link_right(t, v),
      link_left(v, c), 
      link_left(p, t)
	]).


pre(inst_nurmi, reduce_weight, case1, [
        reachable(p), left(p, v),
        weight_left(p, wpl), weight_left(v, wvl), weight_right(v, wvr),
        int_gte(wpl, 1), int_gt(wvl, 1), int_gt(wvr, 1),
        sum(wpl, 1, wpl1), sum(wvl, -1, wvl1), sum(wvr, -1, wvr1)
	]).

program_steps(inst_nurmi, reduce_weight, case1, [
      change_weight_left(p, wpl1),
      change_weight_left(v, wvl1),
      change_weight_rigth(v, wvr1)
	]).


pre(inst_nurmi, rotate_and_reduce_weight, case1, 
	[
       reachable(p), left(p, u), 
       left(u, a), right(u, v), left(v, b), right(v, c),
       weight_left(u, w1), int_gt(w1, 1), weight_right(u, 0), 
       weight_left(v, w2), int_gte(w2, 1), 
       weight_right(v, w3), int_gte(w3, 1),
       sum(w1, -1, w11), sum(w2, -1, w21)
	]).

program_steps(inst_nurmi, rotate_and_reduce_weight, case1, [
       link_left(v, u),
       link_right(u, b),
       change_weight_left(v, 1),
       change_weight_left(u, w11),
       change_weight_right(u, w21),
       link_left(p, v)
	]).



class(inst_nurmi, [node(node7),
key(node7,knode7),
num(knode7),
lt(knode7,knode3),
node(node3),
key(node3,knode3),
num(knode3),
lt(knode3,knode8),
node(node8),
key(node8,knode8),
num(knode8),
lt(knode8,knode1),
node(node1),
key(node1,knode1),
num(knode1),
lt(knode1,knode12),
node(node12),
key(node12,knode12),
num(knode12),
lt(knode12,knode4),
node(node4),
key(node4,knode4),
num(knode4),
lt(knode4,kroot),
node(root),
key(root,kroot),
num(kroot),
lt(kroot,knode5),
node(node5),
key(node5,knode5),
num(knode5),
lt(knode5,knode2),
node(node2),
key(node2,knode2),
num(knode2),
lt(knode2,knode6),
node(node6),
key(node6,knode6),
num(knode6),
root(root),
root(root),
left(root,node1),
right(root,node2),
weight_left(root,7),
weight_right(root,2),
left(node1,node3),
right(node1,node4),
weight_left(node1,0),
weight_right(node1,0),
left(node2,node5),
right(node2,node6),
weight_left(node2,8),
weight_right(node2,7),
left(node3,node7),
right(node3,node8),
weight_left(node3,-3),
weight_right(node3,-3),
left(node4,node12),
weight_left(node4,7)
]).


code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). 
gen_interference_rules_positive(Op, Block, Rules) :- 
       ds(DS),
       code(DS, Op, _, Block, Pre, Steps, _),
       gen_interference_predicate_positive_head(Op, Block, Pre, Steps, Pred), !, 
       get_locked_nodes(Op, Block, Nodes), 
       lock_window_term(Nodes, LockTerms),
       gen_interference_effect(Op, LockTerms, Pred, Steps, Effects), !, 
       rewrite_primitives(Rewrites), !,
       append(Rewrites, Pred, Rules1),
       append(Rules1, Effects, Rules).


gen_interference_predicate_positive_head(Operation, Block, Pre, _, Predicate) :-
     term_string(Operation, Op),
     term_string(Block, Bl),
     string_concat(Op, Bl, OpBlock),
     string_concat('interfere_', OpBlock, InterfereString),
     term_string(Interfere, InterfereString),
     conjunct_vars(Pre, Vars),
     initial_time_symbol(TimeSymbol),
     append(Vars, [constant(TimeSymbol)], HeadVars),
     Head =.. [Interfere|HeadVars],
     %conjunct_domainvars(Pre, DomainVars),
     %add_time_list_constant(TimeSymbol, Pre, Body),
     %append([time(constant(TimeSymbol))], Body, Body1),
     %append(DomainVars, Body1, Body2),
     Predicate = [rule(head(Head),body(Pre))].


lock_term(Step, [node(Mem),not(locked(Mem))]) :-
       ds(DS),
       Step =..[Name|Args],
       length(Args, L),
       primitive_write_step(DS, Name),
       length(Args2, L),
       Step2 =.. [Name|Args2],
       modifies(DS, X, Step2),
       add_dummy(Args2, Args3),
       index_of(X, Args3, Index),
       element_at_index(Index, Args, Mem).

get_locked_nodes(Op, Block, Nodes) :-
          default_window(Op, Block, Rules),
          get_locked_nodes_helper(Rules, Nodes).

get_locked_nodes_helper([H|T], [X|R]) :-
       H = rule(head(locked(X)),_),
       get_locked_nodes_helper(T, R).

get_locked_nodes_helper([], []).

lock_window_term([H|T], [node(H), not(locked(H)) | R]) :-
         lock_window_term(T, R).

lock_window_term([], []). 


add_dummy([H|T], [dummy|R]) :-
      var(H), !,
      add_dummy(T, R).

add_dummy([H|T], [H|R]) :-
      nonvar(H), !,
      add_dummy(T, R).

add_dummy([], []).

gen_interference_theory(Flattened) :-
        ds(DS),
        findall(Op, write_operation(DS,Op,_), Ops),
        maplist(gen_interference_rule_op, Ops, InterferenceTheory), !,
        flatten(InterferenceTheory, InterferenceTheory1),
        rewrite_primitives(Rewrites),
        append(InterferenceTheory1, Rewrites, Append),
        gen_constraints(Constraints),
        append(Append, Constraints, Append2),
        flatten(Append2, Flattened),
        write_to_file('Interference', Flattened).
 

gen_interference_rule_op(Op, Rules) :-
       ds(DS),
       findall(Block, code(DS, Op, _, Block, _, _, _), List), 
       gen_interference_rule_blocks(Op, List, Rules).


gen_interference_rule_blocks(Op, [Block|T], [Rule|Rules]) :-
         gen_interference_rule(Op, Block, Rule),
         gen_interference_rule_blocks(Op, T, Rules).

gen_interference_rule_blocks(_, [], []).

gen_interference_rule(Op, Block, Rule) :-
        ds(DS),
        code(DS, Op, _, Block, Pre, Steps, _),
        gen_interference_predicate(Op, Block, Pre, Predicate),
        gen_interference_effect(Op, Predicate, Steps, Effects),
        Rule = [Predicate, Effects].

op_blocks(OpBlocks2) :-
     ds(DS),
     findall(Op, code(DS, Op, _, _, _, _, _),Ops),
     blocks(Ops, OpBlocks),
     remove_duplicates(OpBlocks, OpBlocks1),
     flatten(OpBlocks1, OpBlocks2).

blocks([Op|T], [OpBlocks|R]) :-
    ds(DS),
    findall(Block, code(DS, Op, _, Block, _, _, _), Blocks),
    zip(Op, Blocks, OpBlocks),    
    blocks(T, R).

blocks([], []).
get_interference_heads(Heads) :-
          op_blocks(OpBlocks),
          get_interference_heads_helper(OpBlocks, Heads).

get_interference_heads_helper([(Op,Block)|T], [(Head,Domains)|R]) :-
           ds(DS),
           code(DS,Op, _, Block, Pre, _, _),
           get_interference_head_and_domains(Op, Block, Pre, Head, Domains), !,
           get_interference_heads_helper(T, R).

get_interference_heads_helper([], []).


get_interference_head_and_domains(Operation, Block, Pre, Head, DomainVars) :-
     term_string(Operation, Op),
     term_string(Block, Bl),
     string_concat(Op, Bl, OpBlock),
     string_concat('interfere_', OpBlock, InterfereString),
     term_string(Interfere, InterfereString),
     conjunct_vars(Pre, Vars),
     %generate_symbol(time, TimeSymbol),
     %append(Vars, [TimeSymbol], HeadVars),
     Head =.. [Interfere|Vars],
     conjunct_domainvars(Pre, DomainVars).

gen_interference_predicate(Operation, Block, Pre, Predicate) :-
     term_string(Operation, Op),
     term_string(Block, Bl),
     string_concat(Op, Bl, OpBlock),
     string_concat('interfere_', OpBlock, InterfereString),
     term_string(Interfere, InterfereString),
     conjunct_vars(Pre, Vars),
     generate_symbol(time, TimeSymbol),
     append(Vars, [TimeSymbol], HeadVars),
     Head =.. [Interfere|HeadVars],
     neg_term(Interfere, NegInterfere),
     NegHead =.. [NegInterfere|HeadVars],
     append(Pre, [time(TimeSymbol), not(NegHead)], Body),
     append(Pre, [time(TimeSymbol), not(Head)], NegBody),
     conjunct_domainvars(Pre, DomainVars),
     add_time_list(TimeSymbol, Body, Body1),
     add_time_list(TimeSymbol, NegBody, NegBody1),
     append(DomainVars, Body1, Body2),
     append(DomainVars, NegBody1, NegBody2),
     Predicate = [rule(head(Head),body(Body2)),
                  rule(head(NegHead),body(NegBody2))].

gen_interference_effect(_, LockTerms, Predicate, Steps, Effects) :-
     Predicate = [rule(head(Head),_)|_],
     link_program_steps(Steps, LockTerms, Head, Effects).

link_program_steps([H|T], LockTerms, InterfereHead, [Effect|R]) :-
         rewrite_interference_name(H, H1),
         copy_timevar(InterfereHead, H1, EffectHead),
         %V2: add locked node check against all nodes modified by InterfereHead
         Effect = rule(head(EffectHead), body([InterfereHead|LockTerms])),
         link_program_steps(T, LockTerms, InterfereHead, R).

link_program_steps([], _, _, []).

gen_constraints(Constraints) :-
    get_interference_heads(Heads),
    gen_constraints_between_terms(C1),
    gen_within_terms_rec(Heads, C2),
    append(C1, C2, Constraints).

gen_within_terms_rec([H|T], Constraints) :-
       H = (Head, Domains),
       gen_pairwise_constraints_within_term(Head, Domains, C), 
       gen_within_terms_rec(T, R),
       append(C, R, Constraints).

gen_within_terms_rec([], []).

gen_pairwise_constraints_within_term(InterferenceHead, Domains, Constraints) :-
        maplist(domain_variant, Domains, Variants),
        rename_vars(InterferenceHead, Variants, HeadVariant),
        append(Domains, Variants, L1),
        generate_symbol(time, TimeSymbol),
        add_time_unconditional(TimeSymbol, InterferenceHead, InterferenceHead1),
        add_time_unconditional(TimeSymbol, HeadVariant, HeadVariant1),
        append(L1, [time(TimeSymbol), InterferenceHead1, HeadVariant1], Base),
        gen_constraints_within(Base, Domains, Variants, Constraints).
        

gen_constraints_within(Base, [Term1|T1], [Term2|T2],[Rule|R]) :- 
          Term1 =.. [Domain, Var1],
          Domain \= node, Domain \= num,
          Term2 =.. [_,Var2],
          append(Base, [diff_term(Var1,Var2)], Body),
          Rule = constraint(Body),
          gen_constraints_within(Base, T1, T2, R).

gen_constraints_within(Base, [Term1|T1], [Term2|T2],[Rule|R]) :- 
          Term1 =.. [node, Var1],
          Term2 =.. [_,Var2],
          append(Base, [not_eq_node(Var1,Var2)], Body),
          Rule = constraint(Body),
          gen_constraints_within(Base, T1, T2, R).

gen_constraints_within(Base, [Term1|T1], [Term2|T2],[Rule|R]) :- 
          Term1 =.. [num, Var1],
          Term2 =.. [_,Var2],
          append(Base, [not_eq_num(Var1,Var2)], Body),
          Rule = constraint(Body),
          gen_constraints_within(Base, T1, T2, R).


gen_constraints_within(_, [], [], []).


gen_constraint_between_terms(Head1, Domains1, Head2, Domains2, Rule) :-
    append(Domains1, Domains2, L1),
    generate_symbol(time, TimeSymbol),
    add_time_unconditional(TimeSymbol, Head1, TimeHead1),
    add_time_unconditional(TimeSymbol, Head2, TimeHead2),
    append(L1, [time(TimeSymbol), TimeHead1, TimeHead2], Body),
    Rule = constraint(Body).

gen_constraints_between_terms(Constraints) :-
          get_interference_heads(Heads),
          gen_constraints_between_terms_helper(Heads, Heads, Constraints).

gen_constraints_between_terms_helper([H|T], [H|T], Constraints) :-
           gen_constraints_between_terms_helper([H|T], T, Constraints).

gen_constraints_between_terms_helper([H|T], [H1|T1], [Rule|R]) :-
            H \= H1,
            H = (Head1, Domains1),
            H1 = (Head2, Domains2),
            %same_timevar(Head1, Head2, Head3),
            gen_constraint_between_terms(Head1, Domains1, Head2, Domains2, Rule),
            gen_constraints_between_terms_helper([H|T],T1,R).

gen_constraints_between_terms_helper([_|T], [], Constraints) :-
            gen_constraints_between_terms_helper(T, T, Constraints).

gen_constraints_between_terms_helper([], [], []).

rewrite_interference_name(Term, Term2) :-
            Term =.. [Name|List],
            term_string(Name, NameStr),
            string_concat(NameStr, '_interfere', NameStr2),
            term_string(Name2, NameStr2),
            Term2 =.. [Name2|List].

rewrite_primitives(Rewrites) :-
     ds(DS),
     findall(S, primitive_write_step(DS,S), Primitives),
     rewrite_primitives_helper(Primitives, Rewrites).

rewrite_primitives_helper([H|T], R1) :-
         rewrite_interference_name(H, Hr),
         signature(H, Arity, _),
         %Arity1 is Arity - 1,
         length(Vars, Arity),
         Term =.. [H|Vars],
         ds(DS),
         causes(DS, Effect, Term), % also captures dataflow thanks to prolog unification
         modifies(DS, ModifiedMem, Term),
         generate_symbol(time, TimeSymbol),
         % add_time_unconditional(TimeHead1, Hr, Hr1).
         Term1 =.. [Hr|Vars],
         add_time_unconditional(TimeSymbol, Term1, Term2),
         term_domainvars(Term, DomainVars),
         generate_symbol(time, NextTimeSymbol),
         add_time_unconditional(NextTimeSymbol, Effect, Effect2),
         append(DomainVars, [time(TimeSymbol), time(NextTimeSymbol), next_time(TimeSymbol, NextTimeSymbol), Term2, not(locked(ModifiedMem))], Body),
         Rewrite = rule(head(Effect2),body(Body)),
         gen_causal_rule(H, Hr, CausalRule),
         append([Rewrite, CausalRule], R, R1), !,
         rewrite_primitives_helper(T, R).

gen_causal_rule(H, Hr, Causal) :-
       signature(H, Arity, _),
       %Arity1 is Arity - 1,
       length(Vars, Arity),
       Term =.. [H|Vars],
       ds(DS),
       modifies(DS, Memory, Term),
       term_domainvars(Term, DomainVars),
       generate_symbol(time, TimeSymbol),
       append(Vars, [TimeSymbol], Vars1),
       Term1 =.. [Hr|Vars1],
       causal_head_name(Term, Name),
       append(DomainVars, [time(TimeSymbol), Term1, not(locked(Memory))], CausalBody),
       Head =.. [Name, Memory, TimeSymbol],
       Causal = rule(head(Head), body(CausalBody)).


causal_head_name(Term, Name) :-
        ds(DS),
        causes(DS, Term2, Term),
        Term2 =.. [Property|_],
        term_string(Property, Ps),
        string_concat('modifies_', Ps, NameString),
        term_string(Name, NameString).

rewrite_primitives_helper([], []).

default_window(Operation, Block, Rules) :- 
       ds(DS),
       code(DS, Operation, _, Block, Precondition, _, _),
       get_nodes(Precondition, Nodes),
       gen_lock_rules(Nodes, Precondition, Rules).


get_nodes(Precondition, Nodes2) :-
        maplist(get_nodes_helper, Precondition, Nodes),
        flatten(Nodes, Nodes1),
        remove_duplicates(Nodes1, Nodes2).

get_nodes_helper(Predicate, Nodes) :-
         lint_negation(Predicate, Linted),
         %signature(Linted, Domains),
         Linted =.. [_|Args],
         get_types(Args, [Linted], Doms),
         filter_nodes(Doms, Nodes).
         %pick_domain_vars(node, Args, Domains, Nodes).

filter_nodes([node(X)|T], [X|R]) :-
       !, filter_nodes(T, R).

filter_nodes([X|T], R) :-
         X \= node(_), !, 
         filter_nodes(T, R).

filter_nodes([], []).

pick_domain_vars(Domain, [H|T], [Domain|D], [H|R]) :-
            pick_domain_vars(Domain, T, D, R), !.

pick_domain_vars(Domain, [_|T], [Domain1|D], R) :-
            Domain \== Domain1, !, 
            pick_domain_vars(Domain, T, D, R).

pick_domain_vars(_, [], [], []).


gen_lock_rules([H|T], Precondition, [Rule|R]) :-
        % maplist(to_var, Precondition, PreFormatted),
        add_time_list_constant(t1, Precondition, Precondition1), 
        Rule = rule(head(locked(H)),body(Precondition1)),
        gen_lock_rules(T, Precondition, R).

gen_lock_rules([], _, []).

%check_adequacy(Operation, Block, Success) :-
%      reset_counts,
%      time_chain(2, Chain),
%      gen_interference_theory(T),
%      Rule = rule(head(Rulename), _),
%      default_window(Operation, Block, Rs),
%      ds(DS),
%      code(DS, Operation, _, Block, Pre, _, _),
%      generate_symbol(time, Time1),
%      generate_symbol(time, Time2),
%      add_time_list(Time1, Pre, PreFmt1),
%      % maplist(to_var, PreFmt, PreFmt1),
%      get_interference_head_and_domains(Operation, Block, Pre, Head, DomainVars),
%      Head =.. [_|Vars],
%      append(Vars, [Time1], Vars2),
%      ConditionHead =.. [condition|Vars2],
%      CondHead =.. [condition|Vars],
%      Condition = rule(head(ConditionHead),body(PreFmt1)),
%      add_time_unconditional_constant(t1, CondHead, Condt1),
%      add_time_unconditional_constant(t2, CondHead, Condt2),
%      Falsify = rule(head(falsify),body([time(t1), time(t2), 
%                      next_time(t1, t2), Condt1, not(Condt2)])),
%      Constraint = constraint([not(falsify)]),
%      append(T, Rs, F),
%      append(F, [Condition, Falsify, Constraint], F1),
%      append(F1, Chain, F2),
%      write_rules(F2, S),
%      rules_str(S, S1),
%      term_string(Operation, Ops),
%      string_concat(Ops, "_", Ops1),
%      term_string(Block, Bs),
%      string_concat(Ops1, Bs, OperationBlock),
%      string_concat('adequacy_', OperationBlock, Adequacy),
%      add_to_base_theory(Adequacy, S1),
%      solve_models(Adequacy, one, Models),
%      (Models \= [] -> Success = false ; Success = true).


check_adequacy_2(Op, Block, true) :-
       op_blocks(Blocks), remove_duplicates(Blocks, Blocks1),
       check_adequacy_2_loop(Op, Block, Blocks1, true).


check_adequacy_2_loop(Op, Block, [(OpInterfere,BlockInterfere)|T], true) :-
      check_adequacy_2(Op, Block, OpInterfere, BlockInterfere, true),
      check_adequacy_2_loop(Op, Block, T, true).

check_adequacy_2_loop(Op, Block, [(OpInterfere,BlockInterfere)|_], false) :-
     check_adequacy_2(Op, Block, OpInterfere, BlockInterfere, false).
               
check_adequacy_2_loop(_, _, [], true).

check_adequacy_2(Operation, Block, OpInterfere, BlockInterfere, Success) :-
      assert(signature(locked, 1, [node])),
      assert(sig_type(locked, 1, [node])),
      reset_counts,
      time_chain(2, Chain),
      gen_interference_rules_positive(OpInterfere, BlockInterfere, T),
      default_window(Operation, Block, Rs),
      ds(DS),
      code(DS, Operation, _, Block, Pre, _, _),
      generate_symbol(time, Time1),
      add_time_list(Time1, Pre, PreFmt1),
      % maplist(to_var, PreFmt, PreFmt1),
      get_interference_head_and_domains(OpInterfere, BlockInterfere, Pre, Head, _),
      Head =.. [_|Vars],
      append(Vars, [Time1], Vars2),
      ConditionHead =.. [condition|Vars2],
      CondHead =.. [condition|Vars],
      Condition = rule(head(ConditionHead),body(PreFmt1)),
      add_time_unconditional_constant(t1, CondHead, Condt1),
      add_time_unconditional_constant(t2, CondHead, Condt2),
      Falsify = rule(head(falsify),body([time(t1), time(t2), 
                      next_time(t1, t2), Condt1, not(Condt2)])),
      Constraint = constraint([not(falsify)]),
      append(T, [], F),
      append(F, [Condition, Falsify, Constraint], F1),
      append(F1, Chain, F2),
      write_rules(F2, S),
      rules_str(S, S1),
      write_rules(Rs, Rs2),
      rules_str(Rs2, S2),
      string_concat(S1, '\n', S3),
      string_concat(S2, S3, S4),
      term_string(Operation, Ops),
      string_concat(Ops, "_", Ops1),
      term_string(Block, Bs),
      string_concat(Ops1, Bs, OperationBlock),
      string_concat('adequacy_', OperationBlock, Adequacy),
      add_to_base_theory(Adequacy, S4),
      solve_models(Adequacy, one, Models), !, 
      (Models \= [] -> Success = false ; Success = true).


check_adequacyV2 :-
     findall((X,Y,Z),signature(X,Y,Z), List1),
     findall((X1,Y1),signature(X,Y),List2),
     assert_sig1(List1),
     assert_sig2(List2),
     prepare_base_theory, !,
     findall((X,Y,Z),sig1(X,Y,Z), List3),
     findall((X1,Y1),sig2(X,Y),List4),
     assert_sig_original_1(List3),
     assert_sig_original_2(List4), 
     op_blocks(OpBlocks), remove_duplicates(OpBlocks, OpBlocks1),
     check_adequacy_true(OpBlocks1).

check_adequacy_true([(Op,Block)|T]) :-
      check_adequacy_2(Op, Block, true),
      check_adequacy_true(T).

check_adequacy_true([]).


ass_sig1((X,Y,Z), _) :- assert(sig1(X,Y,Z)).
ass_sig2((X,Y), _) :- assert(sig2(X,Y)).
ass_sig3((X,Y,Z), _) :- assert(signature(X,Y,Z)).
ass_sig4((X,Y), _) :- assert(signature(X,Y)).

assert_sig1(List) :- maplist(ass_sig1, List,_).
assert_sig2(List) :- maplist(ass_sig2, List,_).
assert_sig_original_1(List) :- maplist(ass_sig3, List,_).
assert_sig_original_2(List) :- maplist(ass_sig4, List,_).
precondition_rule((Op, Block), [Constraint, Rule]) :-
      ds(DS),
      pre(DS, Op, Block, Pre),
      term_string(Op, OpS),
      term_string(Block, BlockS),
      string_concat(OpS, "_", OpS1),
      string_concat(OpS1, BlockS, OpBlockS),
      term_string(OpBlock, OpBlockS),
      Rule = rule(head(OpBlock), body(Pre)),
      Constraint = constraint([not(OpBlock)]).


precondition_rules(Rules1) :-
      op_blocks(OpBlocks),
      remove_duplicates(OpBlocks, OpBlocks1),
      maplist(precondition_rule, OpBlocks1, Rules),
      flatten(Rules, Rules1).


:- dynamic num_nodes/1.
:- dynamic curr_depth/1.
:- dynamic type_of/1.

curr_depth(3).
num_nodes(7).


increase_num_nodes :-
       ((type_of(tree) ; type_of(list)) ->
              (curr_depth(D),
              D1 is D + 1,
              N is 2 ** D1 - 1)
        ;
         type_of(int_tree) -> 
               (num_nodes(N1),
               N is N1 + 1,
               curr_depth(D),
               D1 is D)
              ),
       retractall(num_nodes(_)),
       retractall(curr_depth(_)),
       assert(curr_depth(D1)),
       assert(num_nodes(N)).


pick_instance(Instance) :-
    type_of(list) -> pick_instance_list(Instance) ;
    type_of(tree)  -> pick_instance_tree(Instance);
    type_of(int_tree) -> class(tree, Instance).

pick_instance_int_tree(Instance) :-
    prepare_instance_theory(N, File, DSFile),
    find_instance(int_tree, N, Instance, File, DSFile).


pick_instance_tree(Instance) :- 
    prepare_instance_theory(N, File, DSFile), 
    find_instance(tree, N, Instance, File, DSFile).


pick_instance_list(Instance) :- 
    prepare_instance_theory(N, File, DSFile), 
    find_instance(list, N, Instance, File, DSFile).

populate_unreachable_nodes(Facts) :-
    ds(DS),
    findall(X, pre(DS,_,_,X), List) ,
    maplist(count_unreachable, List, Counts),
    reduce(Counts, sum, 0, Count),
    gen_node_info(Count, Facts).

gen_node_info(Count, [node(X), key(X, KX)| R]) :-
      Count > 0, 
      gen_nodename(X), !,
      key(X, KX),
      Count1 is Count - 1,
      gen_node_info(Count1, R).

gen_node_info(0, []).


count_unreachable(List, Count) :-
      count_unreachable(List, 0, Count).

count_unreachable([H|T], C, Count) :- 
        H = not(reachable(_)), !,
        C1 is C + 1,
        count_unreachable(T, C1, Count).

count_unreachable([H|T], C, Count) :-
        H \= not(reachable(_)),
        count_unreachable(T, C, Count).

count_unreachable([], C, C).
  
sum(X, Y, Z) :- Z is X + Y, !.

prepare_instance_theory(N, File, DSFile) :-
    file_cleanup,
    ds_file(DSFile),
    input_path(Path),
    vanilla_theory(Vanilla), 
    write_rules(Vanilla, VanillaRules),
    rules_str(VanillaRules, VanillaStr),
    reasoning_path(RPath),
    string_concat(DSFile, "_heap", DSPath),
    string_concat(RPath, DSPath, File),
    add_text_to_file(VanillaStr, File),
    precondition_rules(Rules),
    write_rules(Rules, Rules1),
    % write_rules_alt(Rules, Rules1),
    rules_str(Rules1, RulesStr),
    add_text_to_file(RulesStr, File),
    populate_unreachable_nodes(Unreachable),
    facts(Unreachable, UnreachableStr),
    add_text_to_file(UnreachableStr, File),
    num_nodes(N).


find_instance(int_tree, N, R, File, DSFile) :-
    treegen([int_tree, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ;  R = Instance). 
    

find_instance(tree, N, R, File, DSFile) :-
    treegen([tree, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ;  R = Instance). 


find_instance(list, N, R, File, DSFile) :-
    treegen([list, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ;  R = Instance). 

:- dynamic model/1.
:- use_module(library(error)).

solve_models(equiv, success) :-
    shell('cat empty > models-eq_check', _),
    solve_models('eq_check', 1, [_|_]).

solve_models(equiv, fail) :-
    shell('cat empty > models-eq_check', _),
    solve_models('eq_check', 1, []).

solve_models(File, All, Models) :-
     ((All = all) -> Option = '0 ' ; Option = ' '),
     string_concat('clingo --outf=3 --warn no-atom-undefined', Option, Pre),
     reasoning_path(ReasoningPath),
     string_concat(ReasoningPath, File, File1),
     string_concat(Pre, File1, BaseCmd),
     % string_concat('./reasoning_files/models-',File, FileModels),
     string_concat(ReasoningPath, 'models-', ModelsPrefix),
     % string_concat('models-',File, FileModels),
     string_concat(ModelsPrefix, File, FileModels),
     string_concat('cat empty > ', FileModels, EmptyModelsCmd),
     shell(EmptyModelsCmd, _),
     string_concat(BaseCmd, ' post-process.py', PostProcess),
     string_concat(' >> ', FileModels, Redirect),
     string_concat(PostProcess, Redirect, Cmd),
     shell(Cmd, _),
     load_models(FileModels, Models).

load_models(File, Models) :-
     load_models(File),
     findall(X, model(X), Models).

load_models(File) :-
        retractall(model(_)),
        open(File, read, Stream),
        call_cleanup(load_terms(Stream),
                     close(Stream)).

load_terms(Stream) :-
        read(Stream, T0),
        load_terms(T0, Stream).

load_terms(end_of_file, _) :- !.
load_terms(model(X), Stream) :- !,
        assert(model(X)),
        read(Stream, T2),
        load_terms(T2, Stream).
load_terms(Term, Stream) :-
        type_error(model, Term).


file_cleanup :-
      reasoning_path(Path),
      Path \= './',
      string_concat(Path, '*', Everything),
      string_concat('rm -r ', Everything, Cmd),
      shell(Cmd, _).


operation(nurmii, add).
operation(nurmii, remove).
operation(nurmii, blacking).
operation(nurmii, single_rotation).
operation(nurmii, double_rotation).
operation(nurmii, reduce_weight).
operation(nurmii, rotate_and_reduce_weight).


write_operation(nurmii, add,_).
write_operation(nurmii, remove,_).
write_operation(nurmii, blacking,_).
write_operation(nurmii, single_rotation,_).
write_operation(nurmii, double_rotation,_).
write_operation(nurmii, reduce_weight,_).
write_operation(nurmii, rotate_and_reduce_weight,_).


causes(nurmii, weight_left(x,w), change_weight_left(x,w)).
causes(nurmii, weight_right(x,w),change_weight_right(x,w)).
causes(nurmii, left(x,y), link_left(x,y)).
causes(nurmii, right(x,y), link_right(x,y)).

primitive_write_operation(nurmii, link_left).
primitive_write_operation(nurmii, link_right).
primitive_write_operation(nurmii, change_weight_left).
primitive_write_operation(nurmii, change_weight_right).

modifies(nurmii, x, link_left(x,y)).
modifies(nurmii, x, link_right(x,y)).
modifies(nurmii, x, change_weight_left(x,w)).
modifies(nurmii, x, change_weight_right(x,w)).


pre(nurmii, blacking, onlycase, 
	[
	 reachable(p), left(p, c), 
     weight_left(p, w), int_gt(w, 0), weight_left(c, 0), weight_right(c, 0), sum(w, -1, w1) 
	]).

program_steps(nurmii, blacking, onlycase, [
     change_weight_left(c, 1),
     change_weight_right(c, 1),
     change_weight(p, w1)
	]).

pre(nurmii, single_rotation, case1, [
     reachable(p), left(p, v),
     left(v, u), left(u, a), right(u, b), right(v, c),
     weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w, 1)
	]).

program_steps(nurmii, single_rotation, case1, [
       link_right(u, v),
       link_left(v, b),
       link_left(p, v)
	]).

pre(nurmii, double_rotation, case1, [
      reachable(p), left(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul, 1), weight_left(tee , wtl), int_gte(wtl, 1),
      weight_right(tee, wtr), int_gte(wtr, 1) 

	]).

program_steps(nurmii, double_rotation, case1, [
      link_left(t, u),
      link_right(u, b),
      link_right(t, v),
      link_left(v, c), 
      link_left(p, t)
	]).


pre(nurmii, reduce_weight, case1, [
        reachable(p), left(p, v),
        weight_left(p, wpl), weight_left(v, wvl), weight_right(v, wvr),
        int_gte(wpl, 1), int_gt(wvl, 1), int_gt(wvr, 1),
        sum(wpl, 1, wpl1), sum(wvl, -1, wvl1), sum(wvr, -1, wvr1)
	]).

program_steps(nurmii, reduce_weight, case1, [
      change_weight_left(p, wpl1),
      change_weight_left(v, wvl1),
      change_weight_rigth(v, wvr1)
	]).


pre(nurmii, rotate_and_reduce_weight, case1, 
	[
       reachable(p), left(p, u), 
       left(u, a), right(u, v), left(v, b), right(v, c),
       weight_left(u, w1), int_gt(w1, 1), weight_right(u, 0), 
       weight_left(v, w2), int_gte(w2, 1), 
       weight_right(v, w3), int_gte(w3, 1),
       sum(w1, -1, w11), sum(w2, -1, w21)
	]).

program_steps(nurmii, rotate_and_reduce_weight, case1, [
       link_left(v, u),
       link_right(u, b),
       change_weight_left(v, 1),
       change_weight_left(u, w11),
       change_weight_right(u, w21),
       link_left(p, v)
	]).



class(nurmii, [node(node7),
key(node7,knode7),
num(knode7),
lt(knode7,knode3),
node(node3),
key(node3,knode3),
num(knode3),
lt(knode3,knode8),
node(node8),
key(node8,knode8),
num(knode8),
lt(knode8,knode1),
node(node1),
key(node1,knode1),
num(knode1),
lt(knode1,knode12),
node(node12),
key(node12,knode12),
num(knode12),
lt(knode12,knode4),
node(node4),
key(node4,knode4),
num(knode4),
lt(knode4,kroot),
node(root),
key(root,kroot),
num(kroot),
lt(kroot,knode5),
node(node5),
key(node5,knode5),
num(knode5),
lt(knode5,knode2),
node(node2),
key(node2,knode2),
num(knode2),
lt(knode2,knode6),
node(node6),
key(node6,knode6),
num(knode6),
root(root),
root(root),
left(root,node1),
right(root,node2),
weight_left(root,7),
weight_right(root,2),
left(node1,node3),
right(node1,node4),
weight_left(node1,0),
weight_right(node1,0),
left(node2,node5),
right(node2,node6),
weight_left(node2,8),
weight_right(node2,7),
left(node3,node7),
right(node3,node8),
weight_left(node3,-3),
weight_right(node3,-3),
left(node4,node12),
weight_left(node4,7)
]).


code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). operation(nurmi, add).
operation(nurmi, remove).
operation(nurmi, blacking).
operation(nurmi, single_rotation).
operation(nurmi, double_rotation).
operation(nurmi, reduce_weight).
operation(nurmi, rotate_and_reduce_weight).


write_operation(nurmi, add,_).
write_operation(nurmi, remove,_).
write_operation(nurmi, blacking,_).
write_operation(nurmi, single_rotation,_).
write_operation(nurmi, double_rotation,_).
write_operation(nurmi, reduce_weight,_).
write_operation(nurmi, rotate_and_reduce_weight,_).


causes(nurmi, weight_left(x,w), change_weight_left(x,w)).
causes(nurmi, weight_right(x,w),change_weight_right(x,w)).
causes(nurmi, left(x,y), link_left(x,y)).
causes(nurmi, right(x,y), link_right(x,y)).

primitive_write_operation(nurmi, link_left).
primitive_write_operation(nurmi, link_right).
primitive_write_operation(nurmi, change_weight_left).
primitive_write_operation(nurmi, change_weight_right).

modifies(nurmi, x, link_left(x,y)).
modifies(nurmi, x, link_right(x,y)).
modifies(nurmi, x, change_weight_left(x,w)).
modifies(nurmi, x, change_weight_right(x,w)).


pre(nurmi, blacking, onlycase, 
	[
	 reachable(p), left(p, c), 
     weight_left(gp, w), int_gt(w, 0), weight_left(c, 0), weight_right(c, 0), sum(w, -1, w1) 
	]).

program_steps(nurmi, blacking, onlycase, [
     change_weight_left(c, 1),
     change_weight_right(c, 1),
     change_weight(p, w1)
	]).

pre(nurmi, single_rotation, case1, [
     reachable(p), left(p, v),
     left(v, u), left(u, a), right(u, b), right(v, c),
     weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w, 1)
	]).

program_steps(nurmi, single_rotation, case1, [
       link_right(u, v),
       link_left(v, b),
       link_left(p, v)
	]).

pre(nurmi, double_rotation, case1, [
      reachable(p), left(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul, 1), weight_left(t, wtl), int_gte(wtl, 1),
      weight_right(t, wtr), int_gte(wtr, 1) 

	]).

program_steps(nurmi, double_rotation, case1, [
      link_left(t, u),
      link_right(u, b),
      link_right(t, v),
      link_left(v, c), 
      link_left(p, t)
	]).


pre(nurmi, reduce_weight, case1, [
        reachable(p), left(p, v),
        weight_left(p, wpl), weight_left(v, wvl), weight_right(v, wvr),
        int_gte(wpl, 1), int_gt(wvl, 1), int_gt(wvr, 1),
        sum(wpl, 1, wpl1), sum(wvl, -1, wvl1), sum(wvr, -1, wvr1)
	]).

program_steps(nurmi, reduce_weight, case1, [
      change_weight_left(p, wpl1),
      change_weight_left(v, wvl1),
      change_weight_rigth(v, wvr1)
	]).


pre(nurmi, rotate_and_reduce_weight, case1, 
	[
       reachable(p), left(p, u), 
       left(u, a), right(u, v), left(v, b), right(v, c),
       weight_left(u, w1), int_gt(w1, 1), weight_right(u, 0), 
       weight_left(v, w2), int_gte(w2, 1), 
       weight_right(v, w3), int_gte(w3, 1),
       sum(w1, -1, w11), sum(w2, -1, w21)
	]).

program_steps(nurmi, rotate_and_reduce_weight, case1, [
       link_left(v, u),
       link_right(u, b),
       change_weight_left(v, 1),
       change_weight_left(u, w11),
       change_weight_right(u, w21),
       link_left(p, v)
	]).



class(nurmi, [node(node7),
key(node7,knode7),
num(knode7),
lt(knode7,knode3),
node(node3),
key(node3,knode3),
num(knode3),
lt(knode3,knode8),
node(node8),
key(node8,knode8),
num(knode8),
lt(knode8,knode1),
node(node1),
key(node1,knode1),
num(knode1),
lt(knode1,knode12),
node(node12),
key(node12,knode12),
num(knode12),
lt(knode12,knode4),
node(node4),
key(node4,knode4),
num(knode4),
lt(knode4,kroot),
node(root),
key(root,kroot),
num(kroot),
lt(kroot,knode5),
node(node5),
key(node5,knode5),
num(knode5),
lt(knode5,knode2),
node(node2),
key(node2,knode2),
num(knode2),
lt(knode2,knode6),
node(node6),
key(node6,knode6),
num(knode6),
root(root),
root(root),
left(root,node1),
right(root,node2),
weight_left(root,7),
weight_right(root,2),
left(node1,node3),
right(node1,node4),
weight_left(node1,0),
weight_right(node1,0),
left(node2,node5),
right(node2,node6),
weight_left(node2,8),
weight_right(node2,7),
left(node3,node7),
right(node3,node8),
weight_left(node3,-3),
weight_right(node3,-3),
left(node4,node12),
weight_left(node4,7)
]).


code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). 

strip_arity('_false_0', false).

strip_arity(Term, Term) :-
	  Term =.. [Name|_],
    operator(Name), !.

strip_arity(Term, Term2) :- 
      Term =.. [Name|Args],
      atom_chars(Name, Chars),
      not(operator(Name)),
      append(Prefix, ['_'|X], Chars), 
      not(append(_, ['_' | _], X)),
       !,
      atom_chars(Name2, Prefix),
      Term2 =.. [Name2|Args].

strip_arity(X, X).

operator(\=).
operator(<).
operator(>).
operator(=).
operator(>=).
operator(<=).
operator(+).
operator(-).
operator('!=').
operator('..').

first_char(String, Char) :-
     not(string_chars(String,_)), !,
     term_string(String, Str),
     first_char(Str, Char).

first_char(String, Char) :-
     string_chars(String, [Char|_]).

format_sasp_arg([], []) :- !.

strip_constant_special(constant(X), X).
strip_constant_special(X, Y) :-
           X \= constant(_), X = [_|_],
           maplist(strip_constant_special, X, Y).
strip_constant_special(X, X) :-
           X \= constant(_), X \= [_|_].

format_sasp_arg(Term, Formatted) :-
       Term \= [_|_], Term \= [], 
       Term =.. [Name|Args], length(Args, L), L > 0, 
       format_sasp_arg(Name, NameFmt),
       maplist(format_sasp_arg, Args, ArgsFmt),
       (NameFmt = constant(X) -> NameFmt1 = X ; NameFmt1 = NameFmt),
       maplist(strip_constant_special, ArgsFmt, ArgsFmt1),
       Formatted =.. [NameFmt1|ArgsFmt1], !.


format_sasp_arg(typenum(X), constant(X)) :- !.
format_sasp_arg('..','..').

format_sasp_arg(X+Y,TX+TY) :-
      (X = typenum(X1) -> term_string(constant(X1), S1), SX = S1 ; SX = X),
      (Y = typenum(Y1) -> term_string(constant(Y1), S2), SY = S2 ; SY = Y),
      string_lower(SX, SX1),
      string_lower(SY, SY1),
      term_string(TX, SX1),
      term_string(TY, SY1),
      !.

format_sasp_arg(X, constant(X1)) :- 
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, lower),
      strip_arity(X, X1).
      
format_sasp_arg(X, X1) :-
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, upper),
      string_lower(X, Xs),
      term_string(X1, Xs).

format_sasp_arg(X, X1) :- 
      X = [_|_],
      maplist(format_sasp_arg, X, X1).

format_sasp_functor2(Functor, F) :-
       Functor = not(F1), !,
       format_sasp_functor2(F1, F2),
       F = not(F2).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Functor], !,
     format_sasp_functor(Functor, F).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Name, Tuples],
     Tuples =.. [Name2|_],
     operator(Name2), !, 
     format_sasp_functor(Functor, F).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Name|Tuples],
     Tuples =.. [Name2|_],
     not(operator(Name2)), !, 
     maplist(tuple_list, Tuples, Args),
     flatten(Args, Args1),
     Functor2 =.. [Name|Args1],
     format_sasp_functor(Functor2, F).

format_sasp_functor2(Functor, F) :-
       !,
       format_sasp_functor(Functor, F).


format_sasp_functor(Functor, F2) :-
      Functor = not(Functor1),
      format_sasp_functor(Functor1, F1),
      F2 = not(F1).

format_sasp_functor(Functor, F2) :-
     Functor \= not(_),
     strip_arity(Functor, F1),
     F1 =.. [Name|Args],
     maplist(format_sasp_arg, Args, Args1),
     F2 =.. [Name|Args1].

format_sasp_rule(Head-_, []) :- 
   Head =.. [Name|_],
   reserved_predicate_names(Names),
   reserved(Name, Names, Head),
   format_sasp_functor2(Head, Head1),
   strip_constant_symbol(Head1, Head2),
   brk2(Head2),
   (Head2 =.. [primitive_write_step|[Op|Args]] -> Head3 =.. [primitive_write_step, Op, Args] 
          ;    Head3 = Head2),  
   assert(Head3). 
   %Rule = rule(head(Head2), body([])).

brk2(_).

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
    reserved_predicate_names(Names),
	  not(member(Name, Names)),
    Name \= '_false_0',
   format_sasp_functor2(Head, Head1),
	 % Head1 \= false,
	 maplist(format_sasp_functor2, Body, Body1),
	 Rule = rule(head(Head1), body(Body1)).     

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
	  Name = '_false_0',
	 format_sasp_functor(Head, Head1),
	 Head1 = false,
	 maplist(format_sasp_functor2, Body, Body1),
	 Rule = constraint(Body1).     

reserved_predicate_names([
   'signature_3',
   'node_property_1',
   'fluent_1',
   'invariant_1',
   'constructor_1',
   'primitive_write_step_2',
   'causes_2',
   'modifies_2',
   'constants_2'
]).

brk(_).

reserved(Name, Names, _) :-
     member(Name, Names).

reserved(Name, _, Head) :-
     begins_with(Name, "signature"),
     brk(Head),
     remove_constant_functor(Head, Formatted2),
     Formatted2 =.. Args,
     maplist(strip_arity, Args, Args1),
     Formatted =.. Args1,
     Args1 = [A|B],
     B = [C, D | E],
     (E = [] -> (Formatted3 =.. [sig_type| [C, D, []]], Formatted4 =.. [signature| [C, D, []]])
             ; (Formatted3 =.. [sig_type|[C, D, E]]), Formatted4 =.. [signature|[C, D, E]]),
     assert(Formatted3),
     assert(Formatted4).

remove_constant(constant(X), X) :- !.
remove_constant(typenum(X), X) :- !.
remove_constant(X, X).

remove_constant_functor(Functor, Functor2) :-
      Functor =.. [Name|Args],
      maplist(tuple_list, Args, Args1),
      flatten(Args1, Args2),
      maplist(remove_constant, Args2, Args3),
      Functor2 =.. [Name|Args3].


strip_constant_symbol(Term, Term2) :-
      Term =.. [Name|Args],
      maplist(strip_constant_symbol_helper, Args, Args1),
      Term2 =.. [Name|Args1].

strip_constant_symbol_helper([], []) :- !.

strip_constant_symbol_helper(X, X) :-
           X \= constant(_), X \= [_|_], !.

strip_constant_symbol_helper(constant(X), X) :-
          X \= [_|_].

strip_constant_symbol_helper(X, X1) :-
          X = [_|_],
          maplist(strip_constant_symbol_helper, X, X1).

sasp_locksynth(Rules, Rules2) :-
     maplist(format_sasp_rule, Rules, Rules1),
     flatten(Rules1, Rules2).

:- dynamic node_property/1.
:- discontiguous node_property/1.

cleanup :- 
  retractall(signature(_, _, _)), 
  retractall(fluent(_)),
  %retractall(node_property(_)),
  retractall(invariant(_)),
  retractall(constructor(_)),
  retractall(time_dependent(_)),
  retractall(time_dependent(_, _)),
  retractall(causes(_, _)),
  retractall(modifies(_, _)),
  retractall(primitive_write_step(_, _)),
  retractall(rule_base(_, _)),
  retractall(constraint_base(_, _)),
  retractall(nonterminal(_)),
  %retractall(rule(_, _)),
  %retractall(start(_)),
  assert(signature(lt, 2, [num, num])),
  assert(signature(gt, 2, [num, num])),
  assert(signature(eq_num, 2, [num, num])),
  assert(signature(not_eq_num, 2, [num, num])),
  assert(signature(eq_node, 2, [node, node])),
  assert(signature(not_eq_node, 2, [node, node])).



assert_signature([H|T]) :-
        H = signature(_, _, _),
        assert(H),
        assert_signatures(T).

assert_signatures([H|T]) :-
        H \= signature(_, _, _),
        assert_signatures(T).

assert_signatures([]).





% Add a key in an external bst
pre(rb, add, case1, [
       reachable(x),
       external(x), parent(x, p), left(p,x), color(x, black), not(reachable(internal)), not(reachable(target)),
       key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target), 
       tag(x, none), tag(p, none), tag(tag, none), tag(internal, none),
       color(p, black)
  ]).

program_steps(rb, add, case1, [
        link_left(internal, target),
        link_right(internal, x),
        link_left(p, internal),
        change_color(internal, red)
       ]).


pre(rb, add, case2, [
      reachable(x), external(x), parent(x, p), left(p, x), not(reachable(internal)), not(reachable(target)),
      key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target),
      color(p, red), parent(p, gp), color(gp, black), left(gp, p), right(gp, c), 
      color(c, black), parent(gp, ggp), left(ggp, gp), sibling(p, y),
      tag(x, none), tag(p, none), tag(internal, none), tag(target, none), tag(gp, none), tag(c, none),
      tag(p, none)
  ]).

program_steps(rb, add, case2, [
      link_left(internal, target),
      link_right(internal, x),
      link_left(p, internal),
      change_color(internal, red),
      link_right(p, gp),
      link_left(gp, y),
      link_left(ggp, p),
      change_color(p, black),
      change_color(gp, red)
  ]).

% recolor nodes, no rotation needed
pre(rb, add,  case3, [
   not(reachable(internal)), not(reachable(target)),
   external(x), color(x, red), parent(x, p), key(x, kx), lt(ktarget, kx), parent(p, gp), left(p, x),
   color(p, black), color(gp, red), sibling(x, y), sibling(p, sp), color(sp, red),
   tag(x, none), tag(p, none), tag(gp, none), tag(y, none), tag(sp, none), visited(x, target)
  ]).

program_steps(rb, add, case3, [
  not(reachable(internal)), not(reachable(target)),
  link_left(internal, target), link_right(internal, x), link_left(p, internal), 
  change_color(internal, black), change_color(p, red), change_color(sp, black), tag(gp, tagged),
  change_tag(target, none), change_tag(internal, none)
  ]).

% resolve a red-red conflict
pre(rb, red_red_resolve, case1,  
  [
  tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red),
  tag(p, none), tag(y, none), tag(gp, none)
  ]).

program_steps(rb, red_red_resolve, case1, 
  [
   change_color(x, black), change_color(p, red), change_tag(x, none), change_tag(gp, tagged)
  ]).

% remove a key from external bst
pre(rb, remove, case1,[
       reachable(x), external(x), parent(x, p),  sibling(x, y), color(x, black), color(y, black),
       color(p, red), parent(p, gp), left(gp, p), color(gp, black),
       tag(x, none), tag(y, none), tag(p, none), tag(gp, none)  
  ]).

program_steps(rb, remove, case1, [
         link_left(gp, y)
  ]).


%pre(rb, remove, case2, [
%    reachable(x), external(x), parent(x, p), parent(p, gp), sibling(x, y), 
%    left(p, x), left(gp, p), right(gp, c), 
%    color(p, black), color(gp, red), color(c, black),
%
%%% ]).

%program_steps(rb, remove, case2,[
%
%
% ]).

pre(rb_tree, add, case1, [
       reachable(x),
       external(x), parent(x, p), left(p,x), color(x, black), not(reachable(internal)), not(reachable(target)),
       key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target), 
       tag(x, none), tag(p, none), tag(tag, none), tag(internal, none),
       color(p, black)
	]).

program_steps(rb_tree, add, case1, [
        link_left(internal, target),
        link_right(internal, x),
        link_left(p, internal),
        change_color(internal, red)
       ]).


pre(rb_tree, add, case2, [
      reachable(x), external(x), parent(x, p), left(p, x), not(reachable(internal)), not(reachable(target)),
      key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target),
      color(p, red), parent(p, gp), color(gp, black), left(gp, p), right(gp, c), 
      color(c, black), parent(gp, ggp), left(ggp, gp), sibling(p, y),
      tag(x, none), tag(p, none), tag(internal, none), tag(target, none), tag(gp, none), tag(c, none),
      tag(p, none)
	]).

program_steps(rb_tree, add, case2, [
      link_left(internal, target),
      link_right(internal, x),
      link_left(p, internal),
      change_color(internal, red),
      link_right(p, gp),
      link_left(gp, y),
      link_left(ggp, p),
      change_color(p, black),
      change_color(gp, red)
	]).

pre(rb_tree, add,  case3, [
	 external(x), color(x, red), parent(x, p), key(x, kx), lt(ktarget, kx), parent(p, gp), left(p, x),
	 color(p, black), color(gp, red), sibling(x, y), sibling(p, sp), color(sp, red),
	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none), tag(sp, none), visited(x, target)
	]).

program_steps(rb_tree, add, case3, [
	link_left(internal, target), link_right(internal, x), link_left(p, internal), 
	change_color(internal, black), change_color(p, red), change_color(sp, black), tag(gp, tagged),
	change_tag(target, none), change_tag(internal, none)
	]).

pre(rb_tree, red_red_resolve, case1,  
	[
	tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red),
	tag(p, none), tag(y, none), tag(gp, none)
	]).

program_steps(rb_tree, red_red_resolve, case1, 
	[
	 change_color(x, black), change_color(p, red), change_tag(x, none), change_tag(gp, tagged)
	]).


pre(rb_tree, remove, case1,[
       reachable(x), external(x), parent(x, p),  sibling(x, y), color(x, black), color(y, black),
       color(p, red), parent(p, gp), left(gp, p), color(gp, black),
       tag(x, none), tag(y, none), tag(p, none), tag(gp, none)	
	]).

program_steps(rb_tree, remove, case1, [
         link_left(gp, y)
	]).


%pre(rb_tree, remove, case2, [
%	   reachable(x), external(x), parent(x, p), parent(p, gp), sibling(x, y), 
%	   left(p, x), left(gp, p), right(gp, c), 
%	   color(p, black), color(gp, red), color(c, black),
%
%%%	]).

%program_steps(rb_tree, remove, case2,[
%
%
%	]).

%code(rb_tree, insert, _, block1, 
%	[visited(x, target), external(x), left(z, x), key(x, kx), key(target, ktarget), lt(ktarget, kx), color(x,black),color(z,red),
%	tag(x, none), tag(z, none)],
%	[link_left(internal, target), link_right(internal, x), link_left(z, internal), change_color(x, red), change_color(target, red), change_color(internal, black),
%	 change_tag(target, none), change_tag(internal, none)],
%	_).

%code(rb_tree, insert, _, block2, 
%	[visited(x, target), external(x), left(z, x), key(x, kx), key(target, ktarget), lt(kx, ktarget), color(x,black),color(z,red),
%	tag(x, none), tag(z, none)],
%	[link_right(internal, target), link_left(internal, x), link_left(z, internal), change_color(x, red), change_color(target, red), change_color(internal, black),
%	 change_tag(target, none), change_tag(internal, none)],
%	_).


%code(rb_tree, insert, _, block3, 
%	[visited(x, target), external(x), parent(x, p), parent(p, gp), parent(gp, ggp), key(p, kp), key(gp, kgp), key(ggp, kggp), 
%	 left(p, x), lt(ktarget, x), color(x, red), color(p, black), color(gp, black), color(ggp, black), right(gp, rgp), 
%	 color(rgp, red),
%	 tag(x, none), tag(p, none), tag(gp, none), tag(ggp, none),tag(rgp, none)],
%	[link_left(internal, target), link_right(internal, x),
%	 link_left(p, x), change_color(internal, black), change_color(x, red), change_color(target, red),
%	 change_color(gp, red), change_color(rgp, black),
%	 change_tag(internal, none), change_tag(target, none)],
%	_).

%code(rb_tree, insert, _, block4, 
%	[external(x), key(x,kx), lt(ktarget, kx), parent(x, p), parent(p, gp), parent(gp, ggp),
%	 right(p, x),
%	 color(x, red), color(p, black), color(gp, black), color(ggp, black), sibling(p, sp), left(sp, spl), right(sp, spr),
%	 tag(x, none), tag(p, none), tag(gp, none), tag(ggp, none), tag(sp, none), tag(spl, none), tag(spr, none)],
%	[link_left(internal, target), link_right(internal, x), link_left(p, internal), 
%	  change_color(gp, red), change_color(sp, black), change_color(spl, red), change_spr(red),
%	  change_tag(internal, none), change_tag(target, none)],_).



%code(rb_tree, delete, _, block1,
%	[ external(x), parent(x, p), parent(p, gp), key(target, ktarget), key(x,kx),
%	 color(x, red), color(p, black), color(gp, black), left(gp, p), sibling(target, y),
%	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
%	[link_left(gp, y)],
%	_).

%code(rb_tree, delete, _, block2,
%	[ external(x), parent(x, p), parent(p, gp), key(target, ktarget), key(x,kx),
%	 color(x, black), color(p, red), color(gp, black), left(gp, p), sibling(target, y),
%	 tag(x, none), tag(p, none), tag(gp, none), tag(target, none), tag(y, none)],
%	[link_left(gp, y)],
%	_).


%code(rb_tree, delete, _, block3, 
%	[external(x), color(x, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red), sibling(x, y), left(gp, p),
%	tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
%	[link_left(gp, y), change_color(y, black)],_).

%code(rb_tree, delete, _, block4, 
%	[external(x), color(x, black), parent(x, p), color(p, black), parent(p, gp), color(gp, red), sibling(x, y), left(gp, p),
%	tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
%	[link_left(gp, y), change_color(gp, black)],_).
%

code(rb_tree, insert, _, block5, 
	[external(x), color(x, red), parent(x, p), key(x, kx), lt(ktarget, kx), parent(p, gp), left(p, x),
	 color(p, black), color(gp, red), sibling(x, y), sibling(p, sp), color(sp, red),
	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none), tag(sp, none)],
	[link_left(internal, target), link_right(internal, x), link_left(p, internal), 
	change_color(internal, black), change_color(p, red), change_color(sp, black), tag(gp, tagged),
	change_tag(target, none), change_tag(internal, none)],_).



code(rb_tree, red_red_resolve, _, block1, 
	[tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, black),
	tag(y, none), tag(p, none), tag(gp, none)],
	[change_color(x, black), change_color(p, red), change_tag(x, none)], _).

code(rb_tree, red_red_resolve, _, block2, 
	[tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red),
	tag(p, none), tag(y, none), tag(gp, none)],
	[change_color(x, black), change_color(p, red), change_tag(x, none), change_tag(gp, tagged)], _).


generate_traversal_theory_2(Theory3) :-
    reset_counts, 
     max_depth(Length), 
     time_chain(Length, Chain),
     TimeTransitiveClosureRules = 
       [rule(head(greater(t1, t2)), body([time(t1), time(t2), next_time(t2, t1)])),
        rule(head(greater(t1, t2)), body([time(t1), time(t2), time(t3), greater(t1, t3), greater(t3, t2)]))
      ],
      ds(DS),
     start_node(DS, StartNode),
     Start = rule(head(visitedAgent(StartNode, constant(t1))),body([time(constant(t1))])),
     end_node(DS, EndNode),
     EndNodeFact = rule(head(end_node(constant(EndNode))), body([])), 
     Transitive = rule(head(visitedAgent(y, t2)), body([time(t1), time(t2), next_time(t1, t2), visitedAgent(x, t1), next_node(target, x, y, t1)])),
     VisitedAgent = rule(head(visitedAgent(x)), body([visitedAgent(x,t1)])),
     TraversalDone = rule(head(done(t1)), body([time(t1), visitedAgent(x, t1), end_node(x)])),
     TraversalDoneDominated = rule(head(dominating(t1)),body([time(t1), time(t2), done(t1), done(t2), greater(t1, t2)])),
     EarliestTimeTraversalDone = rule(head(earliest(t1)), body([time(t1), done(t1), not(dominating(t1))])),
     next_node_rules_2(NextNodeRules),
     gen_rounds(Length, Rounds),
     StartOracle = rule(head(visitedOracle(StartNode, constant(1), t1)),body([time(t1)])),
     TransitiveOracle = rule(head(visitedOracle(y, r+1, t1)), body([time(t1), round(r), visitedOracle(x, r, t1), next_node(target, x, y, t1)])),  
     TransitiveOracleVisited = rule(head(visitedOracle(x, t1)), body([time(t1), round(r), visitedOracle(x, r, t1)])),
     append(Chain, NextNodeRules, NextNodeAndChain),
     Theory = [Start, Transitive, StartOracle, TransitiveOracle, TransitiveOracleVisited, TraversalDone, TraversalDoneDominated,
               VisitedAgent, EarliestTimeTraversalDone, EndNodeFact | NextNodeAndChain], 
     append(Theory, TimeTransitiveClosureRules, Theory2),
     append(Theory2, Rounds, Theory3).

next_node_rules_2(Rules) :-
     ds(DS),
     findall((CurrentNode, NextNode, Cond), next_node(DS, target, CurrentNode, (NextNode, Cond)), List),
     maplist(next_node_rules_helper_2, List, Rules).

next_node_rules_helper_2((CurrentNode, NextNode, Cond), Rule) :-
     add_time_list(t1, Cond, Cond1),
     Rule = rule(head(next_node(target, CurrentNode, NextNode, t1)), body([time(t1)|Cond1])).


detect_key_movement_2(Op, Block, Yes) :- 
   generate_traversal_theory_2(T1),
   gen_interference_rules_positive(Op, Block, T2),
   key_movement_rule(Rule), 
   key_movement_constraint(Constraint),
   append(T1, T2, T3),
   append(T3, [Rule, Constraint], T4),
   write_rules(T4, S),
   rules_str(S, S1),
   add_to_base_theory('rcucheck', S1), 
   solve_models('rcucheck', one, Models),
   (Models \= [] -> Yes = true ; Yes = false).


detect_key_movementV2(true) :-
    op_blocks(OpBlocks),
    check_movement_true(OpBlocks).

check_movement_true([(Op,Block)|T]) :-
      detect_key_movement_2(Op, Block, false), !,
      check_movement_true(T).

check_movement_true([(Op,Block)|T]) :-
      detect_key_movement_2(Op, Block, true), !.



generate_traversal_theory(Theory2) :-
    reset_counts, 
     max_depth(Length), 
     time_chain(Length, Chain),
     TimeTransitiveClosureRules = 
       [rule(head(greater(t1, t2)), body([time(t1), time(t2), next_time(t2, t1)])),
        rule(head(greater(t1, t2)), body([time(t1), time(t2), time(t3), greater(t1, t3), greater(t3, t2)]))
      ],
      ds(DS),
     start_node(DS, StartNode),
     Start = rule(head(visited(StartNode, t1)),body([time(t1)])),
     end_node(DS, EndNode),
     EndNodeFact = rule(head(end_node(constant(EndNode))), body([])), 
     Transitive = rule(head(visited(y, t2)), body([time(t1), time(t2), next_time(t1, t2), visited(x, t1), next_node(target, x, y, t1)])),
     TraversalDone = rule(head(done(t1)), body([time(t1), visited(x, t1), end_node(x)])),
     TraversalDoneDominated = rule(head(dominating(t1)),body([time(t1), time(t2), done(t1), done(t2), greater(t1, t2)])),
     EarliestTimeTraversalDone = rule(head(earliest(t1)), body([time(t1), done(t1), not(dominating(t1))])),
     next_node_rules(NextNodeRules),
     StartOracle = rule(head(visitedOracle(StartNode, t1)),body([time(t1)])),
     TransitiveOracle = rule(head(visitedOracle(y, t1)), body([time(t1), visitedOracle(x, t1), next_node(target, x, y, t1)])),  
     append(Chain, NextNodeRules, NextNodeAndChain),
     Theory = [Start, Transitive, StartOracle, TransitiveOracle, TraversalDone, TraversalDoneDominated,
               EarliestTimeTraversalDone, EndNodeFact | NextNodeAndChain], 
     append(Theory, TimeTransitiveClosureRules, Theory2).



next_node_rules(Rules) :-
     ds(DS),
     findall((CurrentNode, NextNode, Cond), next_node(DS, CurrentNode, (NextNode, Cond)), List),
     maplist(next_node_rules_helper, List, Rules).

next_node_rules_helper((CurrentNode, NextNode, Cond), Rule) :-
     add_time_list(t1, Cond, Cond1),
     Rule = rule(head(next_node(target, CurrentNode, NextNode, t1)), body([time(t1)|Cond1])).
     
time_chain(Length, Chain) :-
	   Length > 0,
       time_chain(0, Length, Chain).

time_chain(0, Length, Chain) :-
     generate_symbol(time, Time),
     Rule = rule(head(time(constant(Time))), body([])),
     time_chain(1, Length, Time, [Rule], Chain).



time_chain(N, Length, PrevTime, P, Chain) :-
      N >= 1,
      N < Length,
      generate_symbol(time, Time),
      N1 is N + 1, 
      Rule1 = rule(head(time(constant(Time))), body([])),
      Rule2 = rule(head(next_time(constant(PrevTime), constant(Time))),body([])),
      append(P, [Rule1, Rule2], P1), !, 
      time_chain(N1, Length, Time, P1, Chain).


time_chain(Length, Length, _, Chain, Chain) :- !.

key_movement_rule(Rule) :-
      Head = key_move,  
      Body = [time(t1), earliest(t1), visitedOracle(x, t1), not(visitedAgent(x))],
      Rule = rule(head(Head), body(Body)).

key_movement_constraint(constraint([not(key_move)])).

detect_key_movement(Yes) :- 
   generate_traversal_theory(T1),
   gen_interference_theory(T2),
   key_movement_rule(Rule), 
   key_movement_constraint(Constraint),
   append(T1, T2, T3),
   append(T3, [Rule, Constraint], T4),
   write_rules(T4, S),
   rules_str(S, S1),
   add_to_base_theory('rcucheck', S1), 
   solve_models('rcucheck', one, Models),
   (Models \= [] -> Yes = true ; Yes = false).


element_at_index(Index, List, Element) :-
        element_at_index(Index, 0, List, Element).

element_at_index(Index, Index, [H|_], H).

element_at_index(Index, Curr, [_|T], Element) :-
           Curr < Index, 
           Curr1 is Curr + 1, 
           element_at_index(Index, Curr1, T, Element).

index_of(Element, List, Index) :-
            index_of(Element, List, 0, Index).


index_of(Element, [Element|_], Index, Index) :- !.
index_of(Element, [H|T], Curr, Index) :- 
           Element \= H, 
           Curr1 is Curr + 1, !, 
           index_of(Element, T, Curr1, Index).


index_in_term(Element, Term, Index) :-
        Term =.. [_|Args],
        index_of(Element, Args, Index).


frequency(List, Frequencies) :- 
      frequency(List, [], 0, Frequencies).

frequency([H|T], Store, CurrIndex, Frequencies) :-
        not(member((H, _, _), Store)),
        CurrIndex1 is CurrIndex + 1, 
        frequency(T, [(H, 1, [CurrIndex])|Store], CurrIndex1, Frequencies).

frequency([H|T], Store, CurrIndex, Frequencies) :-
        member((H, F, I), Store),
        F1 is F + 1, 
        NewElement = (H, F1, [CurrIndex|I]),
        replace((H,F,I),NewElement, Store, Store1),
        CurrIndex1 is CurrIndex + 1,
        frequency(T, Store1, CurrIndex1, Frequencies).

frequency([], Frequencies, _, Frequencies).

duplicate_arg_indices([H|T],R) :-
          H = (Element, Frequency, Indices),
          Frequency > 1, 
          Element = constant(_),
          duplicate_arg_indices(T, R).


duplicate_arg_indices([H|T],[X|R]) :-
          H = (Element, Frequency, Indices),
          Frequency > 1, 
          Element \= constant(_),
          X = (Element, Indices),
          duplicate_arg_indices(T, R). 

duplicate_arg_indices([H|T],R) :-
          H = (Element, Frequency, Indices),
          Frequency =< 1, 
          duplicate_arg_indices(T, R). 

duplicate_arg_indices([], []).

:- dynamic symcount/2.

gensym(X, X) :- 
    not(symcount(X,_)), !,
    assert(symcount(X,0)).

gensym(X, Y) :-
    symcount(X, C),
    retractall(symcount(X,_)),
    C1 is C + 1,
    assert(symcount(X,C1)),
    term_string(X, Xs),
    term_string(C1, Cs),
    string_concat(Xs, Cs, Ys),
    term_string(Y, Ys).

dup_symbols([FreqEntry|T], Dups) :-
     FreqEntry = (Element, Freq, Indices),
     gensymbols(Element, Freq, Symbols),
     pair(Symbols, Indices, Dups).
     

gensymbols(Element, Freq, Symbols) :-
       retractall(symcount(Element, _)),
       gensymbols(Element, Freq, [], Symbols).

gensymbols(Element, Freq, P, Symbols) :-
        Freq > 0, 
        gensym(Element, Sym),
        append(P, [Sym], P1),
        Freq1 is Freq - 1,
        gensymbols(Element, Freq1, P1, Symbols).


gensymbols(Element, 0, Symbols, Symbols). 


update_element_at_index(Element, Index, List, List1) :-
            update_element_at_index(Element, Index, List, 0, [], List1).


update_element_at_index(Element, Index, [H|T], CurrIndex, P, List1) :-
          CurrIndex < Index, 
          append(P, [H], P1),
          CurrIndex1 is CurrIndex + 1,
          update_element_at_index(Element, Index, T, CurrIndex1, P1, List1).

update_element_at_index(Element, Index, [H|T], CurrIndex, P, List1) :-
          Index = CurrIndex, 
          append(P, [Element], P1),
          append(P1, T, List1).




rewrite_same_var_term(Term, Term2, _) :-
    retractall(symcount(_, _)),
        Term =.. [Name|Args],
        frequency(Args, Frequencies),
        duplicate_arg_indices(Frequencies, ArgIndices),
        dup_symbols(ArgIndices, DupSymbols),
        update_dup_symbols(Args, DupSymbols, Args2),
        Term2 =.. [Name|Args2].

update_dup_symbols(Args, DupSymbols, Args1) :-
         update_dup_symbols(Args, DupSymbols, Args1).

update_dup_symbols(Args, [(Sym, Index)|T], Args2) :-
         update_element_at_index(Sym, Index, Args, Args1),
         update_dup_symbols(Args1, T, Args2).

update_dup_symbols(Args, [], Args).

:- use_module('./sasp_parser/io').

sasp_rules(Rules) :-
 	ds(DS),
 	base_theory_path(Path),
    io:load_source_files([Path], [], Rules, 0, Errs),
    Errs = 0,
    !.

base_theory(Rules) :-
     sasp_rules(Rs),
     sasp_locksynth(Rs, Rules),
     assert_base_theory(Rules).

eq_num_term(X,Y, eq_num(X,Y)).
eq_node_term(X,Y, eq_node(X,Y)).
not_eq_num_term(X,Y, not_eq_num(X,Y)).
not_eq_node_term(X,Y, not_eq_node(X,Y)).

%rewrite(X<Y,lt(X,Y)) :- !.
%rewrite(X>Y,gt(X,Y)) :- !.
rewrite(X<Y, X<Y) :- !.
rewrite(X>Y, X>Y) :- !.
rewrite(node,X=Y, eq_node(X,Y)).
rewrite(num, X=Y, eq_num(X,Y)).    
rewrite(node,X\=Y, not_eq_node(X,Y)).
rewrite(num, X\=Y, not_eq_num(X,Y)).    

rewrite_term_in_rule(_, X<Y, Rw) :-
      rewrite(X<Y, Rw), !.

rewrite_term_in_rule(_, X>Y, Rw) :-
      rewrite(X>Y, Rw), !.

rewrite_term_in_rule(Rule, X\=Y, X\=Y).
rewrite_term_in_rule(Rule, X=Y, X=Y).


%rewrite_term_in_rule(Rule, X\=Y, Rw) :-
%     (Rule = rule(head(Head), body(Body)) -> append([Head], Body, Literals) ; 
%      Rule = constraint(Body) -> Literals = Body),
%     type_of(X, Literals, Type),
%     (Type = node -> Rw = not_eq_node(X, Y) ; Type = num -> Rw = not_eq_num(X, Y)), !.

%rewrite_term_in_rule(Rule, X=Y, Rw) :-
%     (Rule = rule(head(Head), body(Body)) -> append([Head], Body, Literals) ;
%     Rule = constraint(Body) -> Literals = Body),
%     type_of(X, Literals, Type),
%     (Type = node -> Rw = eq_node(X, Y) ; Type = num -> Rw = eq_num(X, Y)), !.


rewrite_term_in_rule(_, R, R) :- !.


type_of(Var, [H|T], Type) :-
     H = not(X), !,
     type_of(Var, [X|T], Type).

type_of(Var, [H|_], Type) :- 
		not(constants(Var, _)),
    H \= not(_),
		index_in_term(Var, H, Index),
		H =.. [Name|_],   
	    sig_type(Name, _, Types),
	    element_at_index(Index, Types, Type), !.

type_of(Var, [H|T], Type) :- 
		not(constants(Var, _)),
    H \= not(_),
		not(sig_type(Name, _, Types)), !, 
	    type_of(Var, T, Type).

type_of(Var, [H|T], Type) :- 
    H \= not(_),
		not(constants(Var, _)),
		not(index_in_term(Var, H, _)), !,
		type_of(Var, T, Type).

rewrite_term_in_rule_conjunct(Rule, [H|T], Conjunct) :- 
               rewrite_term_in_rule(Rule, H, H1),
               rewrite_term_in_rule_conjunct(Rule, T, R),
               append([H1], R, Conjunct).

rewrite_term_in_rule_conjunct(_, [], []).

rewrite_rule(Rule, Rule1) :-
     Rule = rule(head(Head), body(Body)),
     rewrite_term_in_rule_conjunct(Rule, Body, Body1),
     Rule1 = rule(head(Head), body(Body1)).

rewrite_rule(Rule, Rule1) :-
     Rule = constraint(Body),
     rewrite_term_in_rule_conjunct(Rule, Body, Body1),
     Rule1 = constraint(Body1).


:- dynamic constants/2.	
:- dynamic signature/3.
:- dynamic sig_type/3.


select([H|T], T, H).
select([H|T], [H|R], R1) :-
        select(T, R, R1).

perm(List, R1) :-
	select(List, X, Y),
	perm(X, R),
	append(R,[Y], R1).

perm([], []).

infer_max_depth(MaxDepth) :-
      ds(DS),
      findall(Steps, code(DS, _, _, _, _, Steps, _), List),
      maplist(length, List, Lengths),
      max(Lengths, MaxDepth).

max(List, M) :- 
      List = [H|T],
      max_helper(List, H, M).

max_helper([H|T], P, M) :-
       H > P, 
       max_helper(T, H, M).

max_helper([H|T], P, M) :-
       H =< P, 
       max_helper(T, P, M).

max_helper([], M, M).

rename_steps(Steps, Rename, Rules) :-
     rename_steps(Steps, 0, Rename, Rules).

rename_steps([H|T], C, [H1|R], [Rule|Rules]) :-
      H =.. [Name|Args],
      term_string(C, Cs),
      string_concat("_", Cs, Suffix),
      string_concat(Name, Suffix, Rs),
      term_string(Rename, Rs),
      H1 =..[Rename|Args],
      C1 is C + 1,
      link_renamed_step(H, H1, Rule),
      rename_steps(T, C1, R, Rules).

link_renamed_step(Primitive, Renamed, Rule) :-
      reset_counts,
      generate_symbol(time, Time),
      add_time_unconditional(Time, Primitive, P),
      add_time_unconditional(Time, Renamed, R),
      Head = head(P),
      Body = body([R]),
      Rule = rule(Head, Body).

rename_steps([], _, [], []).

gen_program_step_rules(Steps, Pre, [Rule|R]) :-
	  reset_counts,
	  generate_symbol(time, Time),
	  add_time_list_constant(Time, Pre, Body),
	  Steps = [H|T],
	  add_time_unconditional_constant(Time, H, H1),
	  Rule = rule(head(H1), body(Body)),
	  gen_program_step_rules_helper(T, Time, H1, Body, R).

gen_program_step_rules_helper([H|T], PrevTime, Body, Pre, [Rule|R]) :-
	  generate_symbol(time, Time),
	  append([Body], [next_time(constant(PrevTime), constant(Time))], Body1),
	  append(Body1, Pre, Body2),
	  add_time_unconditional_constant(Time, H, H1),
	  Rule = rule(head(H1), body(Body2)),
	  gen_program_step_rules_helper(T, Time, H1, Pre, R).

gen_program_step_rules_helper([], _, _, _, []).

check_reorder(Op, Block) :-
      check_reorder(Op, Block, _).

check_reorder(Op, Block, Perm) :-
      ds(DS),
      code(DS, Op, _, Block, Pre, Steps, _),
      rename_steps(Steps, Rename, Rules), !, 
      perm(Rename, Perm),
      check_perm(Op, Block, Perm, Pre, Rules, true).
     
check_perm(Op, Block, Steps, Pre, Rules, Success) :-
	  gen_reorder_theory(Op, Block, Steps, Pre, Rules1),
      append(Rules, Rules1, Rules2),
      write_rules(Rules2, RulesStr),
      rules_str(RulesStr, R1),
      term_string(Op, Ops),
      term_string(Block, Bs),
      reduce(['reorder', Ops, Bs], add_underscore, '', File),
      add_to_base_theory(File, R1),
      solve_models(File, one, Models),
      (Models = [] -> Success = false ; Success = true).

 
gen_reorder_theory(Op, Block, Steps, Pre, Rules) :-
      reset_counts,
      infer_max_depth(Depth),
      Depth1 is Depth + 1,
      time_chain(Depth1, TimeRules),
      reset_counts,
      gen_program_step_rules(Steps, Pre, ProgramStepRules),
      append(ProgramStepRules, TimeRules, Rules).
      

get_node_terms([node(var(X))|T], [X|R]) :-
		get_node_terms(T, R).

get_node_terms([], []).

get_key_terms([key(var(X))|T], [X|R]) :-
		get_key_terms(T, R).

get_key_terms([], []).

%gen_eq_rule((Rule, Arg), []) :-
%      dom_of(Arg, Rule, Domain),
%      type_of()
%      Domain \= node, Domain \= num.


gen_eq_rule((Rule, constant(_)), Rule) :- !.
gen_eq_rule((Rule, Arg), []) :-
     Rule = rule(head(Head), body(Body)),
     append([Head], Body, Literals),
     not(type_of(Arg, Literals, _)).

gen_eq_rule((Rule, Arg), []) :-
    Rule = rule(head(Head), body(Body)),
    append([Head], Body, Literals),
    type_of(Arg, Literals, Type),
    Type \= node, Type \= num.

gen_eq_rule((Rule, Arg), EqRule) :-
	  Rule = rule(head(Head), body(Body)),
	  %dom_of(Arg, Body, node),
	  %generate_symbol(node, X),
	  append([Head], Body, Literals),
	  type_of(Arg, Literals, node),
	  gensym(Arg, _),  % ignore first call to gensym which might generate the same symbol
	  gensym(Arg, X),
	  Head =.. [Name|Args],
	  replace(Arg, X, Args, Args1),
	  RewriteHead =.. [Name|Args1],
	  EqRule = rule(head(RewriteHead), body([Head, eq_node(X, Arg)])).

gen_eq_rule((Rule, Arg), EqRule) :-
	  Rule = rule(head(Head), body(Body)),
	  % dom_of(Arg, Body, key),
	  % generate_symbol(key, X),
	  append([Head], Body, Literals),
	  type_of(Arg, Literals, num),
	  gensym(Arg, _),   % ignore first call to gensym which might generate the same symbol
	  gensym(Arg, X),
	  Head =.. [Name|Args],
	  replace(Arg, X, Args, Args1),
	  RewriteHead =.. [Name|Args1],
	  EqRule = rule(head(RewriteHead), body([Head, eq_num(X, Arg)])).

gen_eq_rules(constraint(X), [constraint(X)]).

gen_eq_rules(Rule, [Rule]) :-
     Rule = rule(head(Head), body(Body)),
     Head =.. [Name], !.



gen_eq_rules(Rule, EqRules) :-
     Rule = rule(head(Head), body(Body)),
     Head =.. [_|Args],
     length(Args, L), L >= 1,
     cross_element(Rule, Args, Pairs),
     maplist(gen_eq_rule, Pairs, EqRules).

assert_fluents_as_time_dependent :- 
      findall(X, fluent(X), List),
      assert_time_dependent(List).

assert_time_dependent([H|T]) :- 
		 signature(H, Arity, _),
		 Arity1 is Arity + 1,
         assert(time_dependent(H, Arity1)),
         assert_time_dependent(T).

assert_time_dependent([]).


reify_rule(Rule, Rule2) :-
       Rule = rule(head(Head), body(Body)),
       append([Head], Body, Literals),
       %generate_symbol(time, T),
       add_time_list(t, Literals, [Head1|Body1]),
       Rule2 = rule(head(Head1), body([time(t)|Body1])).

reify_rule(Rule, Rule2) :-
       Rule = constraint(Body),
       Literals = Body,
       %generate_symbol(time, T),
       add_time_list(t, Literals, Body1),
       Rule2 = constraint([time(t)|Body1]).


 reified_theory(Rules) :-
 	       cleanup, 
 	       retractall(symcount(_, _)),
        base_theory(UserDefinedTheory),
        assert_base_theory(UserDefinedTheory),
         assert_fluents_as_time_dependent,
         maplist(rewrite_rule, UserDefinedTheory, Rewrites),
         maplist(gen_eq_rules, Rewrites, EqRules),
         flatten(EqRules, EqRules1),
         remove_duplicates(EqRules1, EqRules2),
        %  write_rules_to_file('EqRules2', EqRules2),
         maplist(reify_rule, EqRules2, ReifiedEq),
         maplist(reify_rule, Rewrites, ReifiedRewrites),
         findall(X, invariant(X), Invariants), 
         maplist(gen_invariant_rule, Invariants, InvariantConstraints),
         append(ReifiedRewrites, ReifiedEq, Preamble),
         append(Preamble, InvariantConstraints, Part1),
         append(Part1, EqRules2, Part2), 
         append(Rewrites, Part2, Part3),
         gen_destructive_update_rules(DestructiveUpdateRules),
         append(Part3, DestructiveUpdateRules, Part4),
         project_into_time(ProjectedRules),
         append(Part4, ProjectedRules, Part5),
         node_property_eq_rules(NodePropEqRules),
         append(Part5, NodePropEqRules, Rules),
         format_constructor(ConstructorRules),
         assert_list(ConstructorRules).

reified_theoryV2(Rules) :-
         cleanup, 
         retractall(symcount(_, _)),
         base_theory(UserDefinedTheory),
         assert_base_theory(UserDefinedTheory),
         assert_fluents_as_time_dependent,
         maplist(rewrite_rule, UserDefinedTheory, Rewrites),
         %maplist(gen_eq_rules, Rewrites, EqRules),
         %flatten(EqRules, EqRules1),
         %remove_duplicates(EqRules1, EqRules2),
        %  write_rules_to_file('EqRules2', EqRules2),
         %maplist(reify_rule, EqRules2, ReifiedEq),
         maplist(reify_rule, Rewrites, ReifiedRewrites),
         findall(X, invariant(X), Invariants), 
         maplist(gen_invariant_rule, Invariants, InvariantConstraints),
         gen_destructive_update_rules(DestructiveUpdateRules),
         project_into_time(ProjectedRules),
         reduce([ReifiedRewrites, InvariantConstraints, DestructiveUpdateRules, ProjectedRules],append,[], Rules).

vanilla_theory(Rules2) :-
    cleanup,
    base_theory(UserDefinedTheory),
    assert_base_theory(UserDefinedTheory),
    maplist(rewrite_rule, UserDefinedTheory, Rewrites),
    cross_element(Rewrites, [signature, fluent, constructor], Pair),
    maplist(remove_term, Pair, Rules),
    flatten(Rules, Rules1),
    remove_duplicates(Rules1, Rules2).

prepare_base_theory :-
       % copy_command('./eq_theories.lp', './reasoning_files/base_theory.lp', Cmd),
       % shell(Cmd, _),
       reified_theoryV2(Rules),
       write_rules_alt(Rules, S),
       rules_str(S,S1),
       shell('cat empty > ./reasoning_files/base_theory.lp',_),
       add_contents_to_file('./reasoning_files/base_theory.lp', S1). 


gen_invariant_rule(not(Pred), constraint([time(t), Pred1])) :-
      add_time_unconditional(t, Pred, Pred1), !.


gen_invariant_rule(Pred, constraint([time(t), not(Pred1)])) :-
      add_time_unconditional(t, Pred, Pred1), !.


gen_destructive_update_rules(Rules) :-
          findall(Step, primitive_write_step(Step, _), Steps),
          maplist(gen_destructive_update_rule, Steps, EffectAxioms),
          maplist(gen_inertia_rules, Steps, InertialRules),
          flatten(InertialRules, InertialRules1),
          append(EffectAxioms, InertialRules1, Rules).

gen_destructive_update_rule(WriteStep, Rule) :-
          causes(Effect, Step),
          Step =.. [WriteStep|Args],
          add_time_unconditional(t1, Effect, EffectT),
          add_time_unconditional(t, Step, StepT),
          Rule = rule(head(EffectT), body([time(t),time(t1), next_time(t, t1),StepT])).

gen_inertia_rules(WriteStep, Rules) :-
        causes(Effect, Step),
        Step =.. [WriteStep|Args],
        node_property(Property), 
        fluent(Property),
        Effect =.. [Property|_],
        modifies(Mem, Step1), 
        Step1 =.. [WriteStep|Args1],
        term_string(Property, Ps),
        string_concat('modifies_', Ps, Mods),
        term_string(ModifiesName, Mods),
        ModifiesHead =.. [ModifiesName, Mem], !, 
        add_time_unconditional(t, ModifiesHead, ModifiesHeadT),
        add_time_unconditional(t, Step1, Step2),
        ModifiesRule = rule(head(ModifiesHeadT), body([time(t), Step2])),
        add_time_unconditional(t, Effect, EffectT),
        add_time_unconditional(t1, Effect, EffectT1),
        index_of(Mem, Args1, Index),
        element_at_index(Index, Args, MemElement),
        ModifiesHead1 =.. [ModifiesName, MemElement],
        add_time_unconditional(t, ModifiesHead1, ModifiesT),
        InertiaRule = rule(head(EffectT1), body([time(t), time(t1), next_time(t, t1), EffectT, not(ModifiesT)])), !,
        Rules = [ModifiesRule, InertiaRule].

project_into_time(Rules) :-
        findall(Prop, (node_property(Prop), fluent(Prop)), Properties), 
        project_into_time_helper(Properties, Rules).


project_into_time_helper([H|T], Rules) :-
         signature(H, Arity, Domains), 
         retractall(symcount(_, _)), 
         gensym(x, _), 
         length(List, Arity), !, 
         maplist(gensym, List, Syms), !, 
         Head =.. [H|Syms],
         add_time_unconditional_constant(t1, Head, Headt1),
         map_domains(Domains, Syms, Doms),
         Rule = rule(head(Headt1), body([Head|Doms])),
         project_into_time_helper(T, R),
         append([Rule], R, Rules).

map_domains([Dom|D],[Arg|A], Domains) :-
        Term =.. [Dom, Arg],
        map_domains(D, A, R),
        append([Term], R, Domains).    

map_domains([], [], []).


project_into_time_helper([], []).


node_property_dummy_rule(Property, Dummy) :-
        signature(Property, Arity, _),
        retractall(symcount(_, _)),
        length(Args, Arity),
        gensym(x, _),
        maplist(gensym, Args, Syms),
        Head =.. [Property|Syms],
        Dummy = rule(head(Head), body([])).

node_property_eq_rules(Rules) :-
       findall(X, node_property(X), Properties),
       maplist(node_property_dummy_rule, Properties, DummyRules),
       maplist(gen_eq_rules, DummyRules, EqRules),
       flatten(EqRules, EqRules1),
       remove_duplicates(EqRules1, Rules).


assert_constructor_as_start :-
          constructor(X),
          assert(start(X)).


has_definition(Name, [H|_]) :- 
          H = rule(head(Head), _),
          Head =.. [Name|_].

has_definition(Name, [H|T]) :-
          H = rule(head(Head), _),
          Head =.. [Name1|_],
          Name \= Name1,
          has_definition(Name, T).

has_definition(Name, [H|T]) :-
          H \= rule(_, _),
          has_definition(Name, T).

rewrites(X) :-  base_theory(T), maplist(rewrite_rule, T, X).
 
reset_metadata :- cleanup, base_theory(_).

format_constructor(RulesFmt) :-
      rewrites(Rewrites),
      % reset_metadata,
      assert_constructor_as_start,
      start(Start),
      get_rules_by_name(Start, Rewrites, Rules),
      format_constructor_rules(Rules, RulesFmt).


get_rules_by_name(Name, [H|T], Rules) :-
          H = rule(head(Head), _),
          Head =.. [Name|_],
          get_rules_by_name(Name, T, R),
          append([H], R, Rules).

get_rules_by_name(Name, [H|T], Rules) :-
          (H \= rule(head(Head), _) ;
            H = rule(head(Head), _),
            Head =.. [Name1|_],
            Name \= Name1),
          get_rules_by_name(Name, T, Rules).

get_rules_by_name(_, [], []).

get_rules_by_names([H|T], Rules, FilteredRules) :-
        get_rules_by_name(H, Rules, Filtered),
        get_rules_by_names(T, Rules, Filtered2),
        append(Filtered, Filtered2, FilteredRules).

get_rules_by_names([], _, []).


format_constructor_rules([H|T], RulesFmt) :-
        format_constructor_rule(H, Fmt),
        find_nonterminals(H, Nonterminals),
        remove_duplicates(Nonterminals, Nonterminals1),
        assert_nonterminals(Nonterminals1),
        fresh_nonterminals([H|T], Nonterminals1, Nonterminals2),
        rewrites(Rewrites),
        get_rules_by_names(Nonterminals2, Rewrites, NonterminalRules),
        append(T, NonterminalRules, MoreRules),
        format_constructor_rules(MoreRules, Fmt2),
        append([Fmt], Fmt2, RulesFmt).


fresh_nonterminals(Rules, [H|T], N) :-
          name_in_rules(H, Rules),
          fresh_nonterminals(Rules, T, N).

fresh_nonterminals(Rules, [H|T], N) :-
          not(name_in_rules(H, Rules)),
          fresh_nonterminals(Rules, T, N1),
          append([H], N1, N).

fresh_nonterminals(_, [], []).

name_in_rules(Name, [H|_]) :-
        H = rule(head(Head), _),
        Head =..[Name|_].

name_in_rules(Name, [H|T]) :-
        H = rule(head(Head), _),
        Head =..[Name2|_],
        Name \= Name2, 
        name_in_rules(Name, T).


format_constructor_rules([], []).  


format_constructor_rule(Rule, RuleFmt) :-
        Rule = rule(head(Head), body(Body)), 
        append([Head], Body, Lit), 
        maplist(domain_info, [Head|Body], Doms),
        flatten(Doms, Doms1),
        append(Lit, Doms1, Literals),
        maplist(format_constructor_term, Literals, [Head1|Body1]),
        flatten(Body1, Body2),
        remove_duplicates(Body2, Body3),
        RuleFmt = rule(head(Head1), body(Body3)).


domain_info(Term, Domains) :-
        lint_negation(Term, Term2),
        Term2 =.. [Name|Args],
        signature(Name, _, Doms),
        map_domains(Doms, Args, Domains).


format_constructor_term(Term, Term2) :- 
          Term =.. [Name|Args],
          maplist(format_constructor_arg, Args, Args1), 
          Term2 =.. [Name|Args1].


format_constructor_arg(constant(X), X).
format_constructor_arg([], []) :- !.
format_constructor_arg(X, Xs) :-
             X = [_|_], !,
             maplist(format_constructor_arg, X, Xs). 
format_constructor_arg(X, var(X)) :-
             X \= constant(_),
             X \= [_|_].
           

find_nonterminals(Rule, Nonterminals) :-
         Rule = rule(head(_), body(Body)),
         maplist(get_name, Body, Names),
         maplist(is_nonterminal, Names, Results),
         remove(false, Results, Nonterminals).

is_nonterminal(X, false) :-
         is_primitive(X).

is_nonterminal(X, X) :-
          not(is_primitive(X)).

is_primitive(X) :-
       not(has_definition(X)).

has_definition(X) :-
        rule_base(head(H), _), % rule_base is the original rule from base theory
        H =.. [X|_].       

assert_base_theory([H|T]) :-
      H = rule(head(Head), body(Body)),
      assert(rule_base(head(Head), body(Body))),
      assert_base_theory(T).

assert_base_theory([H|T]) :-
      H = constraint(Body),
      assert(constraint_base(Body)),
      assert_base_theory(T).

assert_base_theory([]).


assert_nonterminals([H|T]) :-
        assert(nonterminal(H)),
        assert_nonterminals(T).

assert_nonterminals([]).




:- dynamic causes/2.
:- dynamic modifies/2.
:- dynamic node_property/1.
:- dynamic start/1.
:- dynamic rule/2.
:- dynamic rule_base/2.
:- dynamic constraint_base/1.
:- dynamic nonterminal/1.
domain(node).
domain(time).
domain(num).
domain(key).
domain(round).
domain(int).
domain(color).
domain(tag).


background_theory(node, node_theory).
background_theory(num, num_theory).


operation(list, insert).
operation(list, delete).

operation(ext_tree, insert_ext_tree).
operation(ext_tree, delete_ext_tree).
operation(ext_tree, left_rotate).
operation(ext_tree, right_rotate).



%primitive_write_step(list, link).
%primitive_write_step(ext_tree, link_left).
%primitive_write_step(ext_tree, link_right).
%primitive_write_step(tree, link_left).
%primitive_write_step(tree, link_right).


%primitive_write_step(rb_tree, link_left).
%primitive_write_step(rb_tree, link_right).
%primitive_write_step(rb_tree, change_color).
%primitive_write_step(rb_tree, change_tag).


modifies(list, x, link(x,y)).
modifies(ext_tree, x, link_left(x,y)).
modifies(ext_tree, x, link_right(x,y)).
modifies(tree, x, link_left(x,y)).
modifies(tree, x, link_right(x,y)).

modifies(rb_tree, x, link_left(x,y)).
modifies(rb_tree, x, link_right(x,y)).
modifies(rb_tree, x, change_color(x,c)).
modifies(rb_tree, x, change_tag(x, z)).

causes(list, edge(x,y), link(x,y)).
causes(ext_tree, left(x,y), link_left(x,y)).
causes(ext_tree, right(x,y), link_right(x,y)).
causes(tree, left(x,y), link_left(x,y)).
causes(tree, right(x,y), link_right(x,y)).


causes(rb_tree, left(x,y), link_left(x,y)).
causes(rb_tree, right(x,y), link_right(x,y)).
causes(rb_tree, color(x,c), change_color(x,c)).
causes(rb_tree, tag(x,z), change_tag(x,z)).

symbol_prefix(node, node_).
symbol_prefix(time, t).
symbol_prefix(key, k).
symbol_prefix(num, n).

:- dynamic node_property/1.
:- discontiguous node_property1/1.

node_property(edge).
node_property(key).

%time_dependent(edge, 3).
%time_dependent(list, 2).
%time_dependent(suffix, 2).
%time_dependent(reachable, 2).
%time_dependent(present, 2).
%time_dependent(lst, 1).

%time_dependent(left, 3).
%time_dependent(right, 3).
%time_dependent(external, 2).
%time_dependent(internal, 2).
%time_dependent(parent, 3).
%time_dependent(leaf, 2).
%time_dependent(visited, 3).
%time_dependent(inorder_successor, 3).
%time_dependent(height_left, 3).
%time_dependent(height_right, 3).
%time_dependent(height, 3).
%time_dependent(color, 2).
%time_dependent(sibling, 3).
%time_dependent(tag, 2).
%time_dependent(child, 2).
%time_dependent(weight, 2).
%time_dependent(weight_left, 2).
%time_dependent(weight_right, 2).
%time_dependent(weight_edge,3).

%time_dependent(black_height_left, 3).
%time_dependent(black_height_right, 3).

constants(root, node).

constants(h, node).
constants(t, node).
%constants(kh, num).
%constants(kt, num).
%constants(target, node).
%constants(ktarget, num).
constants(nil, node).
constants(root, node).
%constants(internal, node).
%constants(kinternal, num).
constants(black, color).
constants(red, color).
constants(none, tag).
constants(tagged, tag).


terminal_node_symbol(t).
terminal_node_symbol(nil).

%signature(lst, 1, [time]).
%signature(list, 1, [time]).
%signature(suffix, 2, [node, time]).
%signature(reachable, 2, [node, time]).
%signature(admissible, 2, [node, time]).
%signature(edge, 3, [node, node, time]).
%signature(key, 2, [node, num]).
%signature(admissible, 1, [time]).
%signature(present, 2, [key, time]).
%signature(link, 3, [node, node, time]).
%signature(read, 2, [node, time]).
%signature(lt, 2, [num, num]).
%signature(descendant, 4, [node, node, constant, time]).
%signature(descendant, 3, [node, node, time]).
%signature(left, 3, [node, node, time]).
%signature(right,  3, [node, node, time]).	
%signature(eq_node, 2, [node, node]).
%signature(not_eq_node, 2, [node, node]).
%signature(eq_num, 2, [num, num]).
%signature(not_eq_num, 2, [num, num]).
%signature(gt, 2, [num, num]).
%signature(eq, 2, [node, node]).
%signature(height_left, 3, [node, int, time]).
%signature(height_right, 3, [node, int, time]).
%signature(height, 3, [node, int, time]).
%signature(lt_int, 2, [int, int]).
%signature(sibling, 3, [node, node, time]).
%signature(tag, 2, [node, tag]).
  
%signature(black_height_left, 2, [node, int]).
%signature(black_height_right, 2, [node, int]).
%signature(color, 2, [node, color]).

%signature(link_left, 3, [node, node, time]).
%signature(link_right, 3, [node, node, time]).
%signature(change_color, 3, [node, color, time]).
%signature(left, 3, [node, node, time]).
%signature(right, 3, [node, node, time]).
%signature(descendant, 4, [node, node, constant, time]).
%signature(external, 2, [node, time]).
%signature(internal, 2, [node, time]).
%signature(parent, 3, [node, node, time]).
%signature(leaf, 2, [node, time]).
%signature(visited, 3, [node, node, time]).
%signature(inorder_successor, 3, [node, node, time]).
%signature(change_tag, 3, [node, tag, time]).
%signature(child, 3, [node, node, time]).
%signature(weight, 3, [node, int, time]).
%signature(weight_left, 3, [node, int, time]).
%signature(weight_right, 3, [node, int, time]).
%signature(weight_edge, 4, [node, node, int, time]).
%signature(int_gt, 2, [node, int]).
%signature(int_gte, 2, [node, int]).
%signature(sum, 3, [int, int, int]).

%signature(reachable(_), [node]).
%signature(key(_, _), [node, num]).
%signature(edge(_,_), [node, node]).
%signature(suffix(_), [node]).
%signature(link(_, _), [node, node]).
%signature(lt(_,_), [num, num]).
%signature(present(_), [num]).
%signature(external(_), [node]).
%signature(internal(_), [node]).
%signature(left(_,_), [node, node]).
%signature(right(_,_),[node, node]).
%signature(eq_node(_, _), [node, node]).
%signature(not_eq_node(_, _), [node, node]).
%signature(eq_num(_, _), [num, num]).
%signature(not_eq_num(_, _), [num, num]).
%signature(gt(_,_), [num, num]).
%signature(parent(_,_), [node, node]).
%signature(inorder_successor(_,_), [node, node]).
%signature(height_left(_, _), [node, int]).
%signature(height_right(_, _), [node, int]).
%signature(height(_, _), [node, int]).
%signature(lt_int(_, _), [int, int]).
%signature(color(_, _), [node, color]).
%signature(sibling(_, _), [node, node]).
%signature(tag(_, _), [node, tag]).
%signature(descendant(_, _, left), [node, node]).
%signature(descendant(_, _, right), [node, node]).
%signature(leaf(_), [node]).
%signature(visited(_, _), [node, node]).
%signature(child(_, _), [node, node]).
%signature(weight_left(_, _), [node, int]).
%signature(weight_right(_, _), [node, int]).
%signature(weight(_, _), [node, int]).
%signature(weight_edge(_, _, _), [node, node, int]).
%signature(int_gt(_,_), [int, int]).
%signature(int_gte(_, _), [int, int]).
%signature(sum(_,_,_), [int, int, int]).

max_steps(5).

% domains are never preconditions
% preconditions are time-dependent predicates
preconditions(reachable).
preconditions(admissible).
preconditions(edge).
preconditions(present).
preconditions(descendant).
preconditions(external).
preconditions(internal).

write_operation(list, insert, [node(target)]).
write_operation(list, delete, [node(target)]).

write_operation(ext_tree, insert_ext_tree, [node(target)]).
write_operation(ext_tree, delete_ext_tree, [node(target)]).
write_operation(ext_tree, left_rotate, _).
write_operation(ext_tree, right_rotate, _).




write_operation(rb_tree, add, [node(target)]).
write_operation(rb_tree, remove, [node(target)]).
write_operation(rb_tree, red_red_resolve, _).
%write_operation(rb_tree, left_rotate, _).
%write_operation(rb_tree, right_rotate, _).



:- dynamic ds/1.

% time is implicit
code(list, insert, [target], block1, 
     [reachable(x), edge(x, y), not(reachable(target)), key(x, kx), key(y, ky), 
      key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)],
     [link(x,target),link(target,y)],
     [reachable(target)]
    ).


code(list, delete, [target], block1,
     [reachable(x), edge(x, target), edge(target, y) , key(x,kx), 
      key(y, ky), key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)],
     [link(x,y)],
    [not(reachable(target))]  
   ).

next_node(list,x,(y, [edge(x, y)])).
end_node(list, t).
next_node(list, t, t).


start_node(rb_tree, root).
end_node(rb_tree, nil).
next_node(rb_tree,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb_tree,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb_tree, nil, nil).


start_node(avl_nurmi, root).
end_node(avl_nurmi, nil).
next_node(avl_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(avl_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(avl_nurmi, nil, nil).



start_node(nurmi, root).
end_node(nurmi, nil).
next_node(nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(nurmi, nil, nil).


start_node(list, h).

start_node(tree, root).
end_node(tree, nil).

start_node(ext_tree, root).
end_node(ext_tree, nil).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(ext_tree, nil, nil).
next_node(tree,target, x,(z,[key(x, kx),  key(target, ktarget), left(x, z), lt(ktarget, kx)])).
next_node(tree,target, x,(z,[key(x, kx),  key(target, ktarget), right(x, z), lt(kx, ktarget)])).
% next_node(tree,target,  nil, nil).

start_node(rb_nurmi, root).
end_node(rb_nurmi, nil).
next_node(rb_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb_nurmi, nil, nil).

start_node(rb, root).
end_node(rb, nil).
next_node(rb,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb, nil, nil).
 

max_depth(6).

%class_ebst([node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, nil), right(c, nil), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, nil), right(f, nil), key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%            num(kb), num(kc), num(kd), num(ke), num(kf)]).

%class(ext_tree, [node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, i), right(c, j), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, g), right(f, h1), left(g, nil), right(g, nil),
%            left(i, nil), right(i, nil), left(j, nil), right(j, nil),
%            left(h1, nil), right(h1, nil), node(g), node(h1), node(i), node(j),
%             key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%             key(g, kg), key(h1, kh1), key(i, ki), key(j, kj),
%            num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh1), num(ki), num(kj)]).


%class(tree, [node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, i), right(c, j), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, g), right(f, h1), left(g, nil), right(g, nil),
%            left(i, nil), right(i, nil), left(j, nil), right(j, nil),
%            left(h1, nil), right(h1, nil), node(g), node(h1), node(i), node(j),
%             key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%             key(g, kg), key(h1, kh1), key(i, ki), key(j, kj),
%            num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh1), num(ki), num(kj)]).


%class(list, [node(a), node(b), node(c), node(d), edge(a, b), edge(b, c), edge(d, kd), key(a, ka), key(b, kb), key(c, kc), key(d, kd),
%            num(ka), num(kb), num(kc), num(kd), node(h), node(t), key(h, kh), key(t, kt), num(kh), num(kt)]).


class_list([node(a), node(b), node(c), node(d), edge(a, b), edge(b, c), edge(d, kd), key(a, ka), key(b, kb), key(c, kc), key(d, kd),
            num(ka), num(kb), num(kc), num(kd), node(h), node(t), key(h, kh), key(t, kt)]).

%         root
%        /   \
%       a     b
%      / \   / \
%      c  d  e   f
%     /\  /\ \  /\ 
%     g h i j l m n

class(tree, [left(root, a),  right(root, b), 
left(a, c), right(a, d),
left(b, e), right(b, f),
left(c, g), right(c, h),
left(d, i), right(d, j),
left(e, k), right(e, l),
left(f, m), right(f, n),
left(g, nil), right(g, nil),
left(h, nil), right(h, nil),
left(i, nil), right(i, nil),
left(j, nil), right(j, nil),
left(k, nil), right(k, nil),
left(l, nil), right(l, nil),
left(m, nil), right(m, nil),
left(n, nil), right(n, nil),
node(g), num(kg), key(g, kg),
node(h), num(kh), key(h, kh),
node(i), num(ki), key(i, ki),
node(j), num(kj), key(j, kj),
node(k), num(kk), key(k, kk),
node(l), num(kl), key(l, kl),
node(m), num(km), key(m, km),
node(n), num(kn), key(n, kn),
node(f), num(kf), key(f, kf),
node(e), num(ke), key(e, ke),
node(d), num(kd), key(d, kd),
node(c), num(kc), key(c, kc),
node(b), num(kb), key(b, kb),
node(a), num(ka), key(a, ka),
node(nil)]).


%class(tree, [left(root, a),  right(root, b), 
%left(a, c), right(a, d),
%left(b, e), right(b, f),
%left(c, g), right(c, h),
%left(d, i), right(d, j),
%left(e, k), right(e, l),
%left(f, m), right(f, n),
%left(g, nil), right(g, nil),
%left(h, nil), right(h, nil),
%left(i, nil), right(i, nil),
%left(j, nil), right(j, nil),
%left(k, nil), right(k, nil),
%left(l, nil), right(l, nil),
%left(m, nil), right(m, nil),
%left(n, nil), right(n, nil),
%node(g), num(kg), key(g, kg),
%node(h), num(kh), key(h, kh),
%node(i), num(ki), key(i, ki),
%node(j), num(kj), key(j, kj),
%node(k), num(kk), key(k, kk),
%node(l), num(kl), key(l, kl),
%node(m), num(km), key(m, km),
%node(n), num(kn), key(n, kn),
%node(f), num(kf), key(f, kf),
%node(e), num(ke), key(e, ke),
%node(d), num(kd), key(d, kd),
%node(c), num(kc), key(c, kc),
%node(b), num(kb), key(b, kb),
%node(a), num(ka), key(a, ka),
%node(nil)]).

invariant(list, [lst]).
invariant(ext_tree, [not(violate_order), not(ext_tree)]).

time_dependent_node_property(list, edge).
time_dependent_node_property(ext_tree, left).
time_dependent_node_property(ext_tree, right).

time_dependent_node_property(int_tree, left).
time_dependent_node_property(int_tree, right).

%class(rb_tree, [
%   left(root, a), right(root, b),
%   left(a, c), right(a, d),
%   left(b, e), right(e, f),
%   left(c, g), right(c, nil),
%   left(d, nil), right(d, nil),
%   left(e, nil), right(e, nil),
%   left(f, nil), right(f, nil),
%   left(g, nil), right(g, nil),
%   node(a), node(b), node(c), node(d), node(e), node(f), node(g),
%   node(target),
%   color(root, black),
%   color(a, black),
%   color(b, black),
%   color(c, black),
%   color(d, black),
%   color(e, black),
%   color(f, black),
%   color(g, red),
%   key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),
%   key(g, kg), key(target, ktarget),
%   num(ka), num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(ktarget),
%   tag(a, none), tag(b, none), tag(c, none), tag(d, none), tag(e, none), tag(f, none), tag(g,none)
%  ]). 

class(rb_tree, [
    left(root, a), right(root, b),
    left(a, c), right(a, d),
    left(b, e), right(b, f),
    left(c, g), right(c, h),
    left(d, nil), right(d, nil), 
    left(e, nil), right(e, nil),
    left(f, i), right(f, j),
    left(g, nil), right(g, nil),
    left(h, k), right(h, l),
    left(i, m), right(i, n),
    left(j, nil), right(j, nil),
    left(h, k), right(h, l),
    left(m, nil), right(m, nil),
    left(n, nil), right(n, nil),
    left(k, nil), right(k, nil),
    left(l, nil), right(l, nil),
    node(a), node(b), node(c), node(d), node(e), node(f), node(g), node(h), node(i), node(j), node(k), 
    node(l), node(m), node(n), 
    color(root, black), 
    color(a, black),
    color(b, black),
    color(c, red),
    color(d, black),
    color(e, black),
    color(f, red),
    color(g, black),
    color(h, black),
    color(i, red),
    color(j, black),
    color(k, red),
    color(l, red),
    color(m, black),
    color(n, black),
    tag(a, none), tag(b, none), tag(c, none), tag(d, none), tag(e, none), tag(f, tagged), tag(g, none), tag(h, none), 
    tag(i, none), tag(j, none), tag(k, none), tag(l, none), tag(m, none), tag(n, none),  
    num(ka), num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh), num(ki), num(kj), num(kk), num(kl), 
    num(km), num(kn), 
    key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf), key(g, kg), key(h, kh), key(i, ki), 
    key(j, kj), key(k, kk), key(l, kl), key(m, km), key(n, kn) 

  ]).

:- dynamic symbol_count/2.

init_counts :- 
     findall(D, domain(D), List),
     init_counts(List).

init_counts([H|T]) :-
     assert(symbol_count(H, 0)),
     init_counts(T).

init_counts([]).


reset_counts :- 
      findall(D, domain(D), List),
      reset_counts(List).

reset_counts(List) :-
       reset_counts_helper(List),
       init_counts(List).

reset_counts_helper([H|T]) :-
       retractall(symbol_count(H, _)),
       reset_counts_helper(T).

reset_counts_helper([]).

generate_symbol(Domain, Symbol) :-
     symbol_prefix(Domain, Prefix),
     symbol_count(Domain, Count),
     Count1 is Count + 1,
     term_string(Prefix, PrefixString),
     term_string(Count1, CountString),
     string_concat(PrefixString, CountString, SymbolString),
     term_string(Symbol, SymbolString),
     retractall(symbol_count(Domain, _)),
     assert(symbol_count(Domain, Count1)).


initial_time_symbol(t1).


check_rcu :- 
  detect_key_movementV2(X),
  X = true.

check_rcu :-
  ds(DS),
  code(DS, Op, _, Block, _, _, _),
  not(check_reorder(Op, Block)).

program_orders(Orders) :-
    ds(DS),
    findall((Op,Block), code(DS, Op, _, Block, _, _, _), List),
    get_valid_program_orders(List, Orders).

get_valid_program_orders([H|T], [(Op,Block,Order)|Orders]) :-
      H = (Op, Block),
      check_reorder(Op, Block, Order),
      get_valid_program_orders(T, Orders).

get_valid_program_orders([], []).

lock_stmts([H|T], [lock(H)|R]) :-
      lock_stmts(T, R).

lock_stmts([], []).

unlock_stmts([H|T], [unlock(H)|R]) :-
      unlock_stmts(T, R).

unlock_stmts([], []).

validate_cond(Pre, Steps, (if(Pre), Steps)).

gen_concurrent_code(Op, Block, Code2) :-
    check_reorder(Op, Block, Order), !, 
    ds(DS),
    code(DS, Op, _, Block, Pre, _, _),
    get_nodes(Pre, Nodes),
    lock_stmts(Nodes, Locks),
    unlock_stmts(Nodes, Unlocks),
    validate_cond(Pre, Order, CondCode),
    append(Locks, [CondCode], Code),
    append(Code, Unlocks, Code2).

whitespace(Intent, Str) :-
     whitespace(Intent, '', Str).

whitespace(0, P, P).

whitespace(Indent, P, S) :-
       Indent > 0,
       Indent1 is Indent - 1,
       string_concat(P, ' ', P1),
       whitespace(Indent1, P1, S).

gen_text(Code, Text) :- 
    gen_text(Code, 0, '', Text).

gen_text([], _, P, P).

gen_text([Step|T], Indent, P, Text) :-
       Step \= (if(_),_),
       whitespace(Indent, W),
       term_string(Step, S),
       string_concat(W, S, P1),
       string_concat(P1, '\n', P2),
       string_concat(P, P2, P3),
       gen_text(T, Indent, P3, Text).

to_text(if(Pre), S1) :-
        conjunct_text(Pre, Pres),
        string_concat('if validate(', Pres, S),
        string_concat(S, '){\n', S1).

conjunct_text([H], S) :-
        term_string(H, S).

conjunct_text([H|T], S) :-
       term_string(H, Hs), 
       string_concat(Hs, ' & ', Hs1),
       conjunct_text(T, Ts),
       string_concat(Hs1, Ts, S).

gen_text([(if(Pre), Steps)|T], Indent, P, Text) :-
       to_text(if(Pre), S1),
       Indent1 is Indent + 2,
       gen_text(Steps, Indent1, '', Text1),
       string_concat(S1, Text1, Text2),
       string_concat(Text2, '\n}\n', Text3),
       gen_text(T, Indent, Text3, Text4),
       string_concat(P, Text4, Text).

:- dynamic node_property/1.
:- discontiguous node_property/1.


synth :- 
   %input_path(Input),
   %string_concat(Input, 'seq.pl', Seq),
   %consult(Seq),
   current_prolog_flag(argv, Argv),
   Argv = [_, DS1, TheoryPath, SeqPath, TypeOf],
   write(Argv),
   %TheoryPath = './input/list.lp',
   %SeqPath = './seq/list.pl', 
   %TypeOf = list,
   %DS = list,
   (TypeOf \= list, TypeOf \= tree, TypeOf \= int_tree ->  write('Please provide a valid type: tree or list, nothing else'), exit; true),
   assert(type_of(TypeOf)),
   assert(input_path(TheoryPath)),
   assert(knowledge_path(SeqPath)),
   consult(SeqPath),
   term_string(DS, DS1),
   set_ds(DS),
   write('\nFinding maximally applicable instance ....'),
   pick_instance(X), assert(class(DS, X)),
   write('\nSuccess! Found maximally applicable instance!'),
   op_blocks(OpBlocks), remove_duplicates(OpBlocks, OpBlocks1),
   write('\nChecking Lock Adequacy....'),
   check_adequacyV2, 
   write('\n Locks are adequate!'),
   write('\nProceeding to check for vaild program order and key movement'),
   (not(check_rcu) ->   synth(OpBlocks) 
                    ; write('Can recommend only RCU/Coarse-Grain Synrhonization')), 
   exit.

synth([(Op,Block)|T]) :-
    % check_adequacy(Op, Block, true),
    write(Op), 
    write('::'),
    write(Block),
    write('{\n'),
    gen_concurrent_code(Op, Block, Code),
    gen_text(Code, Text),
    write(Text), 
    write('\n}\n'),
    synth(T).

synth([]).

% :- initialization(main, main).
:- dynamic ds/1.
:- dynamic count/2.


count(node, 0).

gen_nodename(Node) :-
    count(node, X),
    term_string(node, N),
    term_string(X, Xs),
    string_concat(N, Xs, Ns),
    term_string(Node, Ns),
    retract(count(node, X)),
    X1 is X + 1,
    assert(count(node, X1)).

gen_heapnodes(list, Length, [h|Nodes]) :- 
      gen_heapnodes(list, Length, 0, Nodes).

gen_heapnodes(list, L, P, [Node|Nodes]) :-
        P < L, !, 
        P1 is P + 1, 
        gen_nodename(Node), !,  
        gen_heapnodes(list, L, P1, Nodes).

gen_heapnodes(list, L, L, [t]).


gen_heap_edges(list, L, Edges) :-
      gen_heapnodes(list, L, Nodes),
      gen_heap_edges_helper(list, Nodes, Edges1),
      maplist(assert_edge, Edges1, _),
      Edges = [node(h)|Edges1],
      assert(heap_term(node(h))),
      assert(node(h)),
      maplist(assert_heap_term, Edges, _).
     
gen_heap_edges_helper(list, [X,Y|T], [edge(X,Y)|Edges]) :-
        gen_heap_edges_helper(list, [Y|T], Edges).

gen_heap_edges_helper(list, [_], []).
 
count(heap_term, 1).

assert_edge(Edge, []) :- assert(Edge).
assert_heap_term(Term, []) :- 
      ds_instance(DS), count(heap_term, X),
       X1 is X + 1, assert(heap(DS, X, Term)), 
       assert(heap_term(Term)),
       retract(count(heap_term, X)), assert(count(heap_term, X1)).

gen_heap_edges(tree, Max, Edges) :-
      gen_heap_edges_queue(tree, Max, 1, [root], none, [], Edges1), 
      maplist(assert_edge, Edges1, _),
      Edges = [root(root)|Edges1],
      assert(heap_term(root(root))),
      assert(root(root)),
      maplist(assert_heap_term, Edges, _).


gen_heap_edges_queue(tree, Max, Curr, [H|T], PrevEdge, PartialEdges, Edges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, CurrOut, PrevEdge, NewEdges),
       NewEdges = [left(H, L), right(H, R)|_],
       append(PartialEdges, NewEdges, PartialEdges1),
       append(T, [L, R], T1),
       gen_heap_edges_queue(tree, Max, CurrOut, T1, right(H, R), PartialEdges1, Edges).

gen_heap_edges_queue(tree, Max, Curr, [H|T], PrevEdge, PartialEdges, Edges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, CurrOut, PrevEdge, NewEdges),
       NewEdges = [left(H, L)|_],
       append(PartialEdges, NewEdges, PartialEdges1),
       append(T, [L], T1),
       gen_heap_edges_queue(tree, Max, CurrOut, T1, left(H, L),  PartialEdges1, Edges).


gen_heap_edges_queue(tree, Max, Curr, [H|_], PrevEdge, PartialEdges, PartialEdges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, _, PrevEdge, []).
       

gen_heap_edges_queue(tree, Max, Max, _, _,  PartialEdges, PartialEdges).


gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = none, 
          Curr < Max, 
          gen_nodename(Left),
          CurrOut is Curr + 1,
          CurrOut = Max,
          (weighted(false) -> Edges = [left(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [left(Node, Left), weight_left(Node, W1)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = none, 
          Curr < Max, 
          gen_nodename(Left),
          Curr1 is Curr + 1,
          Curr1 < Max,
          gen_nodename(Right),
          CurrOut is Curr1 + 1,
          (weighted(false) -> Edges = [left(Node,Left), right(Node, Right)] ;
                              random(-10, 10, W1), random(-10, 10, W2), 
                              Edges = [left(Node,Left), right(Node, Right), weight_left(Node, W1), weight_right(Node, W2)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = right(Node1, _), 
          Node \= Node1,
          Curr < Max, 
          gen_nodename(Left),
          Curr1 is Curr + 1,
          Curr1 < Max,
          gen_nodename(Right),
          CurrOut is Curr1 + 1,
          (weighted(false) -> Edges = [left(Node,Left), right(Node, Right)] ;
                              random(-10, 10, W1), random(-10, 10, W2), 
                              Edges = [left(Node,Left), right(Node, Right), weight_left(Node, W1), weight_right(Node, W2)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = right(Node1, _), 
          Node \= Node1,
          Curr < Max, 
          gen_nodename(Left),
          CurrOut is Curr + 1,
          CurrOut = Max,
          (weighted(false) -> Edges = [left(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [left(Node, Left), weight_left(Node, W1)]).




gen_heap_edges(tree, Node, Max, Max, Max, PrevEdge, []) :-
          PrevEdge = right(Node1, _),
          Node \= Node1.



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = left(Node, _),
          Curr < Max, 
          gen_nodename(Right),
          CurrOut is Curr + 1,
          (weighted(false) -> Edges = [right(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [right(Node, Left), weight_right(Node, W1)]).


gen_heap_edges(tree, Node, Max, Max, Max, PrevEdge, []) :-
          PrevEdge = left(Node, _).



%heap(tree, 1, root(root)).
%heap(list, 1, node(h)).


%heap(tree, 1, root(a)).
%heap(tree, 2, left(a,b)).
%heap(tree, 3, right(a,c)).
%heap(tree, 4, left(b,d)).
%heap(tree, 5, right(b,e)).
%heap(tree, 6, left(c,f)).
%heap(tree, 7, right(c,g)).


%heap(list, 1, node(a)).
%heap(list, 2, edge(a, b)).
%heap(list, 3, edge(b, c)).
%heap(list, 4, edge(c, d)).

:- dynamic root/1.
:- dynamic left/2.
:- dynamic right/2.
:- dynamic heap_term/1.
:- dynamic edge/2.
:- dynamic node/1.

assert_heap(Iteration) :- 
         ds_instance(DS),
         heap(DS, Iteration, X),
         assert(X),
         assert(heap_term(X)),
         Iteration1 is Iteration - 1,
         assert_heap(Iteration1).

assert_heap(1) :- 
          ds_instance(DS),
          heap(DS, 1, X), assert(X), assert(heap_term(X)).


left(X) :- left(X, _).
right(X) :- right(X, _).


list_order(List) :- node(X), list_order(X, List), !.
list_order(X, [X|R]) :- edge(X, Y), list_order(Y, R), !.
list_order(X, [X]) :- not(edge(X,_)).

inorder(List) :- root(X), inorder_rec(X, [], List).
inorder_rec(X, ListIn, List2) :- left(X, Y), right(X, Z), inorder_rec(Y, ListIn, List), 
           append(List, [X], List1), inorder_rec(Z, List1, List2).
inorder_rec(X, ListIn, List2 ) :- left(X, Y), not(right(X)), 
          inorder_rec(Y, ListIn, List1), append(List1, [X], List2).
inorder_rec(X, ListIn, List2) :- 
       right(X, Y), not(left(X)), append([X], ListIn, List1), inorder_rec(Y, List1, List2). 
inorder_rec(X, ListIn, List) :-
           not(left(X)), not(right(X)), append(ListIn, [X], List).

key(X, KX) :- term_string(X, Xs), string_concat("k", Xs, Ks), term_string(KX, Ks).


gen_terms([H], [node(H), key(H, KH), num(KH)]) :- key(H, KH).
gen_terms([A, B|T], [node(A), key(A, KA), num(KA), lt(KA, KB)|R]) :-
          key(A, KA), key(B, KB), gen_terms([B|T], R).


facts(List, Str) :- facts(List, "\n", Str).
facts([H|T], S, Str) :- 
      term_string(H, Hs), string_concat(Hs, ".\n", Hs1),  
      string_concat(S, Hs1, S1), facts(T, S1, Str).
facts([], S, S).


construct_nodes([H|T], [node(H)|R]) :-
        construct_nodes(T, R).

construct_nodes([], []).

pair_nodes_keys([H|T], [K|T1], [key(H, K)|R]) :-
      pair_nodes_keys(T, T1, R).

pair_nodes_keys([], [], []).

treegen([DS, Iter], Terms2) :-  
      retractall(heap_term(_)),
      retractall(heap(_,_,_)),
      retractall(ds_instance(_)),
      retractall(edge(_,_)),
      retractall(left(_,_)),
      retractall(right(_,_)),
      retractall(node(_)),
      assert(ds_instance(DS)),
      assert(weighted(false)),
      term_string(Iteration, Iter),
      % write(Iteration),
      gen_heap_edges(DS, Iteration, _), ! ,
      %assert_heap(Iteration), ! ,
      (DS = tree -> inorder(List) ; DS = list -> list_order(List)  ; 
       DS = int_tree -> gen_heapnodes(list, Iter, Nodes),
                        %maplist(key, Nodes, Keys),
                        %construct_nodes(Nodes, Nodes1),
                        %pair_nodes_keys(Nodes, Keys, Keys1),
                        List = Nodes
          ; List = []), 
      gen_terms(List, Terms),
      findall(X, heap_term(X), HeapTerms),
      append(Terms, HeapTerms, Terms2).


gen_heap_edges(int_tree, _, _).

treegen([DS, Iter, Weighted]) :-  
      assert(ds_instance(DS)),
      assert(weighted(true)),
      term_string(Iteration, Iter),
      % write(Iteration),
      gen_heap_edges(DS, Iteration, _), ! ,
      %assert_heap(Iteration), ! ,
      (DS = tree -> inorder(List) ; DS = list -> list_order(List)  ; List = []), 
      gen_terms(List, Terms),
      findall(X, heap_term(X), HeapTerms),
      append(Terms, HeapTerms, Terms2),
      facts(Terms2, Str),
      write(Str),
      add_facts(Str, 'search.lp').



format_command(List, Str) :- 
        format_command(List, "", Str).

format_command([H|T], S, Str) :-
         string_concat(S, H, S1), 
         string_concat(S1, ' ', S2),
         format_command(T, S2, Str).

format_command([], S, S).

add_facts(Str, File) :-  
           string_concat(File, '_heap', Heap), 
           format_command(['cp', File, Heap], Cmd),
           shell(Cmd, _),
           format_command(['printf \'', Str, '\'', '>>', Heap], Cmd2), 
           shell(Cmd2, _).

add_text_to_file(Str, File) :-
          format_command(['printf \'', Str, '\'', '>>', File], Cmd2), 
           shell(Cmd2, _).



unfold2(0, Terms) :-
     start(Start),
     find_rule(Start, Rule), 
     Rule = rule(head(Start), body(Body)),
     vars_of(Body, Vars2),
     % gen_fresh_symbols(Vars2, Body, FreshVars),
     gen_fresh_symbols(Vars2, FreshVars),
     subst_fresh_vars_conjunct(FreshVars, Body, Body1),
     get_nonterminals(Body1, NonTerminals),
     set_diff(Body1, NonTerminals, Terms).   

unfold2_goals([(Pred, CurrentDepth)|T], Depth, [Terms|Terms2]) :-
     find_rule(Pred, Rule), 
     CurrentDepth < Depth,
     Rule = rule(head(Head), body(Body)),
     Head =.. [_|Vars],
     Pred =.. [_|Args],
     pair_symbol_vars(Args, Vars, Pairs),
     subst_fresh_vars_conjunct(Pairs, Body, Body1),
     vars_of(Body1, Vars2),
     % gen_fresh_symbols(Vars2, Body1, Vars3),
     gen_fresh_symbols(Vars2, Vars3),
     subst_fresh_vars_conjunct(Vars3, Body1, Body2),
     get_nonterminals(Body2, NonTerminals),
     set_diff(Body2, NonTerminals, Terms),
     NonTerminals \= [],
     CurrentDepth1 is CurrentDepth + 1,
     pair_list_value(NonTerminals, CurrentDepth1, Goals),
     append(T, Goals, T2),
     unfold2_goals(T2, Depth, Terms2).

:- dynamic count/1.

unfold2(Depth, [Terms|Terms2]) :-
	 Depth > 0, 
	 start(Start),
     find_rule(Start, Rule), 
     Rule = rule(head(Start),body(Body)),
     vars_of(Body, Vars2),
     % gen_fresh_symbols(Vars2, Body, FreshVars),
     gen_fresh_symbols(Vars2, FreshVars),
     subst_fresh_vars_conjunct(FreshVars, Body, Body1),
     get_nonterminals(Body1, NonTerminals),
     set_diff(Body1, NonTerminals, Terms),
     pair_list_value(NonTerminals, 1, Goals),
     unfold2_goals(Goals, Depth, Terms2).   

  
unfold2_goals([(Pred, CurrentDepth)|T], Depth, Terms) :-
     find_rule(Pred, Rule), 
     CurrentDepth < Depth,
     Rule = rule(head(Head), body(Body)),
     Head =.. [_|Vars],
     Pred =.. [_|Args],
     pair_symbol_vars(Args, Vars, Pairs),
     subst_fresh_vars_conjunct(Pairs, Body, Body1),
     vars_of(Body1, Vars2),
     % gen_fresh_symbols(Vars2, Body1, Vars3),
     gen_fresh_symbols(Vars2, Vars3),
     subst_fresh_vars_conjunct(Vars3, Body1, Body2),
     get_nonterminals(Body2, NonTerminals),
     NonTerminals = [],
     unfold2_goals(T, Depth, Terms).   

 unfold2_goals([], _, []).

unfold2_goals([(Pred, Depth)|T], Depth, Terms2) :-
     unfold2_goals(T, Depth, Terms2).


ufold(Depth, T) :-
     unfold2(Depth, Terms), flatten(Terms, T).


gen_fresh_symbols([H|T], [(H, New)|R]) :-
       gensym(H, _), !,
       gensym(H, New), !,
       gen_fresh_symbols(T, R).

gen_fresh_symbols([], []).

flatten([H|T], [H|R]) :-
      H \= [],
      H \= [_|_], !,
      flatten(T, R).

flatten([H|T], R) :-
      H = [], !,
      flatten(T, R).

flatten([H|T], R) :-
      !,
      flatten(H, R1),
      flatten(T, R2),
      append(R1, R2, R).

flatten([], []).


remove_duplicates([H|T],R) :-
         member(H, T), !,
         remove_duplicates(T, R).

remove_duplicates([H|T], [H|R]) :-
          not(member(H, T)), !,
          remove_duplicates(T, R).
    
remove_duplicates([], []).

write_to_file(File, Content) :-
      current_output(PrevStream),
      open(File, write, NewStream),
      set_output(NewStream),
      write(Content),
      set_output(PrevStream),
      close(NewStream).


set_intersect([H|T], List, [H|R]) :-
           member(H, List),
           set_intersect(T, List, R).

set_intersect([H|T], List, R) :-
           not(member(H, List)),
           set_intersect(T, List, R).

set_intersect([], _, []).


replace(X, Y, [X|T], [Y|R]) :-
             replace(X, Y, T, R).

replace(X, Y, [X1|T], [X1|R]) :-
              X \= X1,
              replace(X, Y, T, R).

replace(X, Y, [], []).


 maplist_general(Pred, [H|T], [Result|R]) :-
         append(H, [Result], H1),
         Term =.. [Pred|H1],
         call(Term),
         maplist_general(Pred, T, R).

maplist_general(_, [], []).


set_diff([H|T], List, [H|R]) :-
           not(member(H, List)),
           set_diff(T, List, R).


set_diff([H|T], List, R) :-
          member(H, List),
          set_diff(T, List, R).


set_diff([], _, []).


pair([H|T], [H1|T1], [(H, H1)|R]) :-
             pair(T, T1, R).

pair([], [], []).

conjunct_str([], '').

conjunct_str([H], Str) :-
      term_string(H, Str).


conjunct_str([H|T], Str) :-
      term_string(H, S1),
      string_concat(S1, ',', S2),
      conjunct_str(T, S3),
      string_concat(S2, S3, Str).

list_str([H], H) :- !.

list_str([H|T], Str) :-
      T \= [],
      string_concat(H, ', ', S2),
      conjunct_str(T, S3),
      string_concat(S2, S3, Str).

lint_string(Str, Str2) :-
      string_chars(Str, List),
      remove('"', List, List1),
      string_chars(Str2, List1).


remove(H, [H|T], R) :-
         remove(H, T, R).

remove(H, [X|T], [X|R]) :-
         X \== H, 
         remove(H, T, R).

remove(_, [], []).

rules_str(Rules, Str) :-
     rules_str_helper(Rules, "", Str).

rules_str_helper([H|T], S, S2) :-
         string_concat(H, S, S1),
         rules_str_helper(T, S1, S2).

rules_str_helper([], S, S).


cross_element(X, [H|T], [(X,H)|R]) :-
         cross_element(X, T, R).

cross_element(_, [], []).


choose_2(List, Combinations) :-
      choose_2_helper(List, Combos),
      flatten(Combos, Combinations).

choose_2_helper([H|T], [R|R1])  :-
      pair(H, T, R),
      choose_2_helper(T, R1).

choose_2_helper([], []).


pair_list_value_helper([H|T], Value, [(H, Value)|R]) :-
         pair_list_value_helper(T, Value, R).

pair_list_value_helper([], _, []).

pair_list_value(List, Value, Pairs) :-
        pair_list_value_helper(List, Value, Pairs2),
        flatten(Pairs2, Pairs).

clear :- 
     once(shell(clear, 0)).

b :-
     shell('./merge.sh', _).


build :-
     shell('./merge.sh', _).

set_ds(Val) :-
      retractall(ds(_)),
      assert(ds(Val)).


add_underscore(A, B, C) :-
    string_concat(A, "_", As),
    string_concat(As, B, C).



reduce(List, Op, I, X) :-
      List = [A, B|T], !,
      call(Op, A, B, X1),
      reduce_helper(T, Op, X1, X).

reduce_helper([], Op, P, P).          

reduce_helper([H|T], Op, P, X) :-
         call(Op, P, H, X1),
         reduce_helper(T, Op, X1, X).  

reduce([H], _, _, H) :- !.

          
sum(X, Y, Z) :- Z is X + Y. 

l :- [merge].
bl :- b, l.

exit :- halt.

zip(X, [H|T], [(X,H)|R]) :-
      !, zip(X, T, R).

zip(_, [], []). 


show(LineNo) :-
   term_string(LineNo, S),
   string_concat('head -n ', S, S1),
   string_concat(S1, ' merge.pl | tail -n 1', Cmd),
   shell(Cmd, _).

gen_rounds(Num, Facts) :-
   gen_rounds(Num, [], Facts).


gen_rounds(Num, P, Rules)  :-
       Num > 1,
       Rule = rule(head(round(constant(Num))), body([])), 
       Num1 is Num - 1,
       gen_rounds(Num1, [Rule|P], Rules).

gen_rounds(1, P, Rules) :- 
     Rule = rule(head(round(constant(1))), body([])), 
     Rules = [Rule|P].  


add_space(Str, Str1) :-
     string_concat(Str, ' ', Str1).
 
copy_command(Source, Destination, Cmd) :-
     maplist(add_space, ["cp", Source], Prefix),
     append(Prefix, [Destination], Args),
     reduce(Args, string_concat, "", Cmd).

base_theory_path(Path) :- 
      %ds(DS),
      %ds_file(DSFile),
      %input_path(InputPath),
      %string_concat(InputPath, DSFile, Path),
      input_path(Path). 

ds_file(File) :-
      ds(DS),
      term_string(DS, DS1),
      string_concat(DS1, '.lp', File).


write_rules_to_file(File, Rules) :-
          write_rules(Rules, S),
          rules_str(S, S1),
          write_to_file(File, S1).


add_contents_to_file(File, Contents) :-
       open(File, append, Stream),
       current_output(Curr),
       set_output(Stream),
       write(Contents),
       set_output(Curr),
       close(Stream).

get_name(Term, Name) :-
       Term =.. [Name|_].

assert_list([H|T]) :-
         assert(H),
         assert_list(T).

assert_list([]).


:- dynamic input_path/1.
:- dynamic reasoning_path/1.

% custom reset 
cr :- 
 retractall(input_path(_)),
 retractall(reasoning_path(_)),
 assert(input_path('')),
 assert(reasoning_path('')).


%  cross_product([H|T], )


remove_term(([H|T], Term), [H|R]) :-
        H \= rule(_, _),
        remove_term((T, Term), R).

remove_term(([H|T], Term), R) :-
        H = rule(head(Head), _),
        Head =.. [Term|_],
        remove_term((T, Term), R).

remove_term(([H|T], Term), [H|R]) :-
       H = rule(head(Head), _),
       Head =.. [Name|_],
       Name \= Term,
       remove_term((T, Term), R).


remove_term(([],_), []). 


tuple_list(Tuple, List) :-
     tuple_list(Tuple, [], List).

tuple_list(Tuple, P, List) :-
     Tuple =.. [',', X, Y], !,
     append(P, [X], P1),
     tuple_list(Y, P1, List).

tuple_list(Tuple, P, List) :-
     Tuple =.. [X], !, 
     append(P, [X], List).

tuple_list(Tuple, P, List) :-
       !, append(P, [Tuple], List).

begins_with(Term, Str) :-
       term_string(Term, S),
       string_chars(S, Chars),
       string_chars(Str, Pattern),
       append(Pattern, _, Chars).