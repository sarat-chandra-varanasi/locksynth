

strip_arity('_false_0', false).

strip_arity(Term, Term) :-
	  Term =.. [Name|_],
    operator(Name), !.

strip_arity(Term, Term2) :- 
      Term =.. [Name|Args],
      atom_chars(Name, Chars),
      not(operator(Name)),
      append(Prefix, ['_'|X], Chars), 
      not(append(_, ['_' | _], X)),
       !,
      atom_chars(Name2, Prefix),
      Term2 =.. [Name2|Args].

strip_arity(X, X).

operator(\=).
operator(<).
operator(>).
operator(=).
operator(>=).
operator(<=).
operator(+).
operator(-).
operator('!=').
operator('..').

first_char(String, Char) :-
     not(string_chars(String,_)), !,
     term_string(String, Str),
     first_char(Str, Char).

first_char(String, Char) :-
     string_chars(String, [Char|_]).

format_sasp_arg([], []) :- !.

strip_constant_special(constant(X), X).
strip_constant_special(X, Y) :-
           X \= constant(_), X = [_|_],
           maplist(strip_constant_special, X, Y).
strip_constant_special(X, X) :-
           X \= constant(_), X \= [_|_].

format_sasp_arg(Term, Formatted) :-
       Term \= [_|_], Term \= [], 
       Term =.. [Name|Args], length(Args, L), L > 0, 
       format_sasp_arg(Name, NameFmt),
       maplist(format_sasp_arg, Args, ArgsFmt),
       (NameFmt = constant(X) -> NameFmt1 = X ; NameFmt1 = NameFmt),
       maplist(strip_constant_special, ArgsFmt, ArgsFmt1),
       Formatted =.. [NameFmt1|ArgsFmt1], !.


format_sasp_arg(typenum(X), constant(X)) :- !.
format_sasp_arg('..','..').

format_sasp_arg(X+Y,TX+TY) :-
      (X = typenum(X1) -> term_string(constant(X1), S1), SX = S1 ; SX = X),
      (Y = typenum(Y1) -> term_string(constant(Y1), S2), SY = S2 ; SY = Y),
      string_lower(SX, SX1),
      string_lower(SY, SY1),
      term_string(TX, SX1),
      term_string(TY, SY1),
      !.

format_sasp_arg(X, constant(X1)) :- 
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, lower),
      strip_arity(X, X1).
      
format_sasp_arg(X, X1) :-
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, upper),
      string_lower(X, Xs),
      term_string(X1, Xs).

format_sasp_arg(X, X1) :- 
      X = [_|_],
      maplist(format_sasp_arg, X, X1).

format_sasp_functor2(Functor, F) :-
       Functor = not(F1), !,
       format_sasp_functor2(F1, F2),
       F = not(F2).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Functor], !,
     format_sasp_functor(Functor, F).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Name, Tuples],
     Tuples =.. [Name2|_],
     operator(Name2), !, 
     format_sasp_functor(Functor, F).

format_sasp_functor2(Functor, F) :-
     Functor =.. [Name|Tuples],
     Tuples =.. [Name2|_],
     not(operator(Name2)), !, 
     maplist(tuple_list, Tuples, Args),
     flatten(Args, Args1),
     Functor2 =.. [Name|Args1],
     format_sasp_functor(Functor2, F).

format_sasp_functor2(Functor, F) :-
       !,
       format_sasp_functor(Functor, F).


format_sasp_functor(Functor, F2) :-
      Functor = not(Functor1),
      format_sasp_functor(Functor1, F1),
      F2 = not(F1).

format_sasp_functor(Functor, F2) :-
     Functor \= not(_),
     strip_arity(Functor, F1),
     F1 =.. [Name|Args],
     maplist(format_sasp_arg, Args, Args1),
     F2 =.. [Name|Args1].

format_sasp_rule(Head-_, []) :- 
   Head =.. [Name|_],
   reserved_predicate_names(Names),
   reserved(Name, Names, Head),
   format_sasp_functor2(Head, Head1),
   strip_constant_symbol(Head1, Head2),
   brk2(Head2),
   (Head2 =.. [primitive_write_step|[Op|Args]] -> Head3 =.. [primitive_write_step, Op, Args] 
          ;    Head3 = Head2),  
   assert(Head3). 
   %Rule = rule(head(Head2), body([])).

brk2(_).

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
    reserved_predicate_names(Names),
	  not(member(Name, Names)),
    Name \= '_false_0',
   format_sasp_functor2(Head, Head1),
	 % Head1 \= false,
	 maplist(format_sasp_functor2, Body, Body1),
	 Rule = rule(head(Head1), body(Body1)).     

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
	  Name = '_false_0',
	 format_sasp_functor(Head, Head1),
	 Head1 = false,
	 maplist(format_sasp_functor2, Body, Body1),
	 Rule = constraint(Body1).     

reserved_predicate_names([
   'signature_3',
   'node_property_1',
   'fluent_1',
   'invariant_1',
   'constructor_1',
   'primitive_write_step_2',
   'causes_2',
   'modifies_2',
   'constants_2'
]).

brk(_).

reserved(Name, Names, _) :-
     member(Name, Names).

reserved(Name, _, Head) :-
     begins_with(Name, "signature"),
     brk(Head),
     remove_constant_functor(Head, Formatted2),
     Formatted2 =.. Args,
     maplist(strip_arity, Args, Args1),
     Formatted =.. Args1,
     Args1 = [A|B],
     B = [C, D | E],
     (E = [] -> (Formatted3 =.. [sig_type| [C, D, []]], Formatted4 =.. [signature| [C, D, []]])
             ; (Formatted3 =.. [sig_type|[C, D, E]]), Formatted4 =.. [signature|[C, D, E]]),
     assert(Formatted3),
     assert(Formatted4).

remove_constant(constant(X), X) :- !.
remove_constant(typenum(X), X) :- !.
remove_constant(X, X).

remove_constant_functor(Functor, Functor2) :-
      Functor =.. [Name|Args],
      maplist(tuple_list, Args, Args1),
      flatten(Args1, Args2),
      maplist(remove_constant, Args2, Args3),
      Functor2 =.. [Name|Args3].


strip_constant_symbol(Term, Term2) :-
      Term =.. [Name|Args],
      maplist(strip_constant_symbol_helper, Args, Args1),
      Term2 =.. [Name|Args1].

strip_constant_symbol_helper([], []) :- !.

strip_constant_symbol_helper(X, X) :-
           X \= constant(_), X \= [_|_], !.

strip_constant_symbol_helper(constant(X), X) :-
          X \= [_|_].

strip_constant_symbol_helper(X, X1) :-
          X = [_|_],
          maplist(strip_constant_symbol_helper, X, X1).

sasp_locksynth(Rules, Rules2) :-
     maplist(format_sasp_rule, Rules, Rules1),
     flatten(Rules1, Rules2).

:- dynamic node_property/1.
:- discontiguous node_property/1.

cleanup :- 
  retractall(signature(_, _, _)), 
  retractall(fluent(_)),
  %retractall(node_property(_)),
  retractall(invariant(_)),
  retractall(constructor(_)),
  retractall(time_dependent(_)),
  retractall(time_dependent(_, _)),
  retractall(causes(_, _)),
  retractall(modifies(_, _)),
  retractall(primitive_write_step(_, _)),
  retractall(rule_base(_, _)),
  retractall(constraint_base(_, _)),
  retractall(nonterminal(_)),
  %retractall(rule(_, _)),
  %retractall(start(_)),
  assert(signature(lt, 2, [num, num])),
  assert(signature(gt, 2, [num, num])),
  assert(signature(eq_num, 2, [num, num])),
  assert(signature(not_eq_num, 2, [num, num])),
  assert(signature(eq_node, 2, [node, node])),
  assert(signature(not_eq_node, 2, [node, node])).



assert_signature([H|T]) :-
        H = signature(_, _, _),
        assert(H),
        assert_signatures(T).

assert_signatures([H|T]) :-
        H \= signature(_, _, _),
        assert_signatures(T).

assert_signatures([]).


