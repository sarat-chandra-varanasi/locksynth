

strip_arity('_false_0', false).

strip_arity(Term, Term) :-
	  Term =.. [Name|Args],
      operator(Name).

strip_arity(Term, Term2) :- 
      Term =.. [Name|Args],
      atom_chars(Name, Chars),
      not(operator(Name)),
      append(Prefix, ['_'|X], Chars),
      not(append(_, ['_' | _], X)),
       !,
      atom_chars(Name2, Prefix),
      Term2 =.. [Name2|Args].

operator(\=).
operator(<).
operator(>).
operator(=).

first_char(String, Char) :-
     string_chars(String, [Char|_]).


format_sasp_arg([], []) :- !.

strip_constant_special(constant(X), X).
strip_constant_special(X, Y) :-
           X \= constant(_), X = [_|_],
           maplist(strip_constant_special, X, Y).
strip_constant_special(X, X) :-
           X \= constant(_), X \= [_|_].

format_sasp_arg(Term, Formatted) :-
       Term \= [_|_], Term \= [], 
       Term =.. [Name|Args], length(Args, L), L > 0, 
       format_sasp_arg(Name, NameFmt),
       maplist(format_sasp_arg, Args, ArgsFmt),
       (NameFmt = constant(X) -> NameFmt1 = X ; NameFmt1 = NameFmt),
       maplist(strip_constant_special, ArgsFmt, ArgsFmt1),
       Formatted =.. [NameFmt1|ArgsFmt1], !.

format_sasp_arg(typenum(X), constant(X)) :- !.

format_sasp_arg(X, constant(X1)) :- 
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, lower),
      strip_arity(X, X1).
      
format_sasp_arg(X, X1) :-
      X \= [_|_],
      first_char(X, Char),
      char_type(Char, upper),
      string_lower(X, Xs),
      term_string(X1, Xs).

format_sasp_arg(X, X1) :- 
      X = [_|_],
      maplist(format_sasp_arg, X, X1).

format_sasp_functor(Functor, F2) :-
      Functor = not(Functor1),
      format_sasp_functor(Functor1, F1),
      F2 = not(F1).

format_sasp_functor(Functor, F2) :-
     Functor \= not(_),
     strip_arity(Functor, F1),
     F1 =.. [Name|Args],
     maplist(format_sasp_arg, Args, Args1),
     F2 =.. [Name|Args1].

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
    reserved_predicate_names(Names),
	  not(member(Name, Names)),
    Name \= '_false_0',
   format_sasp_functor(Head, Head1),
	 % Head1 \= false,
	 maplist(format_sasp_functor, Body, Body1),
	 Rule = rule(head(Head1), body(Body1)).     

format_sasp_rule(Head-Body, Rule) :- 
	  Head =.. [Name|_],
	  Name = '_false_0',
	 format_sasp_functor(Head, Head1),
	 Head1 = false,
	 maplist(format_sasp_functor, Body, Body1),
	 Rule = constraint(Body1).     

reserved_predicate_names([
   'signature_3',
   'node_property_1',
   'fluent_1',
   'invariant_1',
   'constructor_1',
   'primitive_write_step_2',
   'causes_2',
   'modifies_2',
   'constants_2'
]).


format_sasp_rule(Head-Body, []) :- 
	 Head =.. [Name|_],
   reserved_predicate_names(Names),
	 member(Name, Names),
   format_sasp_functor(Head, Head1),
	 strip_constant_symbol(Head1, Head2),
	 assert(Head2),	
	 Rule = rule(head(Head2), body([])).

strip_constant_symbol(Term, Term2) :-
      Term =.. [Name|Args],
      maplist(strip_constant_symbol_helper, Args, Args1),
      Term2 =.. [Name|Args1].

strip_constant_symbol_helper([], []) :- !.

strip_constant_symbol_helper(X, X) :-
           X \= constant(_), X \= [_|_], !.

strip_constant_symbol_helper(constant(X), X) :-
          X \= [_|_].

strip_constant_symbol_helper(X, X1) :-
          X = [_|_],
          maplist(strip_constant_symbol_helper, X, X1).

sasp_locksynth(Rules, Rules2) :-
     maplist(format_sasp_rule, Rules, Rules1),
     flatten(Rules1, Rules2).

cleanup :- 
  retractall(signature(_, _, _)), 
  retractall(fluent(_)),
  retractall(node_property(_)),
  retractall(invariant(_)),
  retractall(constructor(_)),
  retractall(time_dependent(_)),
  retractall(time_dependent(_, _)),
  retractall(causes(_, _)),
  retractall(modifies(_, _)),
  retractall(primitive_write_step(_, _)),
  retractall(rule_base(_, _)),
  retractall(constraint_base(_, _)),
  retractall(nonterminal(_)),
  retractall(rule(_, _)),
  retractall(start(_)),
  assert(signature(lt, 2, [num, num])),
  assert(signature(gt, 2, [num, num])),
  assert(signature(eq_num, 2, [num, num])),
  assert(signature(not_eq_num, 2, [num, num])),
  assert(signature(eq_node, 2, [node, node])),
  assert(signature(not_eq_node, 2, [node, node])).



assert_signature([H|T]) :-
        H = signature(_, _, _),
        assert(H),
        assert_signatures(T).

assert_signatures([H|T]) :-
        H \= signature(_, _, _),
        assert_signatures(T).

assert_signatures([]).


