% :- module(format_terms, []).

time_dependent2(Name) :-
      signature(Name, _, Domains),
      member(time, Domains).

add_time_list(TimeSymbol, [H|T], [not(Term2)|R]) :-
       H = (not(Term)),
       Term =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [TimeSymbol], List2),
       Term2 =.. List2,
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [Term|R]) :-
       H \= (not(_)),
       H =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [TimeSymbol], List2),
       Term =.. List2,
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [H|R]) :-
       H = (not(Term)),
       Term =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list(TimeSymbol, T, R).

add_time_list(TimeSymbol, [H|T], [H|R]) :-
       H \= (not(_)),
       H =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list(TimeSymbol, T, R).


add_time_list(_, [], []).



add_time_list_constant(TimeSymbol, [H|T], [not(Term2)|R]) :-
       H = (not(Term)),
       Term =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [constant(TimeSymbol)], List2),
       Term2 =.. List2,
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [Term|R]) :-
       H \= (not(_)),
       H =.. [Name|Suffix],
       time_dependent(Name, _),
       append([Name|Suffix], [constant(TimeSymbol)], List2),
       Term =.. List2,
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [H|R]) :-
       H = (not(Term)),
       Term =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list_constant(TimeSymbol, T, R).

add_time_list_constant(TimeSymbol, [H|T], [H|R]) :-
       H \= (not(_)),
       H =.. [Name|_],
       not(time_dependent(Name, _)),
       add_time_list_constant(TimeSymbol, T, R).


add_time_list_constant(_, [], []).



add_time(Term, Term2) :-
    lint_negation(Term, Term1),
    Term1 =.. [Name|_],
    time_dependent2(Name),
    Term1 =.. List,
    generate_symbol(time, Symbol),
    append(List,[Symbol], List2),
    Term2 =.. List2.

add_time(Term, Term) :-
    lint_negation(Term, Term1),
    Term1 =.. [Name|_],
    not(time_dependent2(Name)).


add_time_unconditional(TimeSymbol, Term, Term2) :-
          lint_negation(Term, Term1),
          Term1 =.. List,
          append(List, [TimeSymbol], List2),
          Term2 =.. List2.
 
add_time_unconditional_constant(TimeSymbol, Term, Term2) :-
          lint_negation(Term, Term1),
          Term1 =.. List,
          append(List, [constant(TimeSymbol)], List2),
          Term2 =.. List2.


map_vars_domain([H|T], [D|Tail], [Term|R]) :- 
         Term =.. [D,H],
         map_vars_domain(T, Tail, R).

map_vars_domain([], _, []).

term_domainvars(Term, DomainVars) :-
      lint_negation(Term, Term1),
      Term1 =.. [_|Vars],
      get_domains(Term1, Domains),
      map_vars_domain(Vars, Domains, DomainVars).

map_vars_domain([H|T], [D|Tail], [Term|R]) :- 
         [H|T] \= [],
         Term =.. [D,H], 
         map_vars_domain(T, Tail, R), !.

map_vars_domain([], _, []).

tuple_1([(H,_)|T], [H|R]) :-
               tuple_1(T, R).
tuple_1([], []).

term_vars(Term, Vars) :-
       lint_negation(Term, Term2),
       Term2 =.. [_|Vars].

conjunct_vars(List, Vars) :-
    maplist(term_vars, List, VarsMap),
    flatten(VarsMap, Flattened),
    remove_duplicates(Flattened, Vars).

neg_term(Term, NegTerm) :-
      term_string(Term, String),
      string_concat('neg_',String, NegString),
      term_string(NegTerm, NegString).

conjunct_domainvars(List, DomainVars) :-
     maplist(term_domainvars, List, DomainVarsMap),
     flatten(DomainVarsMap, Flattened),
     remove_duplicates(Flattened, DomainVars).


lint_negation(Term, Term2) :-
      Term =.. [not, Term2], !.

lint_negation(Term, Term).


time_var(Term1, Var) :-
      Term1 =.. List,
      last_element(List, Var).

copy_timevar(Term1, Term2, Term3) :-
       time_var(Term1, Var),
       append_var(Var, Term2, Term3).

last_element(List, X) :-
      append(_, [X], List).

append_var(Var, Term, Term1) :-
        Term =.. List,
        append(List, [Var], List1),
        Term1 =.. List1.


get_domains(Term, Domains) :-
      Term =.. [Name|_],
      signature(Name, _, Domains).

domain_variant(Domain, Variant) :-
       Domain =.. [Name,_],
       generate_symbol(Name, Symbol),
       Variant =.. [Name,Symbol].


var_domain(Domain, Var) :-
        Domain =.. [_,Var].

rename_vars(Term, Domains, Term2) :-
    Term =.. [Name|_],
    maplist(var_domain, Domains, List),
    Term2 =.. [Name|List].

% Term2 borrows the same timestep from Term1
same_timevar(Term1, Term2, Term3) :-
      Term1 =.. List,
      last_element(List, TimeVar),
      Term2 =.. List2,
      append(List3, [_], List2),
      append(List3, [TimeVar], List4),
      Term3 =.. List4.


domain_term_of(Var, [H|_], H) :-
      H =.. [_, Var].

domain_term_of(Var, [H|T], Term) :-
      H =.. [_, V],
      Var \== V,
      domain_term_of(Var, T, Term).

domain_of(Var, [H|_], Domain) :-
        H =.. [Domain, Var].

domain_of(Var, [H|T], Domain) :-
        H =.. [_,V],
        V \== Var,
        domain_of(Var, T, Domain).


common_vars(Term1, Term2, Common) :-
        Term1 =.. [_|Vars1],
        Term2 =.. [_|Vars2],
        set_intersect(Vars1, Vars2, Common).

relop(>).
relop(<).
relop(>=).
relop(<=).
relop('!=').
relop('..').
relop(+).
relop(..).
relop(-).

reduce([], string_concat, _, '').

format_conjunct_term(Term, Formatted) :- 
      Term =.. ['..', X, Y], !,
      capitalize(X, X1),
      capitalize(Y, Y1),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " .. ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term(Term, Formatted) :- 
      Term =.. [Relop, X, Y], 
      relop(Relop), !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      term_string(Relop, RelString),
      string_concat(X1s, RelString, X1s1),
      string_concat(X1s1, Y1s, Formatted).


%format_conjunct_term(Term, Formatted) :- 
%      Term =.. [+, X, Y], !,
%      capitalize(X, X1),
%      capitalize(Y, Y1),
%      term_string(X1, X1s),
%      term_string(Y1, Y1s),
%      string_concat(X1s, " + ", X1s1),
%      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term(constant(Symbol), Symbol).

format_conjunct_term(Term, Formatted) :- 
      Term =.. [\=, X, Y], !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " != ", X1s1),
      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term(Term, Formatted) :- 
      Term =.. [=, X, Y], !,
       (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
        format_conjunct_term(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " = ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


drop_last_tactic_helper(Term, Term2) :-
        Term =.. [Name|Args],
        append(Prefix, [X], Args),
        Term2 =.. [Name|Prefix].

drop_last_tactic(Literals, Literals1) :-
       maplist(drop_last_tactic_helper, Literals, Literals1).


get_types([H|T], Literals, [Term|R]) :-
        type_of(H, Literals, Type),
        Term =.. [Type, H], !,
        get_types(T, Literals, R).

get_types([H|T], Literals, [Term|R]) :-
        not(type_of(H, Literals, Type)),
        drop_last_tactic(Literals, Literals1),
        type_of(H, Literals1, Type),
        Term =.. [Type, H], !,
        get_types(T, Literals, R).

get_types([H|T], Literals, R) :-
      !, get_types(T, Literals, R). 

get_types([], _, []).

capitalize_special(Term, String) :-
       Term =.. [Type, Arg],
       capitalize(Arg, S),
       term_string(Type, TypeS),
       string_concat(TypeS, '(', S1),
       string_concat(S1, S, S2),
       string_concat(S2, ")", String).

pair_doms([H|T], [Type|T1], [Term|R]) :-
          Term =.. [Type, H],
          pair_doms(T, T1, R).

pair_doms([], [], []).

add_comma(Str, Str1) :-
       string_concat(Str, ",", Str1).


format_conjunct_term(Term, Formatted) :-
       Term =.. [not, Term2],
       Term2 =..[_|Args],
       get_types(Args, [Term2], Doms),
       %pair_doms(Args, Types, Doms),
       maplist(capitalize_special, Doms, Doms1),
       maplist(add_comma, Doms1, Doms2),
       reduce(Doms2, string_concat, ",", Doms3),
       format_conjunct_term(Term2, Format2),
       string_concat('not ', Format2, Format3),
       string_concat(Doms3, Format3, Formatted).

format_conjunct_term(Term, Formatted) :-
       Term =.. [Name|Args],
       Name \== not,
       maplist(capitalize, Args, Caps),
       list_str(Caps, ArgsStr),
       term_string(Name, NameStr),
       string_concat(NameStr, '(',  S1),
       string_concat(S1, ArgsStr, S2),
       string_concat(S2, ')', Formatted).

format_conjunct_term(Term, Formatted) :-
       Term =.. [Name],
       term_string(Name, Formatted).


capitalize(typenum(Symbol), Symbol).
capitalize(constant(Symbol), Symbol).
capitalize('..'(X,Y), Str) :-
       term_string(X, Xs),
       term_string(Y, Ys),
       string_concat(Xs, '..', Xs1),
       string_concat(Xs1, Ys, Str).

capitalize(Symbol, Str) :-
       constants(Symbol, _),
       term_string(Symbol, Str).

capitalize(Symbol, Caps) :-
       not(constants(Symbol, _)),
       not(number(Symbol)),
       term_string(Symbol, Str),
       string_chars(Str, [H|T]),
       char_code(H, Code),
       CapsCode is Code - 32,
       char_code(H1, CapsCode),
       string_chars(Caps, [H1|T]).

capitalize(Symbol, SymbolString) :-
       not(constants(Symbol, _)),
       number(Symbol),
       term_string(Symbol, SymbolString).
       


dom_of(Arg, Body, Domain) :-
       is_var(Arg, Body),
       domain_of(var(Arg), Body, Domain).


dom_of(Arg, Body, Domain) :-
      not(is_var(Arg, Body)),
      constants(Arg, Domain).


is_var(Arg, [Term|_]) :-
         Term =.. [_, var(Arg)].

is_var(Arg, [X|T]) :-
      X =.. [_|Args],
      length(Args, L), 
      L > 1,
      is_var(Arg, T).

is_var(Arg, [X|T]) :- 
      X =.. [_, A],
      A \= Arg,
      A \= var(Arg),
      is_var(Arg, T).


to_var(Term, Term1) :-
      Term \= not(_),
      Term =.. [Name|Args],
      maplist(to_var_helper, Args, Args1),
      Term1 =.. [Name|Args1].

to_var(Term, not(Term2)) :-
      Term = not(Term1),
      Term1 =.. [Name|Args],
      maplist(to_var_helper, Args, Args1),
      Term2 =.. [Name|Args1].
            
to_var_helper(X, var(X)) :-
          not(constants(X, _)).
to_var_helper(X, X) :-
         constants(X, _).