

% :- initialization(main, main).
:- dynamic ds/1.
:- dynamic count/2.


count(node, 0).

gen_nodename(Node) :-
    count(node, X),
    term_string(node, N),
    term_string(X, Xs),
    string_concat(N, Xs, Ns),
    term_string(Node, Ns),
    retract(count(node, X)),
    X1 is X + 1,
    assert(count(node, X1)).

gen_heapnodes(list, Length, [h|Nodes]) :- 
      gen_heapnodes(list, Length, 0, Nodes).

gen_heapnodes(list, L, P, [Node|Nodes]) :-
        P < L, !, 
        P1 is P + 1, 
        gen_nodename(Node), !,  
        gen_heapnodes(list, L, P1, Nodes).

gen_heapnodes(list, L, L, [t]).


gen_heap_edges(list, L, Edges) :-
      gen_heapnodes(list, L, Nodes),
      gen_heap_edges_helper(list, Nodes, Edges1),
      maplist(assert_edge, Edges1, _),
      Edges = [node(h)|Edges1],
      assert(heap_term(node(h))),
      assert(node(h)),
      maplist(assert_heap_term, Edges, _).
     
gen_heap_edges_helper(list, [X,Y|T], [edge(X,Y)|Edges]) :-
        gen_heap_edges_helper(list, [Y|T], Edges).

gen_heap_edges_helper(list, [_], []).
 
count(heap_term, 1).

assert_edge(Edge, []) :- assert(Edge).
assert_heap_term(Term, []) :- 
      ds_instance(DS), count(heap_term, X),
       X1 is X + 1, assert(heap(DS, X, Term)), 
       assert(heap_term(Term)),
       retract(count(heap_term, X)), assert(count(heap_term, X1)).

gen_heap_edges(tree, Max, Edges) :-
      gen_heap_edges_queue(tree, Max, 1, [root], none, [], Edges1), 
      maplist(assert_edge, Edges1, _),
      Edges = [root(root)|Edges1],
      assert(heap_term(root(root))),
      assert(root(root)),
      maplist(assert_heap_term, Edges, _).


gen_heap_edges_queue(tree, Max, Curr, [H|T], PrevEdge, PartialEdges, Edges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, CurrOut, PrevEdge, NewEdges),
       NewEdges = [left(H, L), right(H, R)|_],
       append(PartialEdges, NewEdges, PartialEdges1),
       append(T, [L, R], T1),
       gen_heap_edges_queue(tree, Max, CurrOut, T1, right(H, R), PartialEdges1, Edges).

gen_heap_edges_queue(tree, Max, Curr, [H|T], PrevEdge, PartialEdges, Edges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, CurrOut, PrevEdge, NewEdges),
       NewEdges = [left(H, L)|_],
       append(PartialEdges, NewEdges, PartialEdges1),
       append(T, [L], T1),
       gen_heap_edges_queue(tree, Max, CurrOut, T1, left(H, L),  PartialEdges1, Edges).


gen_heap_edges_queue(tree, Max, Curr, [H|_], PrevEdge, PartialEdges, PartialEdges) :-
       Curr =< Max, 
       gen_heap_edges(tree, H, Curr, Max, _, PrevEdge, []).
       

gen_heap_edges_queue(tree, Max, Max, _, _,  PartialEdges, PartialEdges).


gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = none, 
          Curr < Max, 
          gen_nodename(Left),
          CurrOut is Curr + 1,
          CurrOut = Max,
          (weighted(false) -> Edges = [left(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [left(Node, Left), weight_left(Node, W1)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = none, 
          Curr < Max, 
          gen_nodename(Left),
          Curr1 is Curr + 1,
          Curr1 < Max,
          gen_nodename(Right),
          CurrOut is Curr1 + 1,
          (weighted(false) -> Edges = [left(Node,Left), right(Node, Right)] ;
                              random(-10, 10, W1), random(-10, 10, W2), 
                              Edges = [left(Node,Left), right(Node, Right), weight_left(Node, W1), weight_right(Node, W2)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = right(Node1, _), 
          Node \= Node1,
          Curr < Max, 
          gen_nodename(Left),
          Curr1 is Curr + 1,
          Curr1 < Max,
          gen_nodename(Right),
          CurrOut is Curr1 + 1,
          (weighted(false) -> Edges = [left(Node,Left), right(Node, Right)] ;
                              random(-10, 10, W1), random(-10, 10, W2), 
                              Edges = [left(Node,Left), right(Node, Right), weight_left(Node, W1), weight_right(Node, W2)]).



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = right(Node1, _), 
          Node \= Node1,
          Curr < Max, 
          gen_nodename(Left),
          CurrOut is Curr + 1,
          CurrOut = Max,
          (weighted(false) -> Edges = [left(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [left(Node, Left), weight_left(Node, W1)]).




gen_heap_edges(tree, Node, Max, Max, Max, PrevEdge, []) :-
          PrevEdge = right(Node1, _),
          Node \= Node1.



gen_heap_edges(tree, Node, Curr, Max, CurrOut, PrevEdge, Edges) :-
          PrevEdge = left(Node, _),
          Curr < Max, 
          gen_nodename(Right),
          CurrOut is Curr + 1,
          (weighted(false) -> Edges = [right(Node, Left)]  ;
                               random(-10, 10, W1), Edges = [right(Node, Left), weight_right(Node, W1)]).


gen_heap_edges(tree, Node, Max, Max, Max, PrevEdge, []) :-
          PrevEdge = left(Node, _).



%heap(tree, 1, root(root)).
%heap(list, 1, node(h)).


%heap(tree, 1, root(a)).
%heap(tree, 2, left(a,b)).
%heap(tree, 3, right(a,c)).
%heap(tree, 4, left(b,d)).
%heap(tree, 5, right(b,e)).
%heap(tree, 6, left(c,f)).
%heap(tree, 7, right(c,g)).


%heap(list, 1, node(a)).
%heap(list, 2, edge(a, b)).
%heap(list, 3, edge(b, c)).
%heap(list, 4, edge(c, d)).

:- dynamic root/1.
:- dynamic left/2.
:- dynamic right/2.
:- dynamic heap_term/1.
:- dynamic edge/2.
:- dynamic node/1.

assert_heap(Iteration) :- 
         ds_instance(DS),
         heap(DS, Iteration, X),
         assert(X),
         assert(heap_term(X)),
         Iteration1 is Iteration - 1,
         assert_heap(Iteration1).

assert_heap(1) :- 
          ds_instance(DS),
          heap(DS, 1, X), assert(X), assert(heap_term(X)).


left(X) :- left(X, _).
right(X) :- right(X, _).


list_order(List) :- node(X), list_order(X, List), !.
list_order(X, [X|R]) :- edge(X, Y), list_order(Y, R), !.
list_order(X, [X]) :- not(edge(X,_)).

inorder(List) :- root(X), inorder_rec(X, [], List).
inorder_rec(X, ListIn, List2) :- left(X, Y), right(X, Z), inorder_rec(Y, ListIn, List), 
           append(List, [X], List1), inorder_rec(Z, List1, List2).
inorder_rec(X, ListIn, List2 ) :- left(X, Y), not(right(X)), 
          inorder_rec(Y, ListIn, List1), append(List1, [X], List2).
inorder_rec(X, ListIn, List2) :- 
       right(X, Y), not(left(X)), append([X], ListIn, List1), inorder_rec(Y, List1, List2). 
inorder_rec(X, ListIn, List) :-
           not(left(X)), not(right(X)), append(ListIn, [X], List).

key(X, KX) :- term_string(X, Xs), string_concat("k", Xs, Ks), term_string(KX, Ks).


gen_terms([H], [node(H), key(H, KH), num(KH)]) :- key(H, KH).
gen_terms([A, B|T], [node(A), key(A, KA), num(KA), lt(KA, KB)|R]) :-
          key(A, KA), key(B, KB), gen_terms([B|T], R).


facts(List, Str) :- facts(List, "\n", Str).
facts([H|T], S, Str) :- 
      term_string(H, Hs), string_concat(Hs, ".\n", Hs1),  
      string_concat(S, Hs1, S1), facts(T, S1, Str).
facts([], S, S).


construct_nodes([H|T], [node(H)|R]) :-
        construct_nodes(T, R).

construct_nodes([], []).

pair_nodes_keys([H|T], [K|T1], [key(H, K)|R]) :-
      pair_nodes_keys(T, T1, R).

pair_nodes_keys([], [], []).

treegen([DS, Iter], Terms2) :-  
      retractall(heap_term(_)),
      retractall(heap(_,_,_)),
      retractall(ds_instance(_)),
      retractall(edge(_,_)),
      retractall(left(_,_)),
      retractall(right(_,_)),
      retractall(node(_)),
      assert(ds_instance(DS)),
      assert(weighted(false)),
      term_string(Iteration, Iter),
      % write(Iteration),
      gen_heap_edges(DS, Iteration, _), ! ,
      %assert_heap(Iteration), ! ,
      (DS = tree -> inorder(List) ; DS = list -> list_order(List)  ; 
       DS = int_tree -> gen_heapnodes(list, Iter, Nodes),
                        %maplist(key, Nodes, Keys),
                        %construct_nodes(Nodes, Nodes1),
                        %pair_nodes_keys(Nodes, Keys, Keys1),
                        List = Nodes
          ; List = []), 
      gen_terms(List, Terms),
      findall(X, heap_term(X), HeapTerms),
      append(Terms, HeapTerms, Terms2).


gen_heap_edges(int_tree, _, _).

treegen([DS, Iter, Weighted]) :-  
      assert(ds_instance(DS)),
      assert(weighted(true)),
      term_string(Iteration, Iter),
      % write(Iteration),
      gen_heap_edges(DS, Iteration, _), ! ,
      %assert_heap(Iteration), ! ,
      (DS = tree -> inorder(List) ; DS = list -> list_order(List)  ; List = []), 
      gen_terms(List, Terms),
      findall(X, heap_term(X), HeapTerms),
      append(Terms, HeapTerms, Terms2),
      facts(Terms2, Str),
      write(Str),
      add_facts(Str, 'search.lp').



format_command(List, Str) :- 
        format_command(List, "", Str).

format_command([H|T], S, Str) :-
         string_concat(S, H, S1), 
         string_concat(S1, ' ', S2),
         format_command(T, S2, Str).

format_command([], S, S).

add_facts(Str, File) :-  
           string_concat(File, '_heap', Heap), 
           format_command(['cp', File, Heap], Cmd),
           shell(Cmd, _),
           format_command(['printf \'', Str, '\'', '>>', Heap], Cmd2), 
           shell(Cmd2, _).

add_text_to_file(Str, File) :-
          format_command(['printf \'', Str, '\'', '>>', File], Cmd2), 
           shell(Cmd2, _).

