

code(rb_tree, insert, _, block1, 
	[visited(x, target), external(x), left(z, x), key(x, kx), key(target, ktarget), lt(ktarget, kx), color(x,black),color(z,red),
	tag(x, none), tag(z, none)],
	[link_left(internal, target), link_right(internal, x), link_left(z, internal), change_color(x, red), change_color(target, red), change_color(internal, black),
	 change_tag(target, none), change_tag(internal, none)],
	_).

code(rb_tree, insert, _, block2, 
	[visited(x, target), external(x), left(z, x), key(x, kx), key(target, ktarget), lt(kx, ktarget), color(x,black),color(z,red),
	tag(x, none), tag(z, none)],
	[link_right(internal, target), link_left(internal, x), link_left(z, internal), change_color(x, red), change_color(target, red), change_color(internal, black),
	 change_tag(target, none), change_tag(internal, none)],
	_).


code(rb_tree, insert, _, block3, 
	[visited(x, target), external(x), parent(x, p), parent(p, gp), parent(gp, ggp), key(p, kp), key(gp, kgp), key(ggp, kggp), 
	 left(p, x), lt(ktarget, x), color(x, red), color(p, black), color(gp, black), color(ggp, black), right(gp, rgp), 
	 color(rgp, red),
	 tag(x, none), tag(p, none), tag(gp, none), tag(ggp, none),tag(rgp, none)],
	[link_left(internal, target), link_right(internal, x),
	 link_left(p, x), change_color(internal, black), change_color(x, red), change_color(target, red),
	 change_color(gp, red), change_color(rgp, black),
	 chabge_tag(internal, none), change_tag(target, none)],
	_).

code(rb_tree, insert, _, block4, 
	[external(x), key(x,kx), lt(ktarget, kx), parent(x, p), parent(p, gp), parent(gp, ggp),
	 right(p, x),
	 color(x, red), color(p, black), color(gp, black), color(ggp, black), sibling(p, sp), left(sp, spl), right(sp, spr),
	 tag(x, none), tag(p, none), tag(gp, none), tag(ggp, none), tag(sp, none), tag(spl, none), tag(spr, none)],
	[link_left(internal, target), link_right(internal, x), link_left(p, internal), 
	  change_color(gp, red), change_color(sp, black), change_color(spl, red), change_spr(red),
	  change_tag(internal, none), change_tag(target, none)],_).



code(rb_tree, delete, _, block1,
	[ external(x), parent(x, p), parent(p, gp), key(target, ktarget), key(x,kx),
	 color(x, red), color(p, black), color(gp, black), left(gp, p), sibling(target, y),
	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
	[link_left(gp, y)],
	_).

code(rb_tree, delete, _, block2,
	[ external(x), parent(x, p), parent(p, gp), key(target, ktarget), key(x,kx),
	 color(x, black), color(p, red), color(gp, black), left(gp, p), sibling(target, y),
	 tag(x, none), tag(p, none), tag(gp, none), tag(target, none), tag(y, none)],
	[link_left(gp, y)],
	_).


code(rb_tree, delete, _, block3, 
	[external(x), color(x, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red), sibling(x, y), left(gp, p),
	tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
	[link_left(gp, y), change_color(y, black)],_).

code(rb_tree, delete, _, block4, 
	[external(x), color(x, black), parent(x, p), color(p, black), parent(p, gp), color(gp, red), sibling(x, y), left(gp, p),
	tag(x, none), tag(p, none), tag(gp, none), tag(y, none)],
	[link_left(gp, y), change_color(gp, black)],_).


code(rb_tree, insert, _, block5, 
	[external(x), color(x, red), parent(x, p), key(x, kx), lt(ktarget, kx), parent(p, gp), left(p, x),
	 color(p, black), color(gp, red), sibling(x, y), sibling(p, sp), color(sp, red),
	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none), tag(sp, none)],
	[link_left(internal, target), link_right(internal, x), link_left(p, internal), 
	change_color(internal, black), change_color(p, red), change_color(sp, black), tag(gp, tagged),
	change_tag(target, none), change_tag(internal, none)],_).



code(rb_tree, red_red_resolve, _, block1, 
	[tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, black),
	tag(y, none), tag(p, none), tag(gp, none)],
	[change_color(x, black), change_color(p, red), change_tag(x, none)], _).

code(rb_tree, red_red_resolve, _, block2, 
	[tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red),
	tag(p, none), tag(y, none), tag(gp, none)],
	[change_color(x, black), change_color(p, red), change_tag(x, none), change_tag(gp, tagged)], _).
