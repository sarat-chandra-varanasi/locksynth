
precondition_rule((Op, Block), [Constraint, Rule]) :-
      ds(DS),
      pre(DS, Op, Block, Pre),
      term_string(Op, OpS),
      term_string(Block, BlockS),
      string_concat(OpS, "_", OpS1),
      string_concat(OpS1, BlockS, OpBlockS),
      term_string(OpBlock, OpBlockS),
      Rule = rule(head(OpBlock), body(Pre)),
      Constraint = constraint([not(OpBlock)]).


precondition_rules(Rules1) :-
      op_blocks(OpBlocks),
      remove_duplicates(OpBlocks, OpBlocks1),
      maplist(precondition_rule, OpBlocks1, Rules),
      flatten(Rules, Rules1).


:- dynamic num_nodes/1.
:- dynamic curr_depth/1.
:- dynamic type_of/1.

curr_depth(3).
num_nodes(7).


increase_num_nodes :-
       ((type_of(tree) ; type_of(list)) ->
              (curr_depth(D),
              D1 is D + 1,
              N is 2 ** D1 - 1)
        ;
         type_of(int_tree) -> 
               (num_nodes(N1),
               N is N1 + 1,
               curr_depth(D),
               D1 is D)
              ),
       retractall(num_nodes(_)),
       retractall(curr_depth(_)),
       assert(curr_depth(D1)),
       assert(num_nodes(N)).


pick_instance(Instance) :-
    type_of(list) -> pick_instance_list(Instance) ;
    type_of(tree)  -> pick_instance_tree(Instance);
    type_of(int_tree) -> class(tree, Instance).

pick_instance_int_tree(Instance) :-
    prepare_instance_theory(N, File, DSFile),
    find_instance(int_tree, N, Instance, File, DSFile).


pick_instance_tree(Instance) :- 
    prepare_instance_theory(N, File, DSFile), 
    find_instance(tree, N, Instance, File, DSFile).


pick_instance_list(Instance) :- 
    prepare_instance_theory(N, File, DSFile), 
    find_instance(list, N, Instance, File, DSFile).

populate_unreachable_nodes(Facts) :-
    ds(DS),
    findall(X, pre(DS,_,_,X), List) ,
    maplist(count_unreachable, List, Counts),
    reduce(Counts, sum, 0, Count),
    gen_node_info(Count, Facts).

gen_node_info(Count, [node(X), key(X, KX)| R]) :-
      Count > 0, 
      gen_nodename(X), !,
      key(X, KX),
      Count1 is Count - 1,
      gen_node_info(Count1, R).

gen_node_info(0, []).


count_unreachable(List, Count) :-
      count_unreachable(List, 0, Count).

count_unreachable([H|T], C, Count) :- 
        H = not(reachable(_)), !,
        C1 is C + 1,
        count_unreachable(T, C1, Count).

count_unreachable([H|T], C, Count) :-
        H \= not(reachable(_)),
        count_unreachable(T, C, Count).

count_unreachable([], C, C).
  
sum(X, Y, Z) :- Z is X + Y, !.

prepare_instance_theory(N, File, DSFile) :-
    file_cleanup,
    ds_file(DSFile),
    input_path(Path),
    vanilla_theory(Vanilla), 
    write_rules(Vanilla, VanillaRules),
    rules_str(VanillaRules, VanillaStr),
    reasoning_path(RPath),
    string_concat(DSFile, "_heap", DSPath),
    string_concat(RPath, DSPath, File),
    add_text_to_file(VanillaStr, File),
    precondition_rules(Rules),
    write_rules(Rules, Rules1),
    % write_rules_alt(Rules, Rules1),
    rules_str(Rules1, RulesStr),
    add_text_to_file(RulesStr, File),
    populate_unreachable_nodes(Unreachable),
    facts(Unreachable, UnreachableStr),
    add_text_to_file(UnreachableStr, File),
    num_nodes(N).


find_instance(int_tree, N, R, File, DSFile) :-
    treegen([int_tree, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ;  R = Instance). 
    

find_instance(tree, N, R, File, DSFile) :-
    treegen([tree, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ;  %R = Instance).
                  filter_node_properties(Models, NodeProps),
                  append(Instance, NodeProps, R)). 
 


find_instance(list, N, R, File, DSFile) :-
    treegen([list, N], Instance),
    facts(Instance, Str),
    write(Str),
    add_text_to_file(Str, File),
    string_concat(DSFile, "_heap", DSFile1),
    solve_models(DSFile1, one, Models),
    (Models = [] -> increase_num_nodes, pick_instance(R)
                  ; R = Instance). 
                  % filter_node_properties(Models, NodeProps),
                  %append(Instance, NodeProps, R)). 



string_term(X, Y) :- term_string(Y, X).

filter_node_prop(X, X) :-  
        X =.. [Name|_],
        node_property(Name),
        Name \= edge, Name \= left, Name \= right, Name \= lt, Name \= key, Name \= node.

filter_node_prop(X, []) :-
        X =.. [Name|_], 
        (Name \= edge ; Name = left ; Name = right ; Name = lt ; Name = key).


filter_node_prop(X, []) :-
        X =.. [Name|_], 
        not(node_property(Name)).


filter_node_properties(Models, NodeProps) :-
         flatten(Models, Models1),
         maplist(string_term, Models1, Terms),
         maplist(filter_node_prop, Terms, Props),
         flatten(Props, NodeProps).
