
get_node_terms([node(var(X))|T], [X|R]) :-
		get_node_terms(T, R).

get_node_terms([], []).

get_key_terms([key(var(X))|T], [X|R]) :-
		get_key_terms(T, R).

get_key_terms([], []).

%gen_eq_rule((Rule, Arg), []) :-
%      dom_of(Arg, Rule, Domain),
%      type_of()
%      Domain \= node, Domain \= num.


gen_eq_rule((Rule, constant(_)), Rule) :- !.
gen_eq_rule((Rule, Arg), []) :-
     Rule = rule(head(Head), body(Body)),
     append([Head], Body, Literals),
     not(type_of(Arg, Literals, _)).

gen_eq_rule((Rule, Arg), []) :-
    Rule = rule(head(Head), body(Body)),
    append([Head], Body, Literals),
    type_of(Arg, Literals, Type),
    Type \= node, Type \= num.

gen_eq_rule((Rule, Arg), EqRule) :-
	  Rule = rule(head(Head), body(Body)),
	  %dom_of(Arg, Body, node),
	  %generate_symbol(node, X),
	  append([Head], Body, Literals),
	  type_of(Arg, Literals, node),
	  gensym(Arg, _),  % ignore first call to gensym which might generate the same symbol
	  gensym(Arg, X),
	  Head =.. [Name|Args],
	  replace(Arg, X, Args, Args1),
	  RewriteHead =.. [Name|Args1],
	  EqRule = rule(head(RewriteHead), body([Head, eq_node(X, Arg)])).

gen_eq_rule((Rule, Arg), EqRule) :-
	  Rule = rule(head(Head), body(Body)),
	  % dom_of(Arg, Body, key),
	  % generate_symbol(key, X),
	  append([Head], Body, Literals),
	  type_of(Arg, Literals, num),
	  gensym(Arg, _),   % ignore first call to gensym which might generate the same symbol
	  gensym(Arg, X),
	  Head =.. [Name|Args],
	  replace(Arg, X, Args, Args1),
	  RewriteHead =.. [Name|Args1],
	  EqRule = rule(head(RewriteHead), body([Head, eq_num(X, Arg)])).

gen_eq_rules(constraint(X), [constraint(X)]).

gen_eq_rules(Rule, [Rule]) :-
     Rule = rule(head(Head), body(Body)),
     Head =.. [Name], !.



gen_eq_rules(Rule, EqRules) :-
     Rule = rule(head(Head), body(Body)),
     Head =.. [_|Args],
     length(Args, L), L >= 1,
     cross_element(Rule, Args, Pairs),
     maplist(gen_eq_rule, Pairs, EqRules).

assert_fluents_as_time_dependent :- 
      findall(X, fluent(X), List),
      assert_time_dependent(List).

assert_time_dependent([H|T]) :- 
		 signature(H, Arity, _),
		 Arity1 is Arity + 1,
         assert(time_dependent(H, Arity1)),
         assert_time_dependent(T).

assert_time_dependent([]).


reify_rule(Rule, Rule2) :-
       Rule = rule(head(Head), body(Body)),
       append([Head], Body, Literals),
       %generate_symbol(time, T),
       add_time_list(t, Literals, [Head1|Body1]),
       Rule2 = rule(head(Head1), body([time(t)|Body1])).

reify_rule(Rule, Rule2) :-
       Rule = constraint(Body),
       Literals = Body,
       %generate_symbol(time, T),
       add_time_list(t, Literals, Body1),
       Rule2 = constraint([time(t)|Body1]).


 reified_theory(Rules) :-
 	       cleanup, 
 	       retractall(symcount(_, _)),
        base_theory(UserDefinedTheory),
        assert_base_theory(UserDefinedTheory),
         assert_fluents_as_time_dependent,
         maplist(rewrite_rule, UserDefinedTheory, Rewrites),
         maplist(gen_eq_rules, Rewrites, EqRules),
         flatten(EqRules, EqRules1),
         remove_duplicates(EqRules1, EqRules2),
        %  write_rules_to_file('EqRules2', EqRules2),
         maplist(reify_rule, EqRules2, ReifiedEq),
         maplist(reify_rule, Rewrites, ReifiedRewrites),
         findall(X, invariant(X), Invariants), 
         maplist(gen_invariant_rule, Invariants, InvariantConstraints),
         append(ReifiedRewrites, ReifiedEq, Preamble),
         append(Preamble, InvariantConstraints, Part1),
         append(Part1, EqRules2, Part2), 
         append(Rewrites, Part2, Part3),
         gen_destructive_update_rules(DestructiveUpdateRules),
         append(Part3, DestructiveUpdateRules, Part4),
         project_into_time(ProjectedRules),
         append(Part4, ProjectedRules, Part5),
         node_property_eq_rules(NodePropEqRules),
         append(Part5, NodePropEqRules, Rules),
         format_constructor(ConstructorRules),
         assert_list(ConstructorRules).

reified_theoryV2(Rules) :-
         cleanup, 
         retractall(symcount(_, _)),
         base_theory(UserDefinedTheory),
         assert_base_theory(UserDefinedTheory),
         assert_fluents_as_time_dependent,
         maplist(rewrite_rule, UserDefinedTheory, Rewrites),
         %maplist(gen_eq_rules, Rewrites, EqRules),
         %flatten(EqRules, EqRules1),
         %remove_duplicates(EqRules1, EqRules2),
        %  write_rules_to_file('EqRules2', EqRules2),
         %maplist(reify_rule, EqRules2, ReifiedEq),
         maplist(reify_rule, Rewrites, ReifiedRewrites),
         findall(X, invariant(X), Invariants), 
         maplist(gen_invariant_rule, Invariants, InvariantConstraints),
         gen_destructive_update_rules(DestructiveUpdateRules),
         project_into_time(ProjectedRules),
         reduce([ReifiedRewrites, InvariantConstraints, DestructiveUpdateRules, ProjectedRules],append,[], Rules).

vanilla_theory(Rules2) :-
    cleanup,
    base_theory(UserDefinedTheory),
    assert_base_theory(UserDefinedTheory),
    maplist(rewrite_rule, UserDefinedTheory, Rewrites),
    cross_element(Rewrites, [signature, fluent, constructor], Pair),
    maplist(remove_term, Pair, Rules),
    flatten(Rules, Rules1),
    remove_duplicates(Rules1, Rules2).

prepare_base_theory :-
       % copy_command('./eq_theories.lp', './reasoning_files/base_theory.lp', Cmd),
       % shell(Cmd, _),
       reified_theoryV2(Rules),
       write_rules_alt(Rules, S),
       rules_str(S,S1),
       shell('cat empty > ./reasoning_files/base_theory.lp',_),
       add_contents_to_file('./reasoning_files/base_theory.lp', S1). 


gen_invariant_rule(not(Pred), constraint([time(t), Pred1])) :-
      add_time_unconditional(t, Pred, Pred1), !.


gen_invariant_rule(Pred, constraint([time(t), not(Pred1)])) :-
      add_time_unconditional(t, Pred, Pred1), !.


gen_destructive_update_rules(Rules) :-
          findall(Step, primitive_write_step(Step, _), Steps),
          maplist(gen_destructive_update_rule, Steps, EffectAxioms),
          maplist(gen_inertia_rules, Steps, InertialRules),
          flatten(InertialRules, InertialRules1),
          append(EffectAxioms, InertialRules1, Rules).

gen_destructive_update_rule(WriteStep, Rule) :-
          causes(Effect, Step),
          Step =.. [WriteStep|Args],
          add_time_unconditional(t1, Effect, EffectT),
          add_time_unconditional(t, Step, StepT),
          Rule = rule(head(EffectT), body([time(t),time(t1), next_time(t, t1),StepT])).

gen_inertia_rules(WriteStep, Rules) :-
        causes(Effect, Step),
        Step =.. [WriteStep|Args],
        node_property(Property), 
        fluent(Property),
        Effect =.. [Property|_],
        modifies(Mem, Step1), 
        Step1 =.. [WriteStep|Args1],
        term_string(Property, Ps),
        string_concat('modifies_', Ps, Mods),
        term_string(ModifiesName, Mods),
        ModifiesHead =.. [ModifiesName, Mem], !, 
        add_time_unconditional(t, ModifiesHead, ModifiesHeadT),
        add_time_unconditional(t, Step1, Step2),
        ModifiesRule = rule(head(ModifiesHeadT), body([time(t), Step2])),
        add_time_unconditional(t, Effect, EffectT),
        add_time_unconditional(t1, Effect, EffectT1),
        index_of(Mem, Args1, Index),
        element_at_index(Index, Args, MemElement),
        ModifiesHead1 =.. [ModifiesName, MemElement],
        add_time_unconditional(t, ModifiesHead1, ModifiesT),
        InertiaRule = rule(head(EffectT1), body([time(t), time(t1), next_time(t, t1), EffectT, not(ModifiesT)])), !,
        Rules = [ModifiesRule, InertiaRule].

project_into_time(Rules) :-
        findall(Prop, (node_property(Prop), fluent(Prop)), Properties), 
        project_into_time_helper(Properties, Rules).


project_into_time_helper([H|T], Rules) :-
         signature(H, Arity, Domains), 
         retractall(symcount(_, _)), 
         gensym(x, _), 
         length(List, Arity), !, 
         maplist(gensym, List, Syms), !, 
         Head =.. [H|Syms],
         add_time_unconditional_constant(t1, Head, Headt1),
         map_domains(Domains, Syms, Doms),
         Rule = rule(head(Headt1), body([Head|Doms])),
         project_into_time_helper(T, R),
         append([Rule], R, Rules).

map_domains([Dom|D],[Arg|A], Domains) :-
        Term =.. [Dom, Arg],
        map_domains(D, A, R),
        append([Term], R, Domains).    

map_domains([], [], []).


project_into_time_helper([], []).


node_property_dummy_rule(Property, Dummy) :-
        signature(Property, Arity, _),
        retractall(symcount(_, _)),
        length(Args, Arity),
        gensym(x, _),
        maplist(gensym, Args, Syms),
        Head =.. [Property|Syms],
        Dummy = rule(head(Head), body([])).

node_property_eq_rules(Rules) :-
       findall(X, node_property(X), Properties),
       maplist(node_property_dummy_rule, Properties, DummyRules),
       maplist(gen_eq_rules, DummyRules, EqRules),
       flatten(EqRules, EqRules1),
       remove_duplicates(EqRules1, Rules).


assert_constructor_as_start :-
          constructor(X),
          assert(start(X)).


has_definition(Name, [H|_]) :- 
          H = rule(head(Head), _),
          Head =.. [Name|_].

has_definition(Name, [H|T]) :-
          H = rule(head(Head), _),
          Head =.. [Name1|_],
          Name \= Name1,
          has_definition(Name, T).

has_definition(Name, [H|T]) :-
          H \= rule(_, _),
          has_definition(Name, T).

rewrites(X) :-  base_theory(T), maplist(rewrite_rule, T, X).
 
reset_metadata :- cleanup, base_theory(_).

format_constructor(RulesFmt) :-
      rewrites(Rewrites),
      % reset_metadata,
      assert_constructor_as_start,
      start(Start),
      get_rules_by_name(Start, Rewrites, Rules),
      format_constructor_rules(Rules, RulesFmt).


get_rules_by_name(Name, [H|T], Rules) :-
          H = rule(head(Head), _),
          Head =.. [Name|_],
          get_rules_by_name(Name, T, R),
          append([H], R, Rules).

get_rules_by_name(Name, [H|T], Rules) :-
          (H \= rule(head(Head), _) ;
            H = rule(head(Head), _),
            Head =.. [Name1|_],
            Name \= Name1),
          get_rules_by_name(Name, T, Rules).

get_rules_by_name(_, [], []).

get_rules_by_names([H|T], Rules, FilteredRules) :-
        get_rules_by_name(H, Rules, Filtered),
        get_rules_by_names(T, Rules, Filtered2),
        append(Filtered, Filtered2, FilteredRules).

get_rules_by_names([], _, []).


format_constructor_rules([H|T], RulesFmt) :-
        format_constructor_rule(H, Fmt),
        find_nonterminals(H, Nonterminals),
        remove_duplicates(Nonterminals, Nonterminals1),
        assert_nonterminals(Nonterminals1),
        fresh_nonterminals([H|T], Nonterminals1, Nonterminals2),
        rewrites(Rewrites),
        get_rules_by_names(Nonterminals2, Rewrites, NonterminalRules),
        append(T, NonterminalRules, MoreRules),
        format_constructor_rules(MoreRules, Fmt2),
        append([Fmt], Fmt2, RulesFmt).


fresh_nonterminals(Rules, [H|T], N) :-
          name_in_rules(H, Rules),
          fresh_nonterminals(Rules, T, N).

fresh_nonterminals(Rules, [H|T], N) :-
          not(name_in_rules(H, Rules)),
          fresh_nonterminals(Rules, T, N1),
          append([H], N1, N).

fresh_nonterminals(_, [], []).

name_in_rules(Name, [H|_]) :-
        H = rule(head(Head), _),
        Head =..[Name|_].

name_in_rules(Name, [H|T]) :-
        H = rule(head(Head), _),
        Head =..[Name2|_],
        Name \= Name2, 
        name_in_rules(Name, T).


format_constructor_rules([], []).  


format_constructor_rule(Rule, RuleFmt) :-
        Rule = rule(head(Head), body(Body)), 
        append([Head], Body, Lit), 
        maplist(domain_info, [Head|Body], Doms),
        flatten(Doms, Doms1),
        append(Lit, Doms1, Literals),
        maplist(format_constructor_term, Literals, [Head1|Body1]),
        flatten(Body1, Body2),
        remove_duplicates(Body2, Body3),
        RuleFmt = rule(head(Head1), body(Body3)).


domain_info(Term, Domains) :-
        lint_negation(Term, Term2),
        Term2 =.. [Name|Args],
        signature(Name, _, Doms),
        map_domains(Doms, Args, Domains).


format_constructor_term(Term, Term2) :- 
          Term =.. [Name|Args],
          maplist(format_constructor_arg, Args, Args1), 
          Term2 =.. [Name|Args1].


format_constructor_arg(constant(X), X).
format_constructor_arg([], []) :- !.
format_constructor_arg(X, Xs) :-
             X = [_|_], !,
             maplist(format_constructor_arg, X, Xs). 
format_constructor_arg(X, var(X)) :-
             X \= constant(_),
             X \= [_|_].
           

find_nonterminals(Rule, Nonterminals) :-
         Rule = rule(head(_), body(Body)),
         maplist(get_name, Body, Names),
         maplist(is_nonterminal, Names, Results),
         remove(false, Results, Nonterminals).

is_nonterminal(X, false) :-
         is_primitive(X).

is_nonterminal(X, X) :-
          not(is_primitive(X)).

is_primitive(X) :-
       not(has_definition(X)).

has_definition(X) :-
        rule_base(head(H), _), % rule_base is the original rule from base theory
        H =.. [X|_].       

assert_base_theory([H|T]) :-
      H = rule(head(Head), body(Body)),
      assert(rule_base(head(Head), body(Body))),
      assert_base_theory(T).

assert_base_theory([H|T]) :-
      H = constraint(Body),
      assert(constraint_base(Body)),
      assert_base_theory(T).

assert_base_theory([]).


assert_nonterminals([H|T]) :-
        assert(nonterminal(H)),
        assert_nonterminals(T).

assert_nonterminals([]).




:- dynamic causes/2.
:- dynamic modifies/2.
:- dynamic node_property/1.
:- dynamic start/1.
:- dynamic rule/2.
:- dynamic rule_base/2.
:- dynamic constraint_base/1.
:- dynamic nonterminal/1.