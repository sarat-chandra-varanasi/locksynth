


pre(tree, insert, block1, [
       not(reachable(target)), visited(x, target), leaf(x), key(x,kx), key(target, ktarget),
      lt(kx, ktarget)
      ]).

program_steps(tree, insert, block1, [
   link_right(x, target)
   ]).

pre(tree, insert,  block2, [
      not(reachable(target)), visited(x, target), leaf(x), key(x,kx), key(target, ktarget),
      lt(ktarget, kx)
      ]).

program_steps(tree, insert, block2, [
       link_left(x, target)
       ]).

pre(tree, delete, block1, 
    [reachable(x), leaf(x), left(z, x)]).

program_steps(tree, delete, block1,[
          link_left(z, nil)
      ]).

pre(tree, delete, block2,  [reachable(x), visited(x,x), leaf(x), right(z, x)]).

program_steps(tree, delete, block2, [link_right(z, nil)]).


pre(tree, delete,  block3, 
     [reachable(x),  not(leaf(x)), left(z,x), left(x, y), not(has_right(x))]).
      
program_steps(tree, delete,  block3, [link_left(x,y)]).



pre(tree, delete,  block4, 
     [reachable(x),  not(leaf(x)), left(z,x), not(has_left(x)), right(x,y)]).

program_steps(tree, delete,  block4,[link_left(x,y)]).

pre(tree, delete, block5, 
     [reachable(x),  not(leaf(x)), right(z,x), left(x, y), not(has_right(x))]).

program_steps(tree, delete, block5, [link_left(x,y)]).

pre(tree, delete, block6, 
     [reachable(x),  not(leaf(x)), right(z,x), not(has_left(x)), right(x,y)]).

program_steps(tree, delete, block6, [link_left(x,y)]).


pre(tree, delete, block7, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x), 
   inorder_successor(x, succ), right(x, succ), left(z, x), left(x,y)]).

program_steps(tree, delete, block7, [link_left(z, succ),link_left(succ, y)]).

pre(tree, delete,  block8, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x), 
   inorder_successor(x, succ), right(x, succ), right(z, x), left(x,y)]).

program_steps(tree, delete, block8, [link_right(z, succ),link_left(succ, y)]).

pre(tree, delete,  block9, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x),
   inorder_successor(x,succ), not(left(x,succ)), not(right(x,succ)), left(x,l), right(x,r), left(z, x), left(z1, succ)]).

program_steps(tree, delete, block9, [link_left(z,succ), link_left(succ,l), link_right(succ,r), link_left(z1, nil)]).


pre(tree, delete,  block10, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x),
   inorder_successor(x,succ), not(left(x,succ)), not(right(x,succ)), left(x,l), right(x,r), left(z, x), right(z1, succ)]).

program_steps(tree, delete, block10,  [link_left(z,succ), link_left(succ,l), link_right(succ,r), link_right(z1, nil)]).

pre(tree, delete, block11, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x),
   inorder_successor(x,succ), not(left(x,succ)), not(right(x,succ)), left(x,l), right(x,r), right(z, x), left(z1, succ)]).

program_steps(tree, delete, block11, [link_right(z,succ), link_left(succ,l), link_right(succ,r), link_left(z1, nil)]).


pre(tree, delete, block12, 
  [reachable(x),  not(leaf(x)), has_left(x), has_right(x),
   inorder_successor(x,succ), not(left(x,succ)), not(right(x,succ)), left(x,l), right(x,r), right(z, x), right(z1, succ)]).

program_steps(tree, delete, block12, [link_right(z,succ), link_left(succ,l), link_right(succ,r), link_right(z1, nil)]).

