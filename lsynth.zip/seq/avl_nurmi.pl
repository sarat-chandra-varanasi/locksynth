% Page 174, Figure 3(a)
pre(avl_nurmi, add, case1, [
	    left(p, x), reachable(p),
        not(reachable(internal)), not(reachable(target)), visited(x, target), external(x), 
        key(x, kx), key(target, ktarget),
        lt(ktarget, kx), tag(x, w), sum(w, -1, w1)	
        ]).

program_steps(avl_nurmi, add, case1, [
          link_left(p, internal),
          link_left(internal, target),
          link_right(internal, x),
          change_tag(internal, w1)
	]).

pre(avl_nurmi, add, case2, [
	    left(p, x), reachable(p),
        not(reachable(internal)), not(reachable(target)), visited(x, target), external(x), 
        key(x, kx), key(target, ktarget),
        lt(kx, ktarget), tag(x, w), sum(w, -1, w1)	
        ]).

program_steps(avl_nurmi, add, case2, [
          link_left(p, internal),
          link_right(internal, target),
          link_left(internal, x),
          change_tag(internal, w1)
	]).


pre(avl_nurmi, add, case3, [
	    right(p, x), reachable(p),
        not(reachable(internal)), not(reachable(target)), visited(x, target), external(x), 
        key(x, kx), key(target, ktarget),
        lt(ktarget, kx), tag(x, w), sum(w, -1, w1)	
        ]).

program_steps(avl_nurmi, add, case3, [
          link_right(p, internal),
          link_left(internal, target),
          link_right(internal, x),
          change_tag(internal, w1)
	]).

pre(avl_nurmi, add, case4, [
	    right(p, x), reachable(p),
        not(reachable(internal)), not(reachable(target)), visited(x, target), external(x), 
        key(x, kx), key(target, ktarget),
        lt(kx, ktarget), tag(x, w), sum(w, -1, w1)	
        ]).

program_steps(avl_nurmi, add, case4, [
          link_right(p, internal),
          link_right(internal, target),
          link_left(internal, x),
          change_tag(internal, w1)
	]).


% Page 174, Figure 3(b)
pre(avl_nurmi, remove, case1, [
         reachable(gp), left(gp, p), child(p,x),
         external(x), sibling(x, y),
         tag(y, j), tag(p, i),
         rbf_plus(p, val), 
         sum(i, j, temp),
         sum(temp, 1, temp2),
         minus(val, neg_val),
         sum(temp2, neg_val, final)
	]).

program_steps(avl_nurmi, remove, case1, [
         link_left(gp, y), 
         change_tag(y, final)
	]).


pre(avl_nurmi, remove, case2, [
         reachable(gp), right(gp, p), child(p,x),
         external(x), sibling(x, y),
         tag(y, j), tag(p, i),
         rbf_plus(p, val), 
         sum(i, j, temp),
         sum(temp, 1, temp2),
         minus(val, neg_val),
         sum(temp2, neg_val, final)
	]).

program_steps(avl_nurmi, remove, case2, [
         link_right(gp, y), 
         change_tag(y, final)
	]).


% Page 174, Figure 4(a)
pre(avl_nurmi, balance, case1, [
          reachable(u), child(u, v),
          rbf(u, wu), tag(u, 0), tag(v, -1), rbf_plus(u, wu1),
          minus(wu1, wu2), sum(wu2, -1, wu3), sum(wu, 1, wu4)
	]).

program_steps(avl_nurmi, balance, case1, [
           change_rbf(u, wu4),
           change_tag(u, wu3),
           change_tag(v, 0)
	]).


% Page 174, Figure 4(b)
pre(avl_nurmi, balance, case2, [
          reachable(u), child(u, v),
          rbf(u, wu), tag(u, 0), tag(v, wv), int_gt(wv, 0),
          sum(wu, -1, wu1), rbf_minus(u, wu2), minus(wu2, wu3), sum(wv, -1, wv1)
	]).

program_steps(avl_nurmi, balance, case2, [
           change_rbf(u, wu1),
           change_tag(u, wu3),
           change_tag(v, wv1)
	]).




% Page 175, Figure 5, followed by symmetry cases
pre(avl_nurmi, single_rotation, case1, [
           reachable(p), left(p, u), 
           tag(u, wu), 
           left(u, v),
           rbf(v, wv),
           sum(wv, -1, wv1),
           rbf_minus(v, wv2),
           sum(wv2, 1, wv3),
           minus(wv2, wv4),
           sum(wu, wv4, wu1),
           left(v, a), right(v, b), right(u, c)
	]).

program_steps(avl_nurmi, single_rotation, case1, [
            link_right(v, u),
            link_left(u, b),
            link_left(p, v),
            change_rbf(v, wv1),
            change_tag(v, wu1),
            change_rbf(u, wv3),
            change_tag(u, 0)
	]).

pre(avl_nurmi, single_rotation, case2, [
           reachable(p), right(p, u), 
           tag(u, wu), 
           left(u, v),
           rbf(v, wv),
           sum(wv, -1, wv1),
           rbf_minus(v, wv2),
           sum(wv2, 1, wv3),
           minus(wv2, wv4),
           sum(wu, wv4, wu1),
           left(v, a), right(v, b), right(u, c)
	]).

program_steps(avl_nurmi, single_rotation, case2, [
            link_right(v, u),
            link_left(u, b),
            link_right(p, v),
            change_rbf(v, wv1),
            change_tag(v, wu1),
            change_rbf(u, wv3),
            change_tag(u, 0)
	]).

pre(avl_nurmi, single_rotation, case3, [
           reachable(p), left(p, u), 
           tag(u, wu), 
           right(u, v),
           rbf(v, wv),
           sum(wv, -1, wv1),
           rbf_minus(v, wv2),
           sum(wv2, 1, wv3),
           minus(wv2, wv4),
           sum(wu, wv4, wu1),
           left(v, a), right(v, b), left(u, c)
	]).

program_steps(avl_nurmi, single_rotation, case3, [
            link_left(v, u),
            link_right(u, a),
            link_left(p, v),
            change_rbf(v, wv1),
            change_tag(v, wu1),
            change_rbf(u, wv3),
            change_tag(u, 0)
	]).

pre(avl_nurmi, single_rotation, case4, [
           reachable(p), right(p, u), 
           tag(u, wu), 
           right(u, v),
           rbf(v, wv),
           sum(wv, -1, wv1),
           rbf_minus(v, wv2),
           sum(wv2, 1, wv3),
           minus(wv2, wv4),
           sum(wu, wv4, wu1),
           left(v, a), right(v, b), left(u, c)
	]).

program_steps(avl_nurmi, single_rotation, case4, [
            link_left(v, u),
            link_right(u, a),
            link_right(p, v),
            change_rbf(v, wv1),
            change_tag(v, wu1),
            change_rbf(u, wv3),
            change_tag(u, 0)
	]).
