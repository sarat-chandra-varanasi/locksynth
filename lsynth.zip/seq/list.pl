
domain(node).
domain(time).
domain(num).
domain(key).
domain(round).
domain(int).
domain(color).
domain(tag).

:- dynamic node_property/1.

operation(list, insert).
operation(list, delete).

primitive_write_step(list, link).

modifies(list, x, link(x,y)).
causes(list, edge(x,y), link(x,y)).

%time_dependent(edge, 3).
%time_dependent(list, 2).
%time_dependent(suffix, 2).
%time_dependent(reachable, 2).
%time_dependent(present, 2).
%time_dependent(list, 1).


%constants(h, node).
%constants(t, node).
%constants(kh, num).
%constants(kt, num).

terminal_node_symbol(t).
terminal_node_symbol(nil).

%signature(list, 1, [time]).
%signature(suffix, 2, [node, time]).
%signature(reachable, 2, [node, time]).
%signature(edge, 3, [node, node, time]).
%signature(key, 2, [node, num]).
%signature(present, 2, [key, time]).
%signature(link, 3, [node, node, time]).
%signature(lt, 2, [num, num]).
  


%signature(reachable(_), [node]).
%signature(key(_, _), [node, num]).
%signature(edge(_,_), [node, node]).
%signature(suffix(_), [node]).
%signature(link(_, _), [node, node]).
%signature(lt(_,_), [num, num]).
%signature(present(_), [num]).

max_steps(5).


write_operation(list, insert, [node(target)]).
write_operation(list, delete, [node(target)]).

code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). 

pre(list, insert,  block1, 
     [reachable(x), edge(x, y), not(reachable(target)), key(x, kx), key(y, ky), 
      key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)]).
program_steps(list, insert, block1,
         [link(x,target),link(target,y)]).
   
post(list, insert, block1,
     [reachable(target)]
    ).


pre(list, delete, block1,
     [reachable(x), edge(x, target), edge(target, y) , key(x,kx), 
      key(y, ky), key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)]).

program_steps(list, delete, block1,
     [link(x,y)]).
post(list, delete, block1 ,[not(reachable(target))] ).

next_node(list,x,(y, [edge(x, y)])).
end_node(list, t).
next_node(list, t, t).


max_depth(6).


%class(list, [node(a), node(b), node(c), node(d), edge(a, b), edge(b, c), edge(d, kd), key(a, ka), key(b, kb), key(c, kc), key(d, kd),
%            num(ka), num(kb), num(kc), num(kd), node(h), node(t), key(h, kh), key(t, kt), num(kh), num(kt)]).


