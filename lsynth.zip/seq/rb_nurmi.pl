
% All cases taken from Nurmi chromatic search tree paper, see "reference papers/nurmi chromatic.pdf"
% Commented out cases are redundant 


pre(rb_nurmi, blacking, case1, [
      reachable(p), left(p, c), 
    weight_left(p, w), 
    int_gt(w, 0), 
    weight_left(c, 0),
    weight_right(c, 0),
    sum(w, -1, w1)
	]).

program_steps(rb_nurmi, blacking, case1, [
         change_weight_left(p, w1)
	]).


pre(rb_nurmi, blacking, case2, [
	reachable(p), right(p, c), 
    weight_right(p, w), 
    int_gt(w, 0), 
    weight_left(c, 0),
    weight_right(c, 0),
    sum(w, -1, w1)
    ]).

program_steps(rb_nurmi, blacking, case2, [
      change_weight_right(p, w1)
	]).



pre(rb_nurmi, reduce_weight, case1, [ 
      reachable(gp), 
      left(gp, p), left(p, u), right(p, v), 
      weight_left(gp, w1), weight_left(p, w2), weight_right(p, w3),
      int_gte(w1, 0), int_gt(w2,1), int_gt(w3, 0),
      sum(w1, 1, w11), sum(w3, -1, w33)
      ]).

program_steps(rb_nurmi, reduce_weight, case1, [ 
           change_weight_left(gp, w11),
           change_weight_right(p, w33)

        ]).


pre(rb_nurmi, reduce_weight, case2, [ 
      reachable(gp), 
      left(gp, p), left(p, u), right(p, v), 
      weight_left(gp, w1), weight_left(p, w2), weight_right(p, w3),
      int_gte(w1,0), int_gt(w2,0), int_gt(w3, 1),
      sum(w1, 1, w11), sum(w2, -1, w22)

      ]).

program_steps(rb_nurmi, reduce_weight, case2, [ 
           change_weight_left(gp, w11),
           change_weight_left(p, w22)
        ]).



pre(rb_nurmi, reduce_weight, case3, [ 
      reachable(gp), 
      right(gp,p), left(p, u), right(p, v), 
      weight_right(gp, w1), weight_left(p, w2), weight_right(p, w3),
      int_gte(w1, 0), int_gt(w2,1), int_gt(w3,0),
      sum(w1, 1, w11), sum(w3, -1, w33)

      ]).

program_steps(rb_nurmi, reduce_weight, case3, [ 
           change_weight_right(gp, w11),
           change_weight_right(p, w33)

        ]).


pre(rb_nurmi, reduce_weight, case4, [ 
      reachable(gp), 
      right(gp, p), left(p, u), right(p, v), 
      weight_right(gp, w1), weight_left(p, w2), weight_right(p, w3),
      int_gte(w1,0), int_gt(w2,0), int_gt(w3,1),
      sum(w1, 1, w11), sum(w2, -1, w22)

      ]).

program_steps(rb_nurmi, reduce_weight, case4, [ 
           change_weight_right(gp, w11),
           change_weight_left(p, w22)

        ]).
pre(rb_nurmi, double_rotation, case1, [
   reachable(p), left(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul,1), weight_left(tee, wtl), int_gte(wtl,1),
      weight_right(tee, wtr), int_gte(wtr,1) 
  ]).

program_steps(rb_nurmi, double_rotation, case1, [
         link_left(tee, u),
         link_right(u, b),
         link_right(tee, v),
         link_left(v, c),
         link_left(p, tee)
  ]).

pre(rb_nurmi, double_rotation, case5, [
   reachable(p), right(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul,1), weight_left(tee, wtl), int_gte(wtl,1),
      weight_right(tee, wtr), int_gte(wtr,1) 
  ]).

program_steps(rb_nurmi, double_rotation, case5, [
         link_left(tee, u),
         link_right(u, b),
         link_right(tee, v),
         link_left(v, c),
         link_right(p, tee)
  ]).

%pre(rb_nurmi, double_rotation, case2, [
%     reachable(p), left(p, v),
%      right(v, u), left(v, d), left(u, tee), right(u, a), left(tee, b), right(tee, c),
%      weight_right(v, 0), weight_left(u, 0), weight_left(v, wvl), int_gte(wvl, 1),
%      weight_right(u, wur), int_gte(wur, 1), weight_left(tee, wtl), int_gte(wtl, 1),
%      weight_right(tee, wtr), int_gte(wtr, 1)
%   ]).



%pre(rb_nurmi, double_rotation, case3, [
%     reachable(p), right(p, v),
%      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
%      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
%      weight_left(u, wul), int_gte(wul, 1), weight_left(tee, wtl), int_gte(wtl, 1),
%      weight_right(tee, wtr), int_gte(wtr, 1)
% ]).


pre(rb_nurmi, double_rotation, case4, [
     reachable(p),right(p, v),
      right(v, u), left(v, d), left(u, tee), right(u, a), left(tee, b), right(tee, c),
      weight_right(v, 0), weight_left(u, 0), weight_left(v, wvl), int_gte(wvl,1),
      weight_right(u, wur), int_gte(wur, 1), weight_left(tee, wtl), int_gte(wtl,1),
      weight_right(tee, wtr), int_gte(wtr, 1) 

  ]).

program_steps(rb_nurmi, double_rotation, case4, [
           link_right(tee, u),
           link_left(u, c),
           link_left(tee, v),
           link_right(v, b),
           link_right(p, tee)

       ]).


pre(rb_nurmi, double_rotation, case6, [
     reachable(p),left(p, v),
      right(v, u), left(v, d), left(u, tee), right(u, a), left(tee, b), right(tee, c),
      weight_right(v, 0), weight_left(u, 0), weight_left(v, wvl), int_gte(wvl,1),
      weight_right(u, wur), int_gte(wur, 1), weight_left(tee, wtl), int_gte(wtl,1),
      weight_right(tee, wtr), int_gte(wtr, 1) 

  ]).

program_steps(rb_nurmi, double_rotation, case6, [
           link_right(tee, u),
           link_left(u, c),
           link_left(tee, v),
           link_right(v, b),
           link_left(p, tee)
       ]).







pre(rb_nurmi, rotate_and_reduce, case1,[
      reachable(p), left(p, u),
      left(u, a), right(u, v), 
      left(v, b), right(v, c), 
      weight_left(u, w1), weight_left(v, w2), weight_right(v, w3),
      int_gt(w1,1), int_gt(w2,0), int_gte(w3,1), weight_right(u, 0),
      sum(w1, -1, w11), sum(w2, -1, w22)
      ]).

program_steps(rb_nurmi, rotate_and_reduce, case1,[
               link_left(v, u),
               link_right(u, b),
               link_left(p, v),
               change_weight_left(v, 1),
               change_weight_left(u, w11),
               change_weight_right(u, w22)

        ]).

%pre(rb_nurmi, rotate_and_reduce, case2,[
%      reachable(p), left(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v,c), 
%      weight_left(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1,1), int_gt(w3,0), int_gte(w2,1), weight_right(u, 0)
%      ]).


%pre(rb_nurmi, rotate_and_reduce, case3,[
%     reachable(p), left(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v, c), 
%      weight_right(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1, 1), int_gt(w2,0), int_gte(3,1), weight_left(u, 0)
%      ]).


%pre(rb_nurmi, rotate_and_reduce, case4,[
%      reachable(p), left(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v, c), 
%      weight_right(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1, 1), int_gt(w3,0), int_gte(w2,1), weight_left(u, 0)
%      ]).


pre(rb_nurmi, rotate_and_reduce, case5,[
      reachable(p), right(p, u),
      left(u, a), right(u, v), 
      left(v, b), right(v, c), 
      weight_left(u, w1), weight_left(v, w2), weight_right(v, w3),
      int_gt(w1, 1), int_gt(w2, 0), int_gte(w3, 1), weight_right(u, 0),
      sum(w1, -1, w11), sum(w2, -1, w22)
      ]).

program_steps(rb_nurmi, rotate_and_reduce, case5,[
               link_left(v, u),
               link_right(u, b),
               link_right(p, v),
               change_weight_left(v, 1),
               change_weight_left(u, w11),
               change_weight_right(u, w22)

       ]).


%pre(rb_nurmi, rotate_and_reduce, case6,[
%      reachable(p), right(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v, c), 
%      weight_left(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1, 1), int_gt(w3, 0), int_gte(w2, 1), weight_right(u, 0)
%      ]).


%pre(rb_nurmi, rotate_and_reduce, case7,[
%      reachable(p), right(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v, c), 
%      weight_right(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1, 1), int_gt(w2, 0), int_gte(w3, 1), weight_left(u, 0)
%      ]).


%pre(rb_nurmi, rotate_and_reduce, case8,[
%      reachable(p), right(p, u),
%      left(u, a), right(u, v), 
%      left(v, b), right(v, c), 
%      weight_right(u, w1), weight_left(v, w2), weight_right(v, w3),
%      int_gt(w1, 1), int_gt(w3, 0), int_gte(w2, 1), weight_left(u, 0)
%      ]).



  

pre(rb_nurmi, single_rotation, case1, [
        reachable(p), left(p, v),
     left(v, u), left(u, a), right(u, b), right(v, c),
     weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w, 1)
	]).

program_steps(rb_nurmi, single_rotation, case1, [
         link_right(u, v), 
         link_left(v, b),
         link_left(p, u)
	]).



%pre(rb_nurmi, single_rotation, case2, [
%     reachable(p), left(p, v),
%     left(v, u), left(u, a), right(u, b), right(v, c),
%     weight_left(v, 0), weight_right(u, 0), weight_right(v, 1), weight_left(u, w), int_gte(w,1)
%	]).



%pre(rb_nurmi, single_rotation, case3, [
%     reachable(p), left(p, v),
%  right(v, u), left(u, a), right(u, b), left(v, c),
%  weight_right(v, 0), weight_left(u, 0), weight_left(v, 1), weight_right(u, w), int_gte(w,1)
%
%	]).


pre(rb_nurmi, single_rotation, case4, [

 reachable(p), left(p, v),
  right(v, u), left(u, a), right(u, b), left(v, c),
  weight_right(v, 0), weight_right(u, 0), weight_left(v, 1), weight_left(u, w), int_gte(w,1)

	]).

program_steps(rb_nurmi, single_rotation, case4, [
          link_left(u, v),
          link_right(v, a),
          link_left(p, u)

	]).

pre(rb_nurmi, single_rotation, case5, [
      reachable(p), right(p, v),
  left(v, u), left(u, a), right(u, b), right(v, c),
  weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w,1)

	]).

program_steps(rb_nurmi, single_rotation, case5, [
         link_right(u, v), 
         link_left(v, b),
         link_right(p, u)
       ]).

%pre(rb_nurmi, single_rotation, case6, [
%  reachable(p), right(p, v),
%     left(v, u), left(u, a), right(u, b), right(v, c),
%     weight_left(v, 0), weight_right(u, 0), weight_right(v, 1), weight_left(u, w), int_gte(w,1)
%	]).

%pre(rb_nurmi, single_rotation, case7, [
%    reachable(p), right(p, v),
%    right(v, u), left(u, a), right(u, b), left(v, c),
%    weight_right(v, 0), weight_left(u, 0), weight_left(v, 1), weight_right(u, w), int_gte(w,1)
%
%	]).

pre(rb_nurmi, single_rotation, case8, [
  reachable(p), right(p, v),
  right(v, u), left(u, a), right(u, b), left(v, c),
  weight_right(v, 0), weight_right(u, 0), weight_left(v, 1), weight_left(u, w), int_gte(w,1)
	]).

program_steps(rb_nurmi, single_rotation, case8, [
         link_left(u, v),
          link_right(v, a),
          link_right(p, u)

	 ]).


