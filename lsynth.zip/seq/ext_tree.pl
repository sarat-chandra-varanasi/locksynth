% Standard insert and delete operation in external bst (leaf-oriented trees)

operation(ext_tree, insert_ext_tree).
operation(ext_tree, delete_ext_tree).
operation(ext_tree, left_rotate).
operation(ext_tree, right_rotate).

write_operation(ext_tree, insert_ext_tree, [node(target)]).
write_operation(ext_tree, delete_ext_tree, [node(target)]).


code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). 


start_node(ext_tree, root).
end_node(tree, nil).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(ext_tree, nil, nil).


pre(ext_tree, insert_ext_tree,  block1, 
  [reachable(x),  parent(x, z), left(x, y), key(x, kx), key(y, ky), not(reachable(internal)), not(reachable(target)), external(y), key(target, ktarget), 
          lt(ktarget, kx), lt(ktarget, ky)]).

program_steps(ext_tree, insert_ext_tree, block1,
          [link_left(internal, target), link_right(internal, y), link_left(x, internal)]).

pre(ext_tree, insert_ext_tree,  block2, 
	[reachable(x), parent(x, z), left(x, y), key(x, kx), key(y, ky), not(reachable(internal)), not(reachable(target)), external(y), key(target, ktarget), 
          lt(ktarget, kx), lt(ky, ktarget)]). 

program_steps(ext_tree, insert_ext_tree,  block2,[link_right(internal, target), link_left(internal, y), link_left(x, internal)]).


pre(ext_tree, insert_ext_tree,  block3,
  [reachable(x), parent(x,z), right(x, y), key(x, kx), key(y, ky), key(target, ktarget),
           lt(kx, ktarget), lt(ktarget, ky), not(reachable(target)), not(reachable(internal))]). 
program_steps(ext_tree, insert_ext_tree,  block3, [link_right(x, internal), link_left(internal, target), link_right(internal,y)]).

pre(ext_tree, insert_ext_tree, block4, [reachable(x), parent(x,z), right(x, y), key(x, kx), key(y, ky), key(target, ktarget),
          lt(kx, ktarget), lt(ky, ktarget), not(reachable(target)), not(reachable(internal))]).
program_steps(ext_tree, insert_ext_tree, block4,[link_right(x, internal), link_left(internal,y), link_right(internal,target)]).


code(ext_tree, delete_ext_tree, block1, [reachable(x), left(x, y), left(y, z), right(y, z1), external(z), external(z1)]).
program_steps(ext_tree, delete_ext_tree, block1, [link_left(x,z1)]).
pre(ext_tree, delete_ext_tree,  block2, 
	[reachable(x), left(x, y), right(y, z), left(y, z1), external(z), external(z1)]).
program_steps(ext_tree, delete_ext_tree,  block2, [link_left(x,z1)]).


pre(ext_tree, delete_ext_tree,  block3, [reachable(x), right(x, y), left(y, z), right(y,z1),external(z), external(z1)]).
program_steps(ext_tree, delete_ext_tree,  block3, [link_right(x,z1)]).


pre(ext_tree, delete_ext_tree, block4, [reachable(x), right(x, y), right(y, z), left(y,z1), external(z), external(z1)]).
program_steps(ext_tree, delete_ext_tree, block4,  [link_right(x,z1)]).

