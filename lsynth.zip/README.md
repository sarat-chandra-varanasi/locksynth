Locksynth : Given Background theory of data structure and sequential data structure knowledge, generate concurrent code (if possible)

Pre-requisites:
------------
1) Need clingo ASP solver from Potassco
   
   Easiest way to install clingo is through the miniconda distribution

   Then need to activate the correct conda environment for clingo to run

2) Need swi-prolog, can easily set up in Ubuntu based distributions using:

    sudo apt install swi-prolog-nox

3) Unzip lsynth.zip and navigate into the directory

4) Run make

5) Generated executable is locksynth


Usage :
--------

./locksynth <DS-Name> <Path-To-Theory-File> <Path-To-Sequential-DS-Knowledge> <DS-Type>

All the arguments are mandatory

<DS-Name> : can be any name such as rb (for red-black), or ext_tree (for external bst)

<Path-To-Theory-File> :  Path to ASP program containing background theory of Data structure

See lsynth/input/list.lp    [For Linked Lists]
    lsynth/input/ext_tree.lp  [For External BSTs]  for examples  


<Path-To-Sequential-DS-Knowledge> : Prolog code containing data structure preconditions, program_steps


See lsynth/seq/list.pl 
    lsynth/seq/ext_tree.pl    for examples


<DS-Type> : Either list or tree  [We want to say whether the data structure is a list or a tree]


Examples: 

 ./locksynth list ./input/list.lp ./seq/list.pl list
 ./locksynth ext_tree ./input/ext_tree.lp ./seq/ext_tree.pl


<DS-Name> determines identifies the precondition and program steps from sequential knowledge


if the DS-name is avl_tree, then

pre(avl_tree, insert, case1, [x, y, z]) identifies the precondition for case 1 of insert operation

The precondition would be [x, y, z] in this case


Similarly the program steps for the same insert operation (case 1) is indexed by avl_tree

That is, 


program_steps(avl_tree, insert, case1, [step1, step2]) identify the program steps 
for insert operation, case1

The program steps in this case would be step1, step2


Special Predicates used widely in the theories and sequential data structure knowledge:
--------------------------------------------------------------------------------------

node(X) :  X is a node type
key(X, KX) : X is a node with key KX
lt(KX, KY) : Key KX is less than KY
reachable(X) : X is a reachable node in either the tree or list considered
edge(X, Y) :  X.next == Y (for linked lists)
left(X, Y) : X.left == Y (for bsts)
right(X, Y) : X.right == Y  (for bsts)
color(X, C) : X.color == Y   (for red-black trees)
weight(X, W) : X.weight == W   (for chromatic search trees)
(and more ....)


Background theory format and requirements:
-------------------------------------------

Familiarity with ASP is desirable. Along with the ASP rules capturing data structure definitions, the
following information is required:

1) Locksynth does not perform type inference currently, so every predicate used must be qualified with a signature
  
  So a predicate reachable(X) must have signature information as:

  signature(reachable, 1, [node])    % Says, reachable has arity 1, and its first argument is of type node

  Similarly, 

  signature(left, 2, [node, node])  % left relation has arity 2, and its arguments are types node and node

  signature(color, 2, [node, color])  % color: arity, 2, of type node and color (this is perfectly allowed)

  Most of these signatures are reused heavily and can be found in ./input/ folder from any of the theory files

2) Notion of atomic write operation must be explicitly mentioned and the arity, type of arguments it manipualtes

   Example:

       primitive_write_step(link_left, 2, [node, node])  % Equivalent to x.left := y  both x, y are type node

3) Effects of atomic write operations

   Example:

    causes(left(x,y), link_left(x,y))    % Same as x.left := y causes the relation left(x,y) on the heap

4) Nodes modified by atomtic write operations
    
    modifies(x, left(x,y))  % x.left := y modifies the node x


5) Fluent qualifications, that is, which predicate are time-dependent

    Example: reachable is time-dependent, so is edge, left, right, color of a ndoe

    Sufficient examples are present in ./input/list.lp, ./input/ext_tree.lp

    Most of these fluent qualifications are re-used. Feel free to use them



Sequential Data Structure Knowledge and Requirements:
-----------------------------------------------------

1) pre and program_steps relations identify code blocks for several operations 
2) pre and program_steps must be indexed by <DS-Name> argument from command line arguments
3) Both pre and program_steps are written as a list of terms

   pre(ext_tree, insert, case1, [
          external(x), reachable(x), 
          key(x, kx), lt(kx, ky)
    ])
 
   The terms in the list identify the precondition. 
   
   a) All variables must be written in lowercase
   b) Support for minimal arithmetic using special predicates: 
      int_gt(x, y) :   x > y
      int_gte(x, y) :  x >= y
      sum(x, y, z)  : z = x + y
   c) Constant integers can be used, for example sum(x, -1, z) for z = x - 1  
  
   d) The ASP definitions for int_gt, int_gte, sum must be present in the background theory
      See Balanced trees in ./input/rb_nurmi.lp  and ./input/avl_nurmi.lp  for examples
      The relaxed external balanced trees by author Nurmi heavily use sum, int_gt and int_gte

   e) Program steps must only contain atomic write operations and nothing else. 
      Arithmetic cannot be performed in program steps, it is assumed that the necessary calculation 
      is already made, and is available in the pre-condition
      This is a fair assumption as local arithmetic computations are performed outside shared memory
4) Data Structure Traversal Knowledge:
  


Running the tool
-----------------

Given locksynth command with correct parameters:

Locksynth does the following steps:

1) Finds a maximal instance (can take some time, if there is a contradiction in the theory, it will go for ever)
2) Reports Adequacy of locks using Precondition locking strategy (mentioned in the paper) 
3) Checks for a valid program order
4) Checks for key movememnt

If either 3 or 4 are failed or information is not available, Locksynth recommends using RCU or a coarse-grain lock

If both 3, 4, succeed after 2 succeeds, Locksynth generate the synchronization code

Try list and ext_tree where locksynth can generate the code

For other data structures, locksynth atleast reports Lock Adequacy


Examples supported : 
  Linked List    :  ./locksynth list ./input/list.lp ./seq/list.pl list
  External BSTS,  : ./locksynth ext_tree ./input/ext_tree.lp ./seq/ext_tree.pl tree
  Nurmi Chromatic Search Tree  : ./locksynth rb_nurmi ./input/rb_nurmi.lp ./rb_nurmi.pl tree
  Relaxed External Red-Black Trees, : ./locksynth rb ./input/rb.lp ./rb.pl tree
  Nurmi External AVL Tree : ./locksynth avl_nurmi ./input/avl_nurmi.lp ./seq/avl_nurmi.pl tree

All the background reasoning can be seen in the ./reasoning_files/ folder
Locksynth creates several theories outlined in the paper and runs ASP Solver clingo on the generated theories


