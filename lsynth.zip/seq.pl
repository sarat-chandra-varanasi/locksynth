
domain(node).
domain(time).
domain(num).
domain(key).
domain(round).
domain(int).
domain(color).
domain(tag).


background_theory(node, node_theory).
background_theory(num, num_theory).


operation(list, insert).
operation(list, delete).

operation(ext_tree, insert_ext_tree).
operation(ext_tree, delete_ext_tree).
operation(ext_tree, left_rotate).
operation(ext_tree, right_rotate).



%primitive_write_step(list, link).
%primitive_write_step(ext_tree, link_left).
%primitive_write_step(ext_tree, link_right).
%primitive_write_step(tree, link_left).
%primitive_write_step(tree, link_right).


%primitive_write_step(rb_tree, link_left).
%primitive_write_step(rb_tree, link_right).
%primitive_write_step(rb_tree, change_color).
%primitive_write_step(rb_tree, change_tag).


modifies(list, x, link(x,y)).
modifies(ext_tree, x, link_left(x,y)).
modifies(ext_tree, x, link_right(x,y)).
modifies(tree, x, link_left(x,y)).
modifies(tree, x, link_right(x,y)).

modifies(rb_tree, x, link_left(x,y)).
modifies(rb_tree, x, link_right(x,y)).
modifies(rb_tree, x, change_color(x,c)).
modifies(rb_tree, x, change_tag(x, z)).

causes(list, edge(x,y), link(x,y)).
causes(ext_tree, left(x,y), link_left(x,y)).
causes(ext_tree, right(x,y), link_right(x,y)).
causes(tree, left(x,y), link_left(x,y)).
causes(tree, right(x,y), link_right(x,y)).


causes(rb_tree, left(x,y), link_left(x,y)).
causes(rb_tree, right(x,y), link_right(x,y)).
causes(rb_tree, color(x,c), change_color(x,c)).
causes(rb_tree, tag(x,z), change_tag(x,z)).

symbol_prefix(node, node_).
symbol_prefix(time, t).
symbol_prefix(key, k).
symbol_prefix(num, n).

:- dynamic node_property/1.
:- discontiguous node_property1/1.

node_property(edge).
node_property(key).

%time_dependent(edge, 3).
%time_dependent(list, 2).
%time_dependent(suffix, 2).
%time_dependent(reachable, 2).
%time_dependent(present, 2).
%time_dependent(lst, 1).

%time_dependent(left, 3).
%time_dependent(right, 3).
%time_dependent(external, 2).
%time_dependent(internal, 2).
%time_dependent(parent, 3).
%time_dependent(leaf, 2).
%time_dependent(visited, 3).
%time_dependent(inorder_successor, 3).
%time_dependent(height_left, 3).
%time_dependent(height_right, 3).
%time_dependent(height, 3).
%time_dependent(color, 2).
%time_dependent(sibling, 3).
%time_dependent(tag, 2).
%time_dependent(child, 2).
%time_dependent(weight, 2).
%time_dependent(weight_left, 2).
%time_dependent(weight_right, 2).
%time_dependent(weight_edge,3).

%time_dependent(black_height_left, 3).
%time_dependent(black_height_right, 3).

constants(root, node).

constants(h, node).
constants(t, node).
%constants(kh, num).
%constants(kt, num).
%constants(target, node).
%constants(ktarget, num).
constants(nil, node).
constants(root, node).
%constants(internal, node).
%constants(kinternal, num).
constants(black, color).
constants(red, color).
constants(none, tag).
constants(tagged, tag).


terminal_node_symbol(t).
terminal_node_symbol(nil).

%signature(lst, 1, [time]).
%signature(list, 1, [time]).
%signature(suffix, 2, [node, time]).
%signature(reachable, 2, [node, time]).
%signature(admissible, 2, [node, time]).
%signature(edge, 3, [node, node, time]).
%signature(key, 2, [node, num]).
%signature(admissible, 1, [time]).
%signature(present, 2, [key, time]).
%signature(link, 3, [node, node, time]).
%signature(read, 2, [node, time]).
%signature(lt, 2, [num, num]).
%signature(descendant, 4, [node, node, constant, time]).
%signature(descendant, 3, [node, node, time]).
%signature(left, 3, [node, node, time]).
%signature(right,  3, [node, node, time]).	
%signature(eq_node, 2, [node, node]).
%signature(not_eq_node, 2, [node, node]).
%signature(eq_num, 2, [num, num]).
%signature(not_eq_num, 2, [num, num]).
%signature(gt, 2, [num, num]).
%signature(eq, 2, [node, node]).
%signature(height_left, 3, [node, int, time]).
%signature(height_right, 3, [node, int, time]).
%signature(height, 3, [node, int, time]).
%signature(lt_int, 2, [int, int]).
%signature(sibling, 3, [node, node, time]).
%signature(tag, 2, [node, tag]).
  
%signature(black_height_left, 2, [node, int]).
%signature(black_height_right, 2, [node, int]).
%signature(color, 2, [node, color]).

%signature(link_left, 3, [node, node, time]).
%signature(link_right, 3, [node, node, time]).
%signature(change_color, 3, [node, color, time]).
%signature(left, 3, [node, node, time]).
%signature(right, 3, [node, node, time]).
%signature(descendant, 4, [node, node, constant, time]).
%signature(external, 2, [node, time]).
%signature(internal, 2, [node, time]).
%signature(parent, 3, [node, node, time]).
%signature(leaf, 2, [node, time]).
%signature(visited, 3, [node, node, time]).
%signature(inorder_successor, 3, [node, node, time]).
%signature(change_tag, 3, [node, tag, time]).
%signature(child, 3, [node, node, time]).
%signature(weight, 3, [node, int, time]).
%signature(weight_left, 3, [node, int, time]).
%signature(weight_right, 3, [node, int, time]).
%signature(weight_edge, 4, [node, node, int, time]).
%signature(int_gt, 2, [node, int]).
%signature(int_gte, 2, [node, int]).
%signature(sum, 3, [int, int, int]).

%signature(reachable(_), [node]).
%signature(key(_, _), [node, num]).
%signature(edge(_,_), [node, node]).
%signature(suffix(_), [node]).
%signature(link(_, _), [node, node]).
%signature(lt(_,_), [num, num]).
%signature(present(_), [num]).
%signature(external(_), [node]).
%signature(internal(_), [node]).
%signature(left(_,_), [node, node]).
%signature(right(_,_),[node, node]).
%signature(eq_node(_, _), [node, node]).
%signature(not_eq_node(_, _), [node, node]).
%signature(eq_num(_, _), [num, num]).
%signature(not_eq_num(_, _), [num, num]).
%signature(gt(_,_), [num, num]).
%signature(parent(_,_), [node, node]).
%signature(inorder_successor(_,_), [node, node]).
%signature(height_left(_, _), [node, int]).
%signature(height_right(_, _), [node, int]).
%signature(height(_, _), [node, int]).
%signature(lt_int(_, _), [int, int]).
%signature(color(_, _), [node, color]).
%signature(sibling(_, _), [node, node]).
%signature(tag(_, _), [node, tag]).
%signature(descendant(_, _, left), [node, node]).
%signature(descendant(_, _, right), [node, node]).
%signature(leaf(_), [node]).
%signature(visited(_, _), [node, node]).
%signature(child(_, _), [node, node]).
%signature(weight_left(_, _), [node, int]).
%signature(weight_right(_, _), [node, int]).
%signature(weight(_, _), [node, int]).
%signature(weight_edge(_, _, _), [node, node, int]).
%signature(int_gt(_,_), [int, int]).
%signature(int_gte(_, _), [int, int]).
%signature(sum(_,_,_), [int, int, int]).

max_steps(5).

% domains are never preconditions
% preconditions are time-dependent predicates
preconditions(reachable).
preconditions(admissible).
preconditions(edge).
preconditions(present).
preconditions(descendant).
preconditions(external).
preconditions(internal).

write_operation(list, insert, [node(target)]).
write_operation(list, delete, [node(target)]).

write_operation(ext_tree, insert_ext_tree, [node(target)]).
write_operation(ext_tree, delete_ext_tree, [node(target)]).
write_operation(ext_tree, left_rotate, _).
write_operation(ext_tree, right_rotate, _).




write_operation(rb_tree, add, [node(target)]).
write_operation(rb_tree, remove, [node(target)]).
write_operation(rb_tree, red_red_resolve, _).
%write_operation(rb_tree, left_rotate, _).
%write_operation(rb_tree, right_rotate, _).



:- dynamic ds/1.

% time is implicit
code(list, insert, [target], block1, 
     [reachable(x), edge(x, y), not(reachable(target)), key(x, kx), key(y, ky), 
      key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)],
     [link(x,target),link(target,y)],
     [reachable(target)]
    ).


code(list, delete, [target], block1,
     [reachable(x), edge(x, target), edge(target, y) , key(x,kx), 
      key(y, ky), key(target, ktarget), lt(kx, ktarget), lt(ktarget, ky)],
     [link(x,y)],
    [not(reachable(target))]  
   ).

next_node(list,x,(y, [edge(x, y)])).
end_node(list, t).
next_node(list, t, t).


start_node(rb_tree, root).
end_node(rb_tree, nil).
next_node(rb_tree,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb_tree,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb_tree, nil, nil).


start_node(avl_nurmi, root).
end_node(avl_nurmi, nil).
next_node(avl_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(avl_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(avl_nurmi, nil, nil).



start_node(nurmi, root).
end_node(nurmi, nil).
next_node(nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(nurmi, nil, nil).


start_node(list, h).

start_node(tree, root).
end_node(tree, nil).

start_node(ext_tree, root).
end_node(ext_tree, nil).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(ext_tree,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(ext_tree, nil, nil).
next_node(tree,target, x,(z,[key(x, kx),  key(target, ktarget), left(x, z), lt(ktarget, kx)])).
next_node(tree,target, x,(z,[key(x, kx),  key(target, ktarget), right(x, z), lt(kx, ktarget)])).
% next_node(tree,target,  nil, nil).

start_node(rb_nurmi, root).
end_node(rb_nurmi, nil).
next_node(rb_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb_nurmi,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb_nurmi, nil, nil).

start_node(rb, root).
end_node(rb, nil).
next_node(rb,x,(y,[key(x, kx), key(ktarget, ktarget), left(x, y), lt(ktarget, kx)])).
next_node(rb,x,(y,[key(x, kx), key(ktarget, ktarget), right(x, y), lt(kx, ktarget)])).
next_node(rb, nil, nil).
 

max_depth(6).

%class_ebst([node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, nil), right(c, nil), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, nil), right(f, nil), key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%            num(kb), num(kc), num(kd), num(ke), num(kf)]).

%class(ext_tree, [node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, i), right(c, j), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, g), right(f, h1), left(g, nil), right(g, nil),
%            left(i, nil), right(i, nil), left(j, nil), right(j, nil),
%            left(h1, nil), right(h1, nil), node(g), node(h1), node(i), node(j),
%             key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%             key(g, kg), key(h1, kh1), key(i, ki), key(j, kj),
%            num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh1), num(ki), num(kj)]).


%class(tree, [node(a), node(b), node(c), node(d), node(e), node(f), node(nil), left(root, a), right(root, b),
%            left(a, c), right(a, d), left(c, i), right(c, j), left(d, nil), right(d, nil), 
%            left(b, e), right(b, f), left(e, nil), right(e, nil), left(f, g), right(f, h1), left(g, nil), right(g, nil),
%            left(i, nil), right(i, nil), left(j, nil), right(j, nil),
%            left(h1, nil), right(h1, nil), node(g), node(h1), node(i), node(j),
%             key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),  num(ka), 
%             key(g, kg), key(h1, kh1), key(i, ki), key(j, kj),
%            num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh1), num(ki), num(kj)]).


%class(list, [node(a), node(b), node(c), node(d), edge(a, b), edge(b, c), edge(d, kd), key(a, ka), key(b, kb), key(c, kc), key(d, kd),
%            num(ka), num(kb), num(kc), num(kd), node(h), node(t), key(h, kh), key(t, kt), num(kh), num(kt)]).


class_list([node(a), node(b), node(c), node(d), edge(a, b), edge(b, c), edge(d, kd), key(a, ka), key(b, kb), key(c, kc), key(d, kd),
            num(ka), num(kb), num(kc), num(kd), node(h), node(t), key(h, kh), key(t, kt)]).

%         root
%        /   \
%       a     b
%      / \   / \
%      c  d  e   f
%     /\  /\ \  /\ 
%     g h i j l m n

class(tree, [left(root, a),  right(root, b), 
left(a, c), right(a, d),
left(b, e), right(b, f),
left(c, g), right(c, h),
left(d, i), right(d, j),
left(e, k), right(e, l),
left(f, m), right(f, n),
left(g, nil), right(g, nil),
left(h, nil), right(h, nil),
left(i, nil), right(i, nil),
left(j, nil), right(j, nil),
left(k, nil), right(k, nil),
left(l, nil), right(l, nil),
left(m, nil), right(m, nil),
left(n, nil), right(n, nil),
node(g), num(kg), key(g, kg),
node(h), num(kh), key(h, kh),
node(i), num(ki), key(i, ki),
node(j), num(kj), key(j, kj),
node(k), num(kk), key(k, kk),
node(l), num(kl), key(l, kl),
node(m), num(km), key(m, km),
node(n), num(kn), key(n, kn),
node(f), num(kf), key(f, kf),
node(e), num(ke), key(e, ke),
node(d), num(kd), key(d, kd),
node(c), num(kc), key(c, kc),
node(b), num(kb), key(b, kb),
node(a), num(ka), key(a, ka),
node(nil)]).


%class(tree, [left(root, a),  right(root, b), 
%left(a, c), right(a, d),
%left(b, e), right(b, f),
%left(c, g), right(c, h),
%left(d, i), right(d, j),
%left(e, k), right(e, l),
%left(f, m), right(f, n),
%left(g, nil), right(g, nil),
%left(h, nil), right(h, nil),
%left(i, nil), right(i, nil),
%left(j, nil), right(j, nil),
%left(k, nil), right(k, nil),
%left(l, nil), right(l, nil),
%left(m, nil), right(m, nil),
%left(n, nil), right(n, nil),
%node(g), num(kg), key(g, kg),
%node(h), num(kh), key(h, kh),
%node(i), num(ki), key(i, ki),
%node(j), num(kj), key(j, kj),
%node(k), num(kk), key(k, kk),
%node(l), num(kl), key(l, kl),
%node(m), num(km), key(m, km),
%node(n), num(kn), key(n, kn),
%node(f), num(kf), key(f, kf),
%node(e), num(ke), key(e, ke),
%node(d), num(kd), key(d, kd),
%node(c), num(kc), key(c, kc),
%node(b), num(kb), key(b, kb),
%node(a), num(ka), key(a, ka),
%node(nil)]).

invariant(list, [lst]).
invariant(ext_tree, [not(violate_order), not(ext_tree)]).

time_dependent_node_property(list, edge).
time_dependent_node_property(ext_tree, left).
time_dependent_node_property(ext_tree, right).

time_dependent_node_property(int_tree, left).
time_dependent_node_property(int_tree, right).

%class(rb_tree, [
%   left(root, a), right(root, b),
%   left(a, c), right(a, d),
%   left(b, e), right(e, f),
%   left(c, g), right(c, nil),
%   left(d, nil), right(d, nil),
%   left(e, nil), right(e, nil),
%   left(f, nil), right(f, nil),
%   left(g, nil), right(g, nil),
%   node(a), node(b), node(c), node(d), node(e), node(f), node(g),
%   node(target),
%   color(root, black),
%   color(a, black),
%   color(b, black),
%   color(c, black),
%   color(d, black),
%   color(e, black),
%   color(f, black),
%   color(g, red),
%   key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf),
%   key(g, kg), key(target, ktarget),
%   num(ka), num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(ktarget),
%   tag(a, none), tag(b, none), tag(c, none), tag(d, none), tag(e, none), tag(f, none), tag(g,none)
%  ]). 

class(rb_tree, [
    left(root, a), right(root, b),
    left(a, c), right(a, d),
    left(b, e), right(b, f),
    left(c, g), right(c, h),
    left(d, nil), right(d, nil), 
    left(e, nil), right(e, nil),
    left(f, i), right(f, j),
    left(g, nil), right(g, nil),
    left(h, k), right(h, l),
    left(i, m), right(i, n),
    left(j, nil), right(j, nil),
    left(h, k), right(h, l),
    left(m, nil), right(m, nil),
    left(n, nil), right(n, nil),
    left(k, nil), right(k, nil),
    left(l, nil), right(l, nil),
    node(a), node(b), node(c), node(d), node(e), node(f), node(g), node(h), node(i), node(j), node(k), 
    node(l), node(m), node(n), 
    color(root, black), 
    color(a, black),
    color(b, black),
    color(c, red),
    color(d, black),
    color(e, black),
    color(f, red),
    color(g, black),
    color(h, black),
    color(i, red),
    color(j, black),
    color(k, red),
    color(l, red),
    color(m, black),
    color(n, black),
    tag(a, none), tag(b, none), tag(c, none), tag(d, none), tag(e, none), tag(f, tagged), tag(g, none), tag(h, none), 
    tag(i, none), tag(j, none), tag(k, none), tag(l, none), tag(m, none), tag(n, none),  
    num(ka), num(kb), num(kc), num(kd), num(ke), num(kf), num(kg), num(kh), num(ki), num(kj), num(kk), num(kl), 
    num(km), num(kn), 
    key(a, ka), key(b, kb), key(c, kc), key(d, kd), key(e, ke), key(f, kf), key(g, kg), key(h, kh), key(i, ki), 
    key(j, kj), key(k, kk), key(l, kl), key(m, km), key(n, kn) 

  ]).