

pre(rb, add, case1, [
       reachable(x),
       external(x), parent(x, p), left(p,x), color(x, black), not(reachable(internal)), not(reachable(target)),
       key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target), 
       tag(x, none), tag(p, none), tag(target, none), tag(internal, none),
       color(p, black)
	]).

program_steps(rb, add, case1, [
        link_left(internal, target),
        link_right(internal, x),
        link_left(p, internal),
        change_color(internal, red)
       ]).


pre(rb, add, case2, [
      reachable(x), external(x), parent(x, p), left(p, x), not(reachable(internal)), not(reachable(target)),
      key(x, kx), key(target, ktarget), lt(ktarget, kx), visited(x, target),
      color(p, red), parent(p, gp), color(gp, black), left(gp, p), right(gp, c), 
      color(c, black), parent(gp, ggp), left(ggp, gp), sibling(p, y),
      tag(x, none), tag(p, none), tag(internal, none), tag(target, none), tag(gp, none), tag(c, none),
      tag(p, none)
	]).

program_steps(rb, add, case2, [
      link_left(internal, target),
      link_right(internal, x),
      link_left(p, internal),
      change_color(internal, red),
      link_right(p, gp),
      link_left(gp, y),
      link_left(ggp, p),
      change_color(p, black),
      change_color(gp, red)
	]).

pre(rb, add,  case3, [
   not(reachable(internal)), not(reachable(target)),
	 external(x), color(x, red), parent(x, p), key(x, kx), lt(ktarget, kx), parent(p, gp), left(p, x),
	 color(p, black), color(gp, red), sibling(x, y), sibling(p, sp), color(sp, red),
	 tag(x, none), tag(p, none), tag(gp, none), tag(y, none), tag(sp, none), visited(x, target)
	]).

program_steps(rb, add, case3, [
 	link_left(internal, target), link_right(internal, x), link_left(p, internal), 
	change_color(internal, black), change_color(p, red), change_color(sp, black), tag(gp, tagged),
	change_tag(target, none), change_tag(internal, none)
	]).

pre(rb, red_red_resolve, case1,  
	[
	tag(x, tagged), child(x, y), color(x, red), color(y, red), parent(x, p), color(p, black), parent(p, gp), color(gp, red),
	tag(p, none), tag(y, none), tag(gp, none)
	]).

program_steps(rb, red_red_resolve, case1, 
	[
	 change_color(x, black), change_color(p, red), change_tag(x, none), change_tag(gp, tagged)
	]).


pre(rb, remove, case1,[
       reachable(x), external(x), parent(x, p),  sibling(x, y), color(x, black), color(y, black),
       color(p, red), parent(p, gp), left(gp, p), color(gp, black),
       tag(x, none), tag(y, none), tag(p, none), tag(gp, none)	
	]).

program_steps(rb, remove, case1, [
         link_left(gp, y)
	]).


%pre(rb, remove, case2, [
%	   reachable(x), external(x), parent(x, p), parent(p, gp), sibling(x, y), 
%	   left(p, x), left(gp, p), right(gp, c), 
%	   color(p, black), color(gp, red), color(c, black),
%
%%%	]).

%program_steps(rb, remove, case2,[
%
%
%	]).