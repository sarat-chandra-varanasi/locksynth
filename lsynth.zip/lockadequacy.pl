

default_window(Operation, Block, Rules) :- 
       ds(DS),
       code(DS, Operation, _, Block, Precondition, _, _),
       get_nodes(Precondition, Nodes),
       gen_lock_rules(Nodes, Precondition, Rules).


get_nodes(Precondition, Nodes2) :-
        maplist(get_nodes_helper, Precondition, Nodes),
        flatten(Nodes, Nodes1),
        remove_duplicates(Nodes1, Nodes2).

get_nodes_helper(Predicate, Nodes) :-
         lint_negation(Predicate, Linted),
         %signature(Linted, Domains),
         Linted =.. [_|Args],
         get_types(Args, [Linted], Doms),
         filter_nodes(Doms, Nodes).
         %pick_domain_vars(node, Args, Domains, Nodes).

filter_nodes([node(X)|T], [X|R]) :-
       !, filter_nodes(T, R).

filter_nodes([X|T], R) :-
         X \= node(_), !, 
         filter_nodes(T, R).

filter_nodes([], []).

pick_domain_vars(Domain, [H|T], [Domain|D], [H|R]) :-
            pick_domain_vars(Domain, T, D, R), !.

pick_domain_vars(Domain, [_|T], [Domain1|D], R) :-
            Domain \== Domain1, !, 
            pick_domain_vars(Domain, T, D, R).

pick_domain_vars(_, [], [], []).


gen_lock_rules([H|T], Precondition, [Rule|R]) :-
        % maplist(to_var, Precondition, PreFormatted),
        add_time_list_constant(t1, Precondition, Precondition1), 
        Rule = rule(head(locked(H)),body(Precondition1)),
        gen_lock_rules(T, Precondition, R).

gen_lock_rules([], _, []).

%check_adequacy(Operation, Block, Success) :-
%      reset_counts,
%      time_chain(2, Chain),
%      gen_interference_theory(T),
%      Rule = rule(head(Rulename), _),
%      default_window(Operation, Block, Rs),
%      ds(DS),
%      code(DS, Operation, _, Block, Pre, _, _),
%      generate_symbol(time, Time1),
%      generate_symbol(time, Time2),
%      add_time_list(Time1, Pre, PreFmt1),
%      % maplist(to_var, PreFmt, PreFmt1),
%      get_interference_head_and_domains(Operation, Block, Pre, Head, DomainVars),
%      Head =.. [_|Vars],
%      append(Vars, [Time1], Vars2),
%      ConditionHead =.. [condition|Vars2],
%      CondHead =.. [condition|Vars],
%      Condition = rule(head(ConditionHead),body(PreFmt1)),
%      add_time_unconditional_constant(t1, CondHead, Condt1),
%      add_time_unconditional_constant(t2, CondHead, Condt2),
%      Falsify = rule(head(falsify),body([time(t1), time(t2), 
%                      next_time(t1, t2), Condt1, not(Condt2)])),
%      Constraint = constraint([not(falsify)]),
%      append(T, Rs, F),
%      append(F, [Condition, Falsify, Constraint], F1),
%      append(F1, Chain, F2),
%      write_rules(F2, S),
%      rules_str(S, S1),
%      term_string(Operation, Ops),
%      string_concat(Ops, "_", Ops1),
%      term_string(Block, Bs),
%      string_concat(Ops1, Bs, OperationBlock),
%      string_concat('adequacy_', OperationBlock, Adequacy),
%      add_to_base_theory(Adequacy, S1),
%      solve_models(Adequacy, one, Models),
%      (Models \= [] -> Success = false ; Success = true).


check_adequacy_2(Op, Block, true) :-
       op_blocks(Blocks), remove_duplicates(Blocks, Blocks1),
       check_adequacy_2_loop(Op, Block, Blocks1, true).


check_adequacy_2_loop(Op, Block, [(OpInterfere,BlockInterfere)|T], true) :-
      check_adequacy_2(Op, Block, OpInterfere, BlockInterfere, true),
      check_adequacy_2_loop(Op, Block, T, true).

check_adequacy_2_loop(Op, Block, [(OpInterfere,BlockInterfere)|_], false) :-
     check_adequacy_2(Op, Block, OpInterfere, BlockInterfere, false).
               
check_adequacy_2_loop(_, _, [], true).

check_adequacy_2(Operation, Block, OpInterfere, BlockInterfere, Success) :-
      assert(signature(locked, 1, [node])),
      assert(sig_type(locked, 1, [node])),
      reset_counts,
      time_chain(2, Chain),
      gen_interference_rules_positive(OpInterfere, BlockInterfere, T),
      default_window(Operation, Block, Rs),
      ds(DS),
      code(DS, Operation, _, Block, Pre, _, _),
      generate_symbol(time, Time1),
      add_time_list(Time1, Pre, PreFmt1),
      % maplist(to_var, PreFmt, PreFmt1),
      get_interference_head_and_domains(OpInterfere, BlockInterfere, Pre, Head, _),
      Head =.. [_|Vars],
      append(Vars, [Time1], Vars2),
      ConditionHead =.. [condition|Vars2],
      CondHead =.. [condition|Vars],
      Condition = rule(head(ConditionHead),body(PreFmt1)),
      add_time_unconditional_constant(t1, CondHead, Condt1),
      add_time_unconditional_constant(t2, CondHead, Condt2),
      Falsify = rule(head(falsify),body([time(t1), time(t2), 
                      next_time(t1, t2), Condt1, not(Condt2)])),
      Constraint = constraint([not(falsify)]),
      append(T, [], F),
      append(F, [Condition, Falsify, Constraint], F1),
      append(F1, Chain, F2),
      write_rules(F2, S),
      rules_str(S, S1),
      write_rules(Rs, Rs2),
      rules_str(Rs2, S2),
      string_concat(S1, '\n', S3),
      string_concat(S2, S3, S4),
      term_string(Operation, Ops),
      string_concat(Ops, "_", Ops1),
      term_string(Block, Bs),
      string_concat(Ops1, Bs, OperationBlock),
      string_concat('adequacy_', OperationBlock, Adequacy),
      add_to_base_theory(Adequacy, S4),
      solve_models(Adequacy, one, Models), !, 
      (Models \= [] -> Success = false ; Success = true).


check_adequacyV2 :-
     findall((X,Y,Z),signature(X,Y,Z), List1),
     findall((X1,Y1),signature(X,Y),List2),
     assert_sig1(List1),
     assert_sig2(List2),
     prepare_base_theory, !,
     findall((X,Y,Z),sig1(X,Y,Z), List3),
     findall((X1,Y1),sig2(X,Y),List4),
     assert_sig_original_1(List3),
     assert_sig_original_2(List4), 
     op_blocks(OpBlocks), remove_duplicates(OpBlocks, OpBlocks1),
     check_adequacy_true(OpBlocks1).

check_adequacy_true([(Op,Block)|T]) :-
      check_adequacy_2(Op, Block, true),
      check_adequacy_true(T).

check_adequacy_true([]).


ass_sig1((X,Y,Z), _) :- assert(sig1(X,Y,Z)).
ass_sig2((X,Y), _) :- assert(sig2(X,Y)).
ass_sig3((X,Y,Z), _) :- assert(signature(X,Y,Z)).
ass_sig4((X,Y), _) :- assert(signature(X,Y)).

assert_sig1(List) :- maplist(ass_sig1, List,_).
assert_sig2(List) :- maplist(ass_sig2, List,_).
assert_sig2([]).
assert_sig_original_1(List) :- maplist(ass_sig3, List,_).
assert_sig_original_2(List) :- maplist(ass_sig4, List,_).

:- dynamic sig2/2.