
:- use_module('./sasp_parser/io').

sasp_rules(Rules) :-
 	ds(DS),
 	base_theory_path(Path),
    io:load_source_files([Path], [], Rules, 0, Errs),
    Errs = 0,
    !.

base_theory(Rules) :-
     sasp_rules(Rs),
     sasp_locksynth(Rs, Rules),
     assert_base_theory(Rules).

eq_num_term(X,Y, eq_num(X,Y)).
eq_node_term(X,Y, eq_node(X,Y)).
not_eq_num_term(X,Y, not_eq_num(X,Y)).
not_eq_node_term(X,Y, not_eq_node(X,Y)).

%rewrite(X<Y,lt(X,Y)) :- !.
%rewrite(X>Y,gt(X,Y)) :- !.
rewrite(X<Y, X<Y) :- !.
rewrite(X>Y, X>Y) :- !.
rewrite(node,X=Y, eq_node(X,Y)).
rewrite(num, X=Y, eq_num(X,Y)).    
rewrite(node,X\=Y, not_eq_node(X,Y)).
rewrite(num, X\=Y, not_eq_num(X,Y)).    

rewrite_term_in_rule(_, X<Y, Rw) :-
      rewrite(X<Y, Rw), !.

rewrite_term_in_rule(_, X>Y, Rw) :-
      rewrite(X>Y, Rw), !.

rewrite_term_in_rule(Rule, X\=Y, X\=Y).
rewrite_term_in_rule(Rule, X=Y, X=Y).


%rewrite_term_in_rule(Rule, X\=Y, Rw) :-
%     (Rule = rule(head(Head), body(Body)) -> append([Head], Body, Literals) ; 
%      Rule = constraint(Body) -> Literals = Body),
%     type_of(X, Literals, Type),
%     (Type = node -> Rw = not_eq_node(X, Y) ; Type = num -> Rw = not_eq_num(X, Y)), !.

%rewrite_term_in_rule(Rule, X=Y, Rw) :-
%     (Rule = rule(head(Head), body(Body)) -> append([Head], Body, Literals) ;
%     Rule = constraint(Body) -> Literals = Body),
%     type_of(X, Literals, Type),
%     (Type = node -> Rw = eq_node(X, Y) ; Type = num -> Rw = eq_num(X, Y)), !.


rewrite_term_in_rule(_, R, R) :- !.


type_of(Var, [H|T], Type) :-
     H = not(X), !,
     type_of(Var, [X|T], Type).

type_of(Var, [H|_], Type) :- 
		not(constants(Var, _)),
    H \= not(_),
		index_in_term(Var, H, Index),
		H =.. [Name|_],   
	    sig_type(Name, _, Types),
	    element_at_index(Index, Types, Type), !.

type_of(Var, [H|T], Type) :- 
		not(constants(Var, _)),
    H \= not(_),
		not(sig_type(Name, _, Types)), !, 
	    type_of(Var, T, Type).

type_of(Var, [H|T], Type) :- 
    H \= not(_),
		not(constants(Var, _)),
		not(index_in_term(Var, H, _)), !,
		type_of(Var, T, Type).

rewrite_term_in_rule_conjunct(Rule, [H|T], Conjunct) :- 
               rewrite_term_in_rule(Rule, H, H1),
               rewrite_term_in_rule_conjunct(Rule, T, R),
               append([H1], R, Conjunct).

rewrite_term_in_rule_conjunct(_, [], []).

rewrite_rule(Rule, Rule1) :-
     Rule = rule(head(Head), body(Body)),
     rewrite_term_in_rule_conjunct(Rule, Body, Body1),
     Rule1 = rule(head(Head), body(Body1)).

rewrite_rule(Rule, Rule1) :-
     Rule = constraint(Body),
     rewrite_term_in_rule_conjunct(Rule, Body, Body1),
     Rule1 = constraint(Body1).


:- dynamic constants/2.	
:- dynamic signature/3.
:- dynamic sig_type/3.

