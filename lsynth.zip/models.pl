
:- dynamic model/1.
:- use_module(library(error)).

solve_models(equiv, success) :-
    shell('cat empty > models-eq_check', _),
    solve_models('eq_check', 1, [_|_]).

solve_models(equiv, fail) :-
    shell('cat empty > models-eq_check', _),
    solve_models('eq_check', 1, []).

solve_models(File, All, Models) :-
     ((All = all) -> Option = '0 ' ; Option = ' '),
     string_concat('clingo --outf=3 --warn no-atom-undefined', Option, Pre),
     reasoning_path(ReasoningPath),
     string_concat(ReasoningPath, File, File1),
     string_concat(Pre, File1, BaseCmd),
     % string_concat('./reasoning_files/models-',File, FileModels),
     string_concat(ReasoningPath, 'models-', ModelsPrefix),
     % string_concat('models-',File, FileModels),
     string_concat(ModelsPrefix, File, FileModels),
     string_concat('cat empty > ', FileModels, EmptyModelsCmd),
     shell(EmptyModelsCmd, _),
     string_concat(BaseCmd, ' post-process.py', PostProcess),
     string_concat(' >> ', FileModels, Redirect),
     string_concat(PostProcess, Redirect, Cmd),
     shell(Cmd, _),
     load_models(FileModels, Models).

load_models(File, Models) :-
     load_models(File),
     findall(X, model(X), Models).

load_models(File) :-
        retractall(model(_)),
        open(File, read, Stream),
        call_cleanup(load_terms(Stream),
                     close(Stream)).

load_terms(Stream) :-
        read(Stream, T0),
        load_terms(T0, Stream).

load_terms(end_of_file, _) :- !.
load_terms(model(X), Stream) :- !,
        assert(model(X)),
        read(Stream, T2),
        load_terms(T2, Stream).
load_terms(Term, Stream) :-
        type_error(model, Term).


file_cleanup :-
      reasoning_path(Path),
      Path \= './',
      string_concat(Path, '*', Everything),
      string_concat('rm -r ', Everything, Cmd),
      shell(Cmd, _).


