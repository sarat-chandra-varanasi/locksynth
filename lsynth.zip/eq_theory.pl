
eq_theory(Rules) :-
 	cleanup, 
 	retractall(symcount(_, _)),
        base_theory(UserDefinedTheory),
        assert_base_theory(UserDefinedTheory),
        maplist(rewrite_rule, UserDefinedTheory, Rewrites),
        maplist(gen_eq_rules, Rewrites, EqRules),
        flatten(EqRules, EqRules1),
        remove_duplicates(EqRules1, EqRules2),
        findall(X, invariant(X), Invariants), 
        maplist(gen_invariant_rule_notime, Invariants, InvariantConstraints),
        append(Rewrites, EqRules2, Part1), 
        node_property_eq_rules(NodePropEqRules),
        append(Part1, NodePropEqRules, Part2),
        append(Part2, InvariantConstraints, Rules),
        format_constructor(ConstructorRules),
        assert_list(ConstructorRules).


gen_invariant_rule_notime(not(Pred), constraint([Pred])).


gen_invariant_rule_notime(Pred, constraint([not(Pred)])).


prepare_eq_theory :-
       % shell('rm eq_check', _),
       copy_command('./eq_theories.lp', 'eq_theory', Cmd),
       shell(Cmd, _),
       cleanup,
       eq_theory(Rules),
       write_rules(Rules, S),
       rules_str(S,S1),
       add_contents_to_file('eq_theory', S1).