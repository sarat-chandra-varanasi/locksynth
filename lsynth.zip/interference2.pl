
gen_interference_rules_positive(Op, Block, Rules) :- 
       ds(DS),
       code(DS, Op, _, Block, Pre, Steps, _),
       gen_interference_predicate_positive_head(Op, Block, Pre, Steps, Pred), !, 
       get_locked_nodes(Op, Block, Nodes), 
       lock_window_term(Nodes, LockTerms),
       gen_interference_effect(Op, LockTerms, Pred, Steps, Effects), !, 
       rewrite_primitives(Rewrites), !,
       append(Rewrites, Pred, Rules1),
       append(Rules1, Effects, Rules).


gen_interference_predicate_positive_head(Operation, Block, Pre, Steps, Predicate) :-
     term_string(Operation, Op),
     term_string(Block, Bl),
     string_concat(Op, Bl, OpBlock),
     string_concat('interfere_', OpBlock, InterfereString),
     term_string(Interfere, InterfereString),
     conjunct_vars(Pre, Vars),
     initial_time_symbol(TimeSymbol),
     append(Vars, [constant(TimeSymbol)], HeadVars),
     Head =.. [Interfere|HeadVars],
     conjunct_domainvars(Pre, DomainVars),
     %add_time_list_constant(TimeSymbol, Pre, Body),
     %append([time(constant(TimeSymbol))], Body, Body1),
     %append(DomainVars, Body1, Body2),
     Predicate = [rule(head(Head),body(Pre))].


lock_term(Step, [node(Mem),not(locked(Mem))]) :-
       ds(DS),
       Step =..[Name|Args],
       length(Args, L),
       primitive_write_step(DS, Name),
       length(Args2, L),
       Step2 =.. [Name|Args2],
       modifies(DS, X, Step2),
       add_dummy(Args2, Args3),
       index_of(X, Args3, Index),
       element_at_index(Index, Args, Mem).

get_locked_nodes(Op, Block, Nodes) :-
          default_window(Op, Block, Rules),
          get_locked_nodes_helper(Rules, Nodes).

get_locked_nodes_helper([H|T], [X|R]) :-
       H = rule(head(locked(X)),_),
       get_locked_nodes_helper(T, R).

get_locked_nodes_helper([], []).

lock_window_term([H|T], [node(H), not(locked(H)) | R]) :-
         lock_window_term(T, R).

lock_window_term([], []). 


add_dummy([H|T], [dummy|R]) :-
      var(H), !,
      add_dummy(T, R).

add_dummy([H|T], [H|R]) :-
      nonvar(H), !,
      add_dummy(T, R).

add_dummy([], []).