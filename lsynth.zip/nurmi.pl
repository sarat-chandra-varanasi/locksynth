operation(nurmi, add).
operation(nurmi, remove).
operation(nurmi, blacking).
operation(nurmi, single_rotation).
operation(nurmi, double_rotation).
operation(nurmi, reduce_weight).
operation(nurmi, rotate_and_reduce_weight).


write_operation(nurmi, add,_).
write_operation(nurmi, remove,_).
write_operation(nurmi, blacking,_).
write_operation(nurmi, single_rotation,_).
write_operation(nurmi, double_rotation,_).
write_operation(nurmi, reduce_weight,_).
write_operation(nurmi, rotate_and_reduce_weight,_).


causes(nurmi, weight_left(x,w), change_weight_left(x,w)).
causes(nurmi, weight_right(x,w),change_weight_right(x,w)).
causes(nurmi, left(x,y), link_left(x,y)).
causes(nurmi, right(x,y), link_right(x,y)).

primitive_write_operation(nurmi, link_left).
primitive_write_operation(nurmi, link_right).
primitive_write_operation(nurmi, change_weight_left).
primitive_write_operation(nurmi, change_weight_right).

modifies(nurmi, x, link_left(x,y)).
modifies(nurmi, x, link_right(x,y)).
modifies(nurmi, x, change_weight_left(x,w)).
modifies(nurmi, x, change_weight_right(x,w)).


pre(nurmi, blacking, onlycase, 
	[
	 reachable(p), left(p, c), 
     weight_left(gp, w), int_gt(w, 0), weight_left(c, 0), weight_right(c, 0), sum(w, -1, w1) 
	]).

program_steps(nurmi, blacking, onlycase, [
     change_weight_left(c, 1),
     change_weight_right(c, 1),
     change_weight(p, w1)
	]).

pre(nurmi, single_rotation, case1, [
     reachable(p), left(p, v),
     left(v, u), left(u, a), right(u, b), right(v, c),
     weight_left(v, 0), weight_left(u, 0), weight_right(v, 1), weight_right(u, w), int_gte(w, 1)
	]).

program_steps(nurmi, single_rotation, case1, [
       link_right(u, v),
       link_left(v, b),
       link_left(p, v)
	]).

pre(nurmi, double_rotation, case1, [
      reachable(p), left(p, v),
      left(v, u), right(v, d), left(u, a), right(u, tee), left(tee, b), right(tee, c),
      weight_left(v, 0), weight_right(u, 0), weight_right(v, wvr), int_gte(wvr, 1),
      weight_left(u, wul), int_gte(wul, 1), weight_left(t, wtl), int_gte(wtl, 1),
      weight_right(t, wtr), int_gte(wtr, 1) 

	]).

program_steps(nurmi, double_rotation, case1, [
      link_left(t, u),
      link_right(u, b),
      link_right(t, v),
      link_left(v, c), 
      link_left(p, t)
	]).


pre(nurmi, reduce_weight, case1, [
        reachable(p), left(p, v),
        weight_left(p, wpl), weight_left(v, wvl), weight_right(v, wvr),
        int_gte(wpl, 1), int_gt(wvl, 1), int_gt(wvr, 1),
        sum(wpl, 1, wpl1), sum(wvl, -1, wvl1), sum(wvr, -1, wvr1)
	]).

program_steps(nurmi, reduce_weight, case1, [
      change_weight_left(p, wpl1),
      change_weight_left(v, wvl1),
      change_weight_rigth(v, wvr1)
	]).


pre(nurmi, rotate_and_reduce_weight, case1, 
	[
       reachable(p), left(p, u), 
       left(u, a), right(u, v), left(v, b), right(v, c),
       weight_left(u, w1), int_gt(w1, 1), weight_right(u, 0), 
       weight_left(v, w2), int_gte(w2, 1), 
       weight_right(v, w3), int_gte(w3, 1),
       sum(w1, -1, w11), sum(w2, -1, w21)
	]).

program_steps(nurmi, rotate_and_reduce_weight, case1, [
       link_left(v, u),
       link_right(u, b),
       change_weight_left(v, 1),
       change_weight_left(u, w11),
       change_weight_right(u, w21),
       link_left(p, v)
	]).



class(nurmi, [node(node7),
key(node7,knode7),
num(knode7),
lt(knode7,knode3),
node(node3),
key(node3,knode3),
num(knode3),
lt(knode3,knode8),
node(node8),
key(node8,knode8),
num(knode8),
lt(knode8,knode1),
node(node1),
key(node1,knode1),
num(knode1),
lt(knode1,knode12),
node(node12),
key(node12,knode12),
num(knode12),
lt(knode12,knode4),
node(node4),
key(node4,knode4),
num(knode4),
lt(knode4,kroot),
node(root),
key(root,kroot),
num(kroot),
lt(kroot,knode5),
node(node5),
key(node5,knode5),
num(knode5),
lt(knode5,knode2),
node(node2),
key(node2,knode2),
num(knode2),
lt(knode2,knode6),
node(node6),
key(node6,knode6),
num(knode6),
root(root),
root(root),
left(root,node1),
right(root,node2),
weight_left(root,7),
weight_right(root,2),
left(node1,node3),
right(node1,node4),
weight_left(node1,0),
weight_right(node1,0),
left(node2,node5),
right(node2,node6),
weight_left(node2,8),
weight_right(node2,7),
left(node3,node7),
right(node3,node8),
weight_left(node3,-3),
weight_right(node3,-3),
left(node4,node12),
weight_left(node4,7)
]).


code(DS, Operation, _, Block, Pre, Steps, _) :-
      pre(DS, Operation, Block, Pre),
      program_steps(DS, Operation, Block, Steps). 