

:- discontiguous unfold_and_check/3.
:- discontiguous unfold/3.
:- discontiguous map_vars_domain/3.
:- discontiguous rewrite_primitives_helper/2.
:- discontiguous rename_steps/4.
:- discontiguous code/7.
:- discontiguous next_node/3.
:- discontiguous traversal_start/2.
:- discontiguous unfold2_goals/3.
:- discontiguous rules_str_helper/3.
:- discontiguous unfold2/2.
:- discontiguous pair/3.
:- discontiguous nonterminal/2.