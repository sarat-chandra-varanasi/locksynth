

generate_traversal_theory_2(Theory3) :-
    reset_counts, 
     max_depth(Length), 
     time_chain(Length, Chain),
     TimeTransitiveClosureRules = 
       [rule(head(greater(t1, t2)), body([time(t1), time(t2), next_time(t2, t1)])),
        rule(head(greater(t1, t2)), body([time(t1), time(t2), time(t3), greater(t1, t3), greater(t3, t2)]))
      ],
      ds(DS),
     start_node(DS, StartNode),
     Start = rule(head(visitedAgent(StartNode, constant(t1))),body([time(constant(t1))])),
     end_node(DS, EndNode),
     EndNodeFact = rule(head(end_node(constant(EndNode))), body([])), 
     Transitive = rule(head(visitedAgent(y, t2)), body([time(t1), time(t2), next_time(t1, t2), visitedAgent(x, t1), next_node(target, x, y, t1)])),
     VisitedAgent = rule(head(visitedAgent(x)), body([visitedAgent(x,t1)])),
     TraversalDone = rule(head(done(t1)), body([time(t1), visitedAgent(x, t1), end_node(x)])),
     TraversalDoneDominated = rule(head(dominating(t1)),body([time(t1), time(t2), done(t1), done(t2), greater(t1, t2)])),
     EarliestTimeTraversalDone = rule(head(earliest(t1)), body([time(t1), done(t1), not(dominating(t1))])),
     next_node_rules_2(NextNodeRules),
     gen_rounds(Length, Rounds),
     StartOracle = rule(head(visitedOracle(StartNode, constant(1), t1)),body([time(t1)])),
     TransitiveOracle = rule(head(visitedOracle(y, r+1, t1)), body([time(t1), round(r), visitedOracle(x, r, t1), next_node(target, x, y, t1)])),  
     TransitiveOracleVisited = rule(head(visitedOracle(x, t1)), body([time(t1), round(r), visitedOracle(x, r, t1)])),
     append(Chain, NextNodeRules, NextNodeAndChain),
     Theory = [Start, Transitive, StartOracle, TransitiveOracle, TransitiveOracleVisited, TraversalDone, TraversalDoneDominated,
               VisitedAgent, EarliestTimeTraversalDone, EndNodeFact | NextNodeAndChain], 
     append(Theory, TimeTransitiveClosureRules, Theory2),
     append(Theory2, Rounds, Theory3).

next_node_rules_2(Rules) :-
     ds(DS),
     findall((CurrentNode, NextNode, Cond), next_node(DS, target, CurrentNode, (NextNode, Cond)), List),
     maplist(next_node_rules_helper_2, List, Rules).

next_node_rules_helper_2((CurrentNode, NextNode, Cond), Rule) :-
     add_time_list(t1, Cond, Cond1),
     Rule = rule(head(next_node(target, CurrentNode, NextNode, t1)), body([time(t1)|Cond1])).


detect_key_movement_2(Op, Block, Yes) :- 
   generate_traversal_theory_2(T1),
   gen_interference_rules_positive(Op, Block, T2),
   key_movement_rule(Rule), 
   key_movement_constraint(Constraint),
   append(T1, T2, T3),
   append(T3, [Rule, Constraint], T4),
   write_rules(T4, S),
   rules_str(S, S1),
   add_to_base_theory('rcucheck', S1), 
   solve_models('rcucheck', one, Models),
   (Models \= [] -> Yes = true ; Yes = false).


detect_key_movementV2(true) :-
    op_blocks(OpBlocks),
    check_movement_true(OpBlocks).

check_movement_true([(Op,Block)|T]) :-
      detect_key_movement_2(Op, Block, false), !,
      check_movement_true(T).

check_movement_true([(Op,Block)|T]) :-
      detect_key_movement_2(Op, Block, true), !.

