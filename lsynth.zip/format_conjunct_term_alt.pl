

format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. ['..', X, Y], !,
      capitalize(X, X1),
      capitalize(Y, Y1),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " .. ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [Relop, X, Y], 
      relop(Relop), !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      (Relop \= '!=' -> term_string(Relop, RelString)
                ;   RelString = ' != '),
      string_concat(X1s, RelString, X1s1),
      string_concat(X1s1, Y1s, Formatted).


%format_conjunct_term_alt(Term, Formatted) :- 
%      Term =.. [+, X, Y], !,
%      capitalize(X, X1),
%      capitalize(Y, Y1),
%      term_string(X1, X1s),
%      term_string(Y1, Y1s),
%      string_concat(X1s, " + ", X1s1),
%      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term_alt(constant(Symbol), Symbol).

format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [\=, X, Y], !,
      (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
       format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " != ", X1s1),
      string_concat(X1s1, Y1s, Formatted).

format_conjunct_term_alt(Term, Formatted) :- 
      Term =.. [=, X, Y], !,
       (X =.. TermX, length(TermX, 1) -> capitalize(X, X1) ;
       format_conjunct_term_alt(X, X1)),
      (Y =.. TermY, length(TermY, 1) -> capitalize(Y, Y1) ;
        format_conjunct_term_alt(Y, Y1)),
      term_string(X1, X1s),
      term_string(Y1, Y1s),
      string_concat(X1s, " = ", X1s1),
      string_concat(X1s1, Y1s, Formatted).


format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [not, Term2],
       format_conjunct_term_alt(Term2, Format2),
       string_concat('not ', Format2, Formatted).

format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [Name|Args],
       Name \== not,
       maplist(capitalize, Args, Caps),
       list_str(Caps, ArgsStr),
       term_string(Name, NameStr),
       string_concat(NameStr, '(',  S1),
       string_concat(S1, ArgsStr, S2),
       string_concat(S2, ')', Formatted).

format_conjunct_term_alt(Term, Formatted) :-
       Term =.. [Name],
       term_string(Name, Formatted).
